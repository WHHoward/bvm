C4R28 functional-28 manual evidence DELTA, group=runs_metadata_002.
The 28 physical runs were already completed manually; this task executed no solver.
A001-A047 raw is referenced by exact package/raw SHA and is not recopied.
Product-bit candidate classification is INDETERMINATE because no decode threshold was preregistered.
No scientific interpretation is included. HTML remains local.
