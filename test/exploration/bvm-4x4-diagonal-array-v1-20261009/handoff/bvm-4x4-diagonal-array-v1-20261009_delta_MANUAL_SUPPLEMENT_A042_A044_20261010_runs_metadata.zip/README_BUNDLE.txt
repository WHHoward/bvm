Workspace package: bvm-4x4-diagonal-array-v1-20261009_delta_MANUAL_SUPPLEMENT_A042_A044_20261010_runs_metadata.zip
Base package: bvm-4x4-diagonal-array-v1-20261009_delta_D3_CARRY_TIMING_A040_A041_20261010_source.zip
Exact member hashes are in BUNDLE_MANIFEST.json. No simulation or scientific interpretation.
