Byte-preserving snapshot of 2x1-bvm-qb-cb-series.
Archive integrity and member hashes are checked; this package does not certify
solver identity, raw semantics, or scientific validity.
