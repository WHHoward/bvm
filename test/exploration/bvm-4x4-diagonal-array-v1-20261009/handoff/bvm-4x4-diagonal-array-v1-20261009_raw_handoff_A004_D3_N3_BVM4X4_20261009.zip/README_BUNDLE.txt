One-run evidence snapshot for A004_D3_N3.
Raw SHA-256: 79357f4a5401f11cae7fc5ec1ba496b81a30fec24c6d426982f42c6fcbb56908
Generated HTML is intentionally excluded and remains local.
Mechanical artifact QA only; no scientific interpretation.
