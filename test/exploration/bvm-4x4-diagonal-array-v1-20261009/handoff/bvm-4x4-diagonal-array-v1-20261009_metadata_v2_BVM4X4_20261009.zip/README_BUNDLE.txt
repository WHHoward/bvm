Bound shared metadata v2 for bvm-4x4-diagonal-array-v1-20261009.
Source commit: 364dd2b6dc0589f1ca1de614a16583a32331a51d
Supersedes only the unbound first metadata snapshot; all six raw-run ZIPs are unchanged.
No new physical solve or scientific interpretation.
