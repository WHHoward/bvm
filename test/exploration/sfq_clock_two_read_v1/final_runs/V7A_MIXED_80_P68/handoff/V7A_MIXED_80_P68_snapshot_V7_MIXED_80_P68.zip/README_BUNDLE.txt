Byte-preserving snapshot of V7A_MIXED_80_P68.
Generated HTML was explicitly excluded by --exclude-html; local HTML files were left untouched.
Archive integrity and member hashes are checked; this package does not certify
solver identity, raw semantics, or scientific validity.
