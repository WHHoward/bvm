One-run evidence snapshot for A003_D3_N2.
Raw SHA-256: 62301133c8faa92e078032270091920710ff361ba052450c4c006092308e9ec4
Generated HTML is intentionally excluded and remains local.
Mechanical artifact QA only; no scientific interpretation.
