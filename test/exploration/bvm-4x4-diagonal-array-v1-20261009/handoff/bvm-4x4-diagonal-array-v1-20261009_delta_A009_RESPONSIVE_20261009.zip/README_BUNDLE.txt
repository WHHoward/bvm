Incremental evidence delta for bvm-4x4-diagonal-array-v1-20261009; tag=A009_RESPONSIVE_20261009.
Base delta: bvm-4x4-diagonal-array-v1-20261009_delta_BVM4X4_BUS400_20261009.zip (2c7747d5fcff639985880af4c8c6cc4e9f54bd0ecfbac95daa4787dbc58e1bf1)
Base source HEAD: 9e1070f85b3e7fcfdc1357f3e9e7bf64f834a29d
Contains A009 raw plus the responsive-visualization source/QA changes.
A007/A008 raw and A001-A006 raw are referenced by exact package/raw SHA; none are copied again.
Generated HTML is excluded. No scientific interpretation.
