Incremental CB_DIRECT D1 evidence for bvm-4x4-diagonal-array-v1-20261009; tag=20261009; group=source.
Base checkpoint source: bvm-4x4-diagonal-array-v1-20261009_delta_T1_CHAIN_A020_A022_20261009_source.zip (52425d327a7d0b58a9e664f19eb95658b16aaca385321b651bb6153c751aef5c)
A001-A022 raw is referenced by exact package/raw SHA and is not recopied.
Only A023/A024 are new physical solves. Generated HTML is excluded.
Mechanical evidence only; no event classification or scientific interpretation.
