Byte-preserving snapshot of bvm-2x2-rowcol-selection-v1-20260928.
Generated HTML was explicitly excluded by --exclude-html; local HTML files were left untouched.
Archive integrity and member hashes are checked; this package does not certify
solver identity, raw semantics, or scientific validity.
