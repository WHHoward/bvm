Workspace package: bvm-4x4-diagonal-array-v1-20261009_delta_V9_MUL_80P68_20261016_runs_metadata_001.zip
Base package: experiment_manifest.json@54aecc583c1366878caa41ba5a8d617eb0aeb93f
Exact member hashes are in BUNDLE_MANIFEST.json. No simulation or scientific interpretation.
