New-run DELTA package for A109_V9_A0_B0_80P68, A110_V9_A1_B1_80P68, A111_V9_A11_B13_80P68, A112_V9_A15_B15_80P68.
Previously retained raw files are referenced by Git-tree or package identity and raw SHA-256; they are not recopied.
Generated HTML remains local. No solver or scientific interpretation was performed by this packaging task.
