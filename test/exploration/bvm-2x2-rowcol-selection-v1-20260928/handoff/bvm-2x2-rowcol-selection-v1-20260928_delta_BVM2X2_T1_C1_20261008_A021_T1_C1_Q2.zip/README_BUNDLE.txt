Incremental evidence for bvm-2x2-rowcol-selection-v1-20260928; group=A021_T1_C1_Q2.
Base package: bvm-2x2-rowcol-selection-v1-20260928_snapshot_bvm2x2-rowcol-a001.zip (90b174f0f7ea71c6d41bcf85db1d999af9c173c0b0ecbb8de31f1c96bb4e3f50)
Base commit: 4035a3d6adcc841f4bd4269fbc32b9a3c897746a
Prior delta checkpoint: 1685ac25d57c0d9d761b8033ae8bdd75507dc930; 23 package(s).
Only new/modified files are included; existing raw evidence is hash-referenced.
Generated HTML is excluded and remains local.
No new physical solve or scientific interpretation by packaging.
