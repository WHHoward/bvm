Manual-run DELTA package for A107_MANUAL_CARRY5_11x13_210.
Previously checkpointed raw files are referenced by exact package and raw SHA-256; they are not recopied.
Generated HTML remains local. No solver or scientific interpretation was performed by this packaging task.
