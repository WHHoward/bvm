Manual-run DELTA package for A076_MANUAL_CARRY5_7x15_210, A077_MANUAL_CARRY5_15x15_210, A078_MANUAL_CARRY5_15x7_210.
Previously checkpointed raw files are referenced by exact package and raw SHA-256; they are not recopied.
Generated HTML remains local. No solver or scientific interpretation was performed by this packaging task.
