One-run evidence snapshot for A001_D3_N0.
Raw SHA-256: af13bc5105c12919b7d93817d21ebd4a3f31123fb18f1e1d39b6a90958199c4d
Generated HTML is intentionally excluded and remains local.
Mechanical artifact QA only; no scientific interpretation.
