One-run evidence snapshot for A002_D3_N1.
Raw SHA-256: f977347a31d24a932262d2a87a145d344b96b56393bce99ebf592cf6dd7a2be2
Generated HTML is intentionally excluded and remains local.
Mechanical artifact QA only; no scientific interpretation.
