Incremental BVM 4x4 D3 Carry timing evidence; group=runs_metadata.
Base checkpoint is A034-A039; A001-A039 raw is referenced by exact SHA and not recopied.
Only A040 and A041 are new physical solves. HTML is excluded.
Mechanical arithmetic only; no event/SFQ classification or scientific interpretation.
