N1_10 source snapshot ZIP attachments, preserved exactly.
Base raw handoff SHA-256: 04b1860397c5c890218e023c632bc387ceb0bf34bfa88a54af47fd1161e9d9bc
N1_10 raw SHA-256: cebce73fe814d065e7a203e1c8568751a898db5daeaeb4c6c1b29b8f1f360b37
No new simulation or interpretation.
