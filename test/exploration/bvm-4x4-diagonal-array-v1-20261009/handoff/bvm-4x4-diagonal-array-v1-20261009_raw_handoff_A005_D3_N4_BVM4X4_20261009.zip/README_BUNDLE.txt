One-run evidence snapshot for A005_D3_N4.
Raw SHA-256: 3b8cb325ed025ae83c3be83226284473357d5e7ec3a472dda6c75fcdd4050060
Generated HTML is intentionally excluded and remains local.
Mechanical artifact QA only; no scientific interpretation.
