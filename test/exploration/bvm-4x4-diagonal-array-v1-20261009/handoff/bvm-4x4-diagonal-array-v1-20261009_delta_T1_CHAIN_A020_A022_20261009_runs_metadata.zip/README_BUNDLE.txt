Incremental evidence DELTA for bvm-4x4-diagonal-array-v1-20261009; tag=20261009; group=runs_metadata.
Base checkpoint: bvm-4x4-diagonal-array-v1-20261009_delta_T1_A017_A019_20261009_source.zip (0a6274c3fb28bb9cafab41336b542daf25cd37e6adad5c4871c0050a9f4dcd2a)
A001-A019 raw is referenced by exact package/raw SHA; it is not recopied.
This package contains only new source/config, run metadata, or one raw file.
Large raw files are split from their run metadata so each uncompressed group stays below the ordinary Git file guard.
Generated HTML is excluded; no scientific interpretation.
