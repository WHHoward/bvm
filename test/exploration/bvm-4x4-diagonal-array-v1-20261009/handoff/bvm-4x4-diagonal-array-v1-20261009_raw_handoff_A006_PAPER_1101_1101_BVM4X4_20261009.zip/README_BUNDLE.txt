One-run evidence snapshot for A006_PAPER_1101_1101.
Raw SHA-256: a318d8c09a958886ab1b3ec8ed636bf42c7b46b7fc9055353cff47ae0432b9cc
Generated HTML is intentionally excluded and remains local.
Mechanical artifact QA only; no scientific interpretation.
