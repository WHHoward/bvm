Byte-preserving snapshot of runs.
Archive integrity and member hashes are checked; this package does not certify
solver identity, raw semantics, or scientific validity.
