Incremental evidence delta for bvm-4x4-diagonal-array-v1-20261009; tag=A010_A012_20261009; group=A011_PAPER_1101_1101.
Base delta: bvm-4x4-diagonal-array-v1-20261009_delta_A009_RESPONSIVE_20261009.zip (a852fa8453ca5d7315767958a96c35dce3465956e1b8a964035af4bc071a2a91)
Base source HEAD: 617311779e996494194ef1aa9bb172295158ea81
Batch additions: A010_PAPER_1101_1101, A011_PAPER_1101_1101, A012_PAPER_1101_1101.
A001-A009 raw is referenced by exact package/raw SHA; no previous raw is copied again.
Generated HTML is excluded. No scientific interpretation.
