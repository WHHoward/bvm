Manual supplemental evidence package for A042-A044.
These runs are separate from the registered A040/A041 authorization; this package does not retroactively authorize physical solves.
A001-A041 raw is referenced by package identity and SHA-256, never recopied.
Generated HTML remains local. This packaging operation ran no solver and performed no scientific interpretation.
