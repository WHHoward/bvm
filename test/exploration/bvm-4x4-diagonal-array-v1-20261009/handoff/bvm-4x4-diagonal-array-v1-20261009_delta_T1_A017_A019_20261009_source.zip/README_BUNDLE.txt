Incremental evidence delta for bvm-4x4-diagonal-array-v1-20261009; tag=T1_A017_A019_20261009; group=source.
Base delta: bvm-4x4-diagonal-array-v1-20261009_delta_T1_7WAY_20261009_source.zip (2e18febe15b39a926484cf53bd4242ac51d261710ef41c2543f4fc656411af2e)
Base source HEAD: 684531519dda6e0a1e8ffec24d0711ee08adf6d1
Batch additions: A017_PAPER_1101_1101, A018_T1_ALL_QUIET, A019_T1_ALL_PLUSE.
A001-A016 raw is referenced by exact package/raw SHA; no previous raw is copied again.
A017 postprocess-invalid raw is preserved and clearly tagged INVALID in the manifest.
Generated HTML is excluded. No scientific interpretation.
