Incremental post-CB sJTL evidence for bvm-4x4-diagonal-array-v1-20261009; tag=A030_A033_20261010; group=source.
Base checkpoint: bvm-4x4-diagonal-array-v1-20261009_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_source.zip (ef0da398613b065b4c3cb896040a1e6b8089f469d56f111dfdbf2950e546b955).
A001-A029 raw is referenced by package/raw SHA and is not recopied.
A030-A033 are the only new physical solves. Generated HTML is excluded.
Mechanical evidence only; no event classifier, bit decode, or scientific interpretation.
