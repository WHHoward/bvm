# L1_NOMINAL — V2.1 system-chain summary

Registered parameters: RJ1=12 ohm; L1=2 pH; IBias=250 uA.

Evidence-only navigation; scientific interpretation was not performed.

## 01_SIGNAL_TIMING
[OVERVIEW_0_200ps](../../plots/v2_1/standalone/L1_NOMINAL/01_SIGNAL_TIMING/OVERVIEW_0_200ps.html) · [FINAL_101_135ps](../../plots/v2_1/standalone/L1_NOMINAL/01_SIGNAL_TIMING/FINAL_101_135ps.html) · [READ_110_121ps](../../plots/v2_1/standalone/L1_NOMINAL/01_SIGNAL_TIMING/READ_110_121ps.html)

## 02_BVM_STATE
[OVERVIEW_0_200ps](../../plots/v2_1/standalone/L1_NOMINAL/02_BVM_STATE/OVERVIEW_0_200ps.html) · [STATE_90_140ps](../../plots/v2_1/standalone/L1_NOMINAL/02_BVM_STATE/STATE_90_140ps.html) · [FINAL_101_135ps](../../plots/v2_1/standalone/L1_NOMINAL/02_BVM_STATE/FINAL_101_135ps.html)

## 03_JSL_CHAIN
[OVERVIEW_0_200ps](../../plots/v2_1/standalone/L1_NOMINAL/03_JSL_CHAIN/OVERVIEW_0_200ps.html) · [CHAIN_101_135ps](../../plots/v2_1/standalone/L1_NOMINAL/03_JSL_CHAIN/CHAIN_101_135ps.html) · [READ_110_121ps](../../plots/v2_1/standalone/L1_NOMINAL/03_JSL_CHAIN/READ_110_121ps.html)

## 04_QB_STATE
[OVERVIEW_0_200ps](../../plots/v2_1/standalone/L1_NOMINAL/04_QB_STATE/OVERVIEW_0_200ps.html) · [STATE_101_135ps](../../plots/v2_1/standalone/L1_NOMINAL/04_QB_STATE/STATE_101_135ps.html) · [READ_110_121ps](../../plots/v2_1/standalone/L1_NOMINAL/04_QB_STATE/READ_110_121ps.html) · [QB_110_130ps](../../plots/v2_1/standalone/L1_NOMINAL/04_QB_STATE/QB_110_130ps.html)

## 05_JTL_CHAIN
[OVERVIEW_0_200ps](../../plots/v2_1/standalone/L1_NOMINAL/05_JTL_CHAIN/OVERVIEW_0_200ps.html) · [CHAIN_110_140ps](../../plots/v2_1/standalone/L1_NOMINAL/05_JTL_CHAIN/CHAIN_110_140ps.html)

## Boundaries

Every category uses INPUT -> INTERNAL -> OUTPUT ordering.

## Unknowns

Missing emitted probe columns remain UNKNOWN; no event or mechanism classification is generated.
