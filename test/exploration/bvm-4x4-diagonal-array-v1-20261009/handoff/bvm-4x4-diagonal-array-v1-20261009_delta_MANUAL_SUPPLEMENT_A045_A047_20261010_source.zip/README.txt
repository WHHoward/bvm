Manual supplemental evidence package for A045-A047.
These runs are outside the registered authorization batches; packaging makes no retroactive authorization claim.
A001-A044 raw is referenced by package identity and SHA-256, never recopied. HTML remains local.
This packaging operation ran no solver and performed no scientific interpretation.
