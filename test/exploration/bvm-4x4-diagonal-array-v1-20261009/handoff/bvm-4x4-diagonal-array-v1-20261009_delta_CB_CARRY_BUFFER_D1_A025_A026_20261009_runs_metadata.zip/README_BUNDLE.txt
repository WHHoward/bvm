Incremental D1 carry-side CB_0928 evidence for bvm-4x4-diagonal-array-v1-20261009; tag=A025_A026_20261009; group=runs_metadata.
Base checkpoint: bvm-4x4-diagonal-array-v1-20261009_delta_CB_DIRECT_D1_20261009_source.zip (e2838461d7dd5f4ed0b6478abf39e80ff1741e87484b0637dec67c3b7ce23a51).
A001-A024 raw is referenced by exact package/raw SHA and is not recopied.
Only A025/A026 are new physical solves. Generated HTML is excluded.
Mechanical evidence only; no SFQ event classification or scientific interpretation.
