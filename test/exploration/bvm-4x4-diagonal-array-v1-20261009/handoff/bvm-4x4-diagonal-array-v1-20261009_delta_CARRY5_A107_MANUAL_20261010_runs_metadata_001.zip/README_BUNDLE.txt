Workspace package: bvm-4x4-diagonal-array-v1-20261009_delta_CARRY5_A107_MANUAL_20261010_runs_metadata_001.zip
Base package: bvm-4x4-diagonal-array-v1-20261009_delta_CARRY5_FUNCTIONAL_28_20261010_runs_metadata_001.zip
Exact member hashes are in BUNDLE_MANIFEST.json. No simulation or scientific interpretation.
