Incremental evidence delta for bvm-4x4-diagonal-array-v1-20261009; tag=T1_7WAY_20261009; group=A014_T1_ALL_CLOCK.
Base delta: bvm-4x4-diagonal-array-v1-20261009_delta_A010_A012_20261009_source.zip (a1d8871e8e015e1c58608582c57097233780baf90462e1db8459741dcc966ba9)
Base source HEAD: c42ad75d39cf796cfe863b836f6f8154388a048a
Batch additions: A013_T1_ALL_QUIET, A014_T1_ALL_CLOCK, A015_T1_PAPER_QUIET, A016_T1_PAPER_CLOCK.
A001-A009 raw is referenced by exact package/raw SHA; no previous raw is copied again.
Generated HTML is excluded. No scientific interpretation.
