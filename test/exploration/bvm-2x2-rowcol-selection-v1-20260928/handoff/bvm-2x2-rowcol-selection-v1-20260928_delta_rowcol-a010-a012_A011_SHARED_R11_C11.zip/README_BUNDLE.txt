Incremental evidence for bvm-2x2-rowcol-selection-v1-20260928; group=A011_SHARED_R11_C11.
Base package: bvm-2x2-rowcol-selection-v1-20260928_snapshot_bvm2x2-rowcol-a001.zip (90b174f0f7ea71c6d41bcf85db1d999af9c173c0b0ecbb8de31f1c96bb4e3f50)
Full-base commit: 4035a3d6adcc841f4bd4269fbc32b9a3c897746a
Prior delta checkpoint: a70ffd5c34076f0d0659b6b8ae0ade92ba0aa10a; 12 package(s).
Only new/modified evidence is included; unchanged evidence is hash-referenced.
Generated HTML was explicitly excluded and remains local.
No solver execution or scientific interpretation was performed by this package step.
