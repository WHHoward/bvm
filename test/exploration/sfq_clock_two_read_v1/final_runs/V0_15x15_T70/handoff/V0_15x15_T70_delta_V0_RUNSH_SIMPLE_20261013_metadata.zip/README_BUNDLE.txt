Incremental evidence for V0_15x15_T70; group=metadata.
Base package: V0_15x15_T70_snapshot_V0_15x15_T70.zip (b32d4bfee9598d789beda83c400aece648ded5a887352c6c81277215135b0f65)
Full-base commit: 99502551e63d3fc0931e37349a040290c69807f2
Prior delta checkpoint: 09596298547f514942bbe3a1af9a54ebd7fb7088; 1 package(s).
Only new/modified evidence is included; unchanged evidence is hash-referenced.
Generated HTML was explicitly excluded and remains local.
No solver execution or scientific interpretation was performed by this package step.
