Incremental full CB-only Carry-chain evidence for bvm-4x4-diagonal-array-v1-20261009; tag=A027_A029_20261009; group=runs_metadata.
Base checkpoint: bvm-4x4-diagonal-array-v1-20261009_delta_CB_CARRY_BUFFER_D1_A025_A026_20261009_source.zip (7640de4da96bd739e3d7c9416d5fddebc8b3453319ec7c12e44306384f29088a).
A001-A026 raw is referenced by exact package/raw SHA and is not recopied.
Only A027-A029 are new physical solves. Generated HTML is excluded.
Mechanical evidence only; no bit decode, event classification, or scientific interpretation.
