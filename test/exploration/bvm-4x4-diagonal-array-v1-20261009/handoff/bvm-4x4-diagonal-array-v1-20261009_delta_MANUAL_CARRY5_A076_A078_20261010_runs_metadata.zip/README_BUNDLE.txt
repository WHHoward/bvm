Workspace package: bvm-4x4-diagonal-array-v1-20261009_delta_MANUAL_CARRY5_A076_A078_20261010_runs_metadata.zip
Base package: bvm-4x4-diagonal-array-v1-20261009_delta_CARRY4_FUNCTIONAL_28_20261010_source_analysis.zip
Exact member hashes are in BUNDLE_MANIFEST.json. No simulation or scientific interpretation.
