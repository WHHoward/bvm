#!/usr/bin/env python3
"""Scoped source/package/push workflow for the new 4x4 diagonal experiment."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

SERIES = Path(__file__).resolve().parents[1]
REPO = SERIES.parents[2]
RUNS = SERIES / "runs"
HANDOFF = SERIES / "handoff"
MIRROR_DEFAULT = Path("/mnt/d/BVM_Backages")
ROOT_SUBMIT_PATH = REPO / "scripts" / "submit.py"
BUS400_PARENT_HEAD = "3de08ba0fd5997b253269849dbc1a535786c8fd6"
BUS400_RUN_IDS = ("A007_BUS400_D3_N0", "A008_BUS400_D3_N1")
A009_RUN_IDS = ("A009_paper_like",)
BUS400_DELTA_NAME = f"{SERIES.name}_delta_BVM4X4_BUS400_20261009.zip"
BUS400_DELTA_SHA256 = "2c7747d5fcff639985880af4c8c6cc4e9f54bd0ecfbac95daa4787dbc58e1bf1"
BUS400_DELTA_HEAD = "9e1070f85b3e7fcfdc1357f3e9e7bf64f834a29d"
A009_DELTA_NAME = f"{SERIES.name}_delta_A009_RESPONSIVE_20261009.zip"
A009_DELTA_SHA256 = "a852fa8453ca5d7315767958a96c35dce3465956e1b8a964035af4bc071a2a91"
A009_DELTA_HEAD = "617311779e996494194ef1aa9bb172295158ea81"
A010_A012_TAG = "A010_A012_20261009"
A010_A012_SOURCE_NAME = f"{SERIES.name}_delta_{A010_A012_TAG}_source.zip"
A010_A012_SOURCE_SHA256 = "a1d8871e8e015e1c58608582c57097233780baf90462e1db8459741dcc966ba9"
A010_A012_SOURCE_HEAD = "a2a9e6211975454c12f1f17d7c94446a37d1a06c"
A010_A012_RUN_PACKAGES = {
    "A010_PAPER_1101_1101": ("f4d2c24862629f9579912e2e12098d42ab9933de5793d1a60aeabcf3464c3e55",
                             "12e875f8dff37bdb3c94555a71ed3ef2f87cf986973e24d48b927a88433a3cb8"),
    "A011_PAPER_1101_1101": ("0a9ae3386fd2cb66c5ee2b6edc547e9c5ec0af36ba8e3091d356ef3d82bdca15",
                             "2e961bbabc5b1db35a6a97d4fa4ed409df8b706688d877fc1bc2f4a3ae1f961e"),
    "A012_PAPER_1101_1101": ("960e1325dbcf89331425a482cd78b1f83341922532cf72ac61efe2e5ee3f1d30",
                             "b5d96f8191506ccce430396458d1dbb7313e9860c39d4984c472b3a34e9a4f0a"),
}
A010_A012_RUN_IDS = tuple(A010_A012_RUN_PACKAGES)
T1_A013_A016_TAG = "T1_7WAY_20261009"
T1_A013_A016_SOURCE_NAME = f"{SERIES.name}_delta_{T1_A013_A016_TAG}_source.zip"
T1_A013_A016_SOURCE_SHA256 = "2e18febe15b39a926484cf53bd4242ac51d261710ef41c2543f4fc656411af2e"
T1_A013_A016_SOURCE_HEAD = "1c2e2e913c690cc613b2f232d3877e7c1b0b58cb"
T1_A013_A016_RUN_PACKAGES = {
    "A013_T1_ALL_QUIET": ("541fe5d9e5fbc86bf91cd49ccd52ade34af08e49e376c2528d0e157439ea96cb",
                          "447bc455892109221a8931a02de4e846f5ae764824a343bce9e2918e02c5153f"),
    "A014_T1_ALL_CLOCK": ("65aed4d7f05f24df9fe9a2cb813ff66027ccacd2f58db0f42e65aa0a901be0ae",
                          "fade41f8071be1db53ad5ba9299c6274dbaf69b2b40d24d37af3c07b59782f03"),
    "A015_T1_PAPER_QUIET": ("199ef479f85863617385e69e2d497a71d7f53f0e8603792fa7f2988c01b2caa8",
                            "6d0d63b72aa12332fd2d2f53313b2f244f78013ffbd0d50740b6bd2c9905c0df"),
    "A016_T1_PAPER_CLOCK": ("210ac40931a721e1d9c3c443613737f3572e46fc778988637373edb5f6db8b6c",
                            "a7a4c9d87c07bc6fc02e66090dc64168e88c80c9d937824842210c785b8cc864"),
}
T1_A013_A016_RUN_IDS = tuple(T1_A013_A016_RUN_PACKAGES)
DELTA_BASE_COMMIT = "684531519dda6e0a1e8ffec24d0711ee08adf6d1"
DELTA_BASE_PACKAGE_NAME = T1_A013_A016_SOURCE_NAME
DELTA_BASE_PACKAGE_SHA256 = T1_A013_A016_SOURCE_SHA256
DELTA_BASE_PACKAGE_SOURCE_HEAD = T1_A013_A016_SOURCE_HEAD
PREVIOUS_DELTA_RUN_IDS = T1_A013_A016_RUN_IDS
DELTA_RUN_IDS = ("A017_PAPER_1101_1101", "A018_T1_ALL_QUIET", "A019_T1_ALL_PLUSE")
INVALID_PRESERVED_DELTA_RUN_IDS = {"A017_PAPER_1101_1101"}
T1_CHAIN_BASE_COMMIT = "64b4e18e2d944fd982f5b200490f7b7575339b46"
T1_CHAIN_BASE_SOURCE_NAME = f"{SERIES.name}_delta_T1_A017_A019_20261009_source.zip"
T1_CHAIN_BASE_SOURCE_SHA256 = "0a6274c3fb28bb9cafab41336b542daf25cd37e6adad5c4871c0050a9f4dcd2a"
T1_CHAIN_BASE_SOURCE_HEAD = "d6104470e2159baa0a7ce8da748f7e4acd340600"
T1_CHAIN_BASE_RUN_PACKAGES = {
    "A017_PAPER_1101_1101": ("8b819f531cb0a1837d30c2acddba40da72dc5e5ee015ede29ff01b20286c9273",
                              "59e4ae993860061735cf6b78319512fe3d3cb20d1e8359fa89f32d12047c4023", "INVALID"),
    "A018_T1_ALL_QUIET": ("6179a2f75afb8001782275f78080c5155046b1b6cfc5188fe0062ac6dbd3d2c9",
                          "9a17cfe79805b16c7977aa23a766be9e2a7101a5553da6162f26d4a141123a1f", "VALID"),
    "A019_T1_ALL_PLUSE": ("c80a149449b14c3c9e4d6df699cbc40162205fce5358a2b9af644850b4b464cf",
                          "3cabda93970826369616d1749cb242f6e9a59576b49e55822126c2fb81212ecf", "VALID"),
}
T1_CHAIN_BASE_RUN_IDS = tuple(T1_CHAIN_BASE_RUN_PACKAGES)
T1_CHAIN_DELTA_RUN_IDS = ("A020_CHAIN_ALL_QUIET", "A021_CHAIN_ALL_GLOBAL_CLOCK",
                          "A022_CHAIN_PAPER_GLOBAL_CLOCK")
CB_DIRECT_D1_BASE_COMMIT = "6364256321eb7c7437ef20ec14a3ba604e7b4d15"
CB_DIRECT_D1_BASE_SOURCE_NAME = f"{SERIES.name}_delta_T1_CHAIN_A020_A022_20261009_source.zip"
CB_DIRECT_D1_BASE_SOURCE_SHA256 = "52425d327a7d0b58a9e664f19eb95658b16aaca385321b651bb6153c751aef5c"
CB_DIRECT_D1_BASE_RUN_PACKAGES = {
    "A020_CHAIN_ALL_QUIET": ("bf978aa2e9061dc7cbe5eabfe8643a494dd09dc37d4416b519408d4dd01d22e6",
                              "ab13d65c671065fbfcd628ff7e4ffc0a9dc0506105bcd2a5bdefd91488aa763d"),
    "A021_CHAIN_ALL_GLOBAL_CLOCK": ("21477be494024eb224c2fd4aec919638ab85fc03bf4cc80396d92aa127533f12",
                                    "85ffd3a00a6815115307d917c9b35d3b06dd7ac240c61ca8bfd47b957e975e9e"),
    "A022_CHAIN_PAPER_GLOBAL_CLOCK": ("8e18c88bf37d327b3d8e7064fc9b62a2d4a2f783dbc46c9234b45e08fec0cfb8",
                                      "2095fc87f129e844abfe21a0ccafb21e9ef2c72b67e7b6c34c8ca8f50935d9cb"),
}
CB_DIRECT_D1_BASE_METADATA_NAME = f"{SERIES.name}_delta_T1_CHAIN_A020_A022_20261009_runs_metadata.zip"
CB_DIRECT_D1_BASE_METADATA_SHA256 = "5f4132cb8ff7a702a52caa77704866551b6ee7cedbf5d77d9f0a472951e8bdc6"
CB_DIRECT_D1_RUN_IDS = ("A023_CB_DIRECT_D1_ALL_CLOCK", "A024_CB_DIRECT_D1_PAPER_CLOCK")
CB_DIRECT_D1_BASE_PACKAGE_GROUPS = (
    ("source", CB_DIRECT_D1_BASE_SOURCE_NAME, CB_DIRECT_D1_BASE_SOURCE_SHA256),
    ("runs_metadata", CB_DIRECT_D1_BASE_METADATA_NAME, CB_DIRECT_D1_BASE_METADATA_SHA256),
    ("A020_CHAIN_ALL_QUIET_raw",
     f"{SERIES.name}_delta_T1_CHAIN_A020_A022_20261009_A020_CHAIN_ALL_QUIET_raw.zip",
     CB_DIRECT_D1_BASE_RUN_PACKAGES["A020_CHAIN_ALL_QUIET"][0]),
    ("A021_CHAIN_ALL_GLOBAL_CLOCK_raw",
     f"{SERIES.name}_delta_T1_CHAIN_A020_A022_20261009_A021_CHAIN_ALL_GLOBAL_CLOCK_raw.zip",
     CB_DIRECT_D1_BASE_RUN_PACKAGES["A021_CHAIN_ALL_GLOBAL_CLOCK"][0]),
    ("A022_CHAIN_PAPER_GLOBAL_CLOCK_raw",
     f"{SERIES.name}_delta_T1_CHAIN_A020_A022_20261009_A022_CHAIN_PAPER_GLOBAL_CLOCK_raw.zip",
     CB_DIRECT_D1_BASE_RUN_PACKAGES["A022_CHAIN_PAPER_GLOBAL_CLOCK"][0]),
)
CB_CARRY_BUFFER_D1_BASE_COMMIT = "e0155de0c19e95d8c909550c67097db65695c842"
CB_CARRY_BUFFER_D1_BASE_SOURCE_HEAD = "0d7095fc395f464b7ec797ef2963afb652fe04c8"
CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME = f"{SERIES.name}_delta_CB_DIRECT_D1_20261009_source.zip"
CB_CARRY_BUFFER_D1_BASE_SOURCE_SHA256 = "e2838461d7dd5f4ed0b6478abf39e80ff1741e87484b0637dec67c3b7ce23a51"
CB_CARRY_BUFFER_D1_BASE_PACKAGES = (
    ("source", CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME, CB_CARRY_BUFFER_D1_BASE_SOURCE_SHA256),
    ("runs_metadata", f"{SERIES.name}_delta_CB_DIRECT_D1_20261009_runs_metadata.zip",
     "882b3266d2d641cecc0f9b3008517547f245a147675ff6d8fe8c6193bde8e54a"),
    ("A023_CB_DIRECT_D1_ALL_CLOCK_raw",
     f"{SERIES.name}_delta_CB_DIRECT_D1_20261009_A023_CB_DIRECT_D1_ALL_CLOCK_raw.zip",
     "87212488292ac5d0dd1f82ca4c6620e57fedcd99a8b93db8f4bddf705ec7b768"),
    ("A024_CB_DIRECT_D1_PAPER_CLOCK_raw",
     f"{SERIES.name}_delta_CB_DIRECT_D1_20261009_A024_CB_DIRECT_D1_PAPER_CLOCK_raw.zip",
     "efce60315ad48c53afd13f253f6164c755143b9f81660316dcf064d83b84876b"),
)
CB_CARRY_BUFFER_D1_RUN_IDS = ("A025_CARRY_CB_D1_ALL_CLOCK", "A026_CARRY_CB_D1_PAPER_CLOCK")
CB_CARRY_BUFFER_D1_TASK = SERIES / "analysis" / "cb-carry-buffer-d1-20261009"
CB_CARRY_BUFFER_ALL_BASE_COMMIT = "fb5139b8b0f6a084b75fcf6343faaddbfcbee104"
CB_CARRY_BUFFER_ALL_BASE_SOURCE_HEAD = "537ce2fdad2f0182ccac558fdd0ad3e1032ebf42"
CB_CARRY_BUFFER_ALL_BASE_SOURCE_NAME = f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_A025_A026_20261009_source.zip"
CB_CARRY_BUFFER_ALL_BASE_SOURCE_SHA256 = "7640de4da96bd739e3d7c9416d5fddebc8b3453319ec7c12e44306384f29088a"
CB_CARRY_BUFFER_ALL_BASE_PACKAGES = (
    ("source", CB_CARRY_BUFFER_ALL_BASE_SOURCE_NAME, CB_CARRY_BUFFER_ALL_BASE_SOURCE_SHA256),
    ("runs_metadata", f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_A025_A026_20261009_runs_metadata.zip",
     "6b5e31bf54dd9a52b1cc2c80e4b35f076c4a3d00ea87914c9af53ceddd55f908"),
    ("A025_CARRY_CB_D1_ALL_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_A025_A026_20261009_A025_CARRY_CB_D1_ALL_CLOCK_raw.zip",
     "015f11cc38a6fc95febceef620e65a93860bf242e5ab2bca4ec8edc17adf0b0e"),
    ("A026_CARRY_CB_D1_PAPER_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_A025_A026_20261009_A026_CARRY_CB_D1_PAPER_CLOCK_raw.zip",
     "c64e041625aa5d7130d12601132281b73aaf9519f8cb67814a2cfe21c6c3d753"),
)
CB_CARRY_BUFFER_ALL_RUN_IDS = ("A027_FULL_CB_CHAIN_ALL_CLOCK", "A028_FULL_CB_CHAIN_PAPER_CLOCK",
                               "A029_FULL_CB_CHAIN_3X3_CLOCK")
CB_CARRY_BUFFER_ALL_TASK = SERIES / "analysis" / "cb-carry-buffer-all-20261009"
CB_CARRY_BUFFER_ALL_BASE_RAW_PACKAGES = {
    "A025_CARRY_CB_D1_ALL_CLOCK": (
        f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_A025_A026_20261009_A025_CARRY_CB_D1_ALL_CLOCK_raw.zip",
        "015f11cc38a6fc95febceef620e65a93860bf242e5ab2bca4ec8edc17adf0b0e",
        "c9b3f6b2c3f707c599794658950de7bbbd3bfd6b51455d637ac3e0eee14369c9"),
    "A026_CARRY_CB_D1_PAPER_CLOCK": (
        f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_A025_A026_20261009_A026_CARRY_CB_D1_PAPER_CLOCK_raw.zip",
        "c64e041625aa5d7130d12601132281b73aaf9519f8cb67814a2cfe21c6c3d753",
        "f9b198ecad7a7eef7181d6f99c1d8febc28db5b47e11956f91ca3beb6b29f7aa"),
}
CARRY_POST_CB_SJTL_BASE_COMMIT = "a5168f187e97b23685863d3d0964e898bbf19863"
CARRY_POST_CB_SJTL_BASE_SOURCE_HEAD = "71a38854f1b08e878aeb7c93e07340a17334371b"
CARRY_POST_CB_SJTL_BASE_SOURCE_NAME = f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_source.zip"
CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256 = "ef0da398613b065b4c3cb896040a1e6b8089f469d56f111dfdbf2950e546b955"
CARRY_POST_CB_SJTL_BASE_PACKAGES = (
    ("source", CARRY_POST_CB_SJTL_BASE_SOURCE_NAME, CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256),
    ("runs_metadata", f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_runs_metadata.zip",
     "8a6a05168ef34928032735dd073ccfd3ff6ac8a72ec28bb1f04bf80995efface"),
    ("A027_FULL_CB_CHAIN_ALL_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_A027_FULL_CB_CHAIN_ALL_CLOCK_raw.zip",
     "a25a320aaaf189c408660e4c626afd4069ca7a5510e2727a939fea2b7d66ede6"),
    ("A028_FULL_CB_CHAIN_PAPER_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_A028_FULL_CB_CHAIN_PAPER_CLOCK_raw.zip",
     "c142a628039b8e7e9980c32081721c0081bd4d73e0b920fbea26ad491935e013"),
    ("A029_FULL_CB_CHAIN_3X3_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_A029_FULL_CB_CHAIN_3X3_CLOCK_raw.zip",
     "7c03c9af6f9007bc1cf9ae101e80d0599fb22f3f674758da2282666f06c80745"),
)
CARRY_POST_CB_SJTL_BASE_RAW_PACKAGES = {
    "A027_FULL_CB_CHAIN_ALL_CLOCK": (
        CARRY_POST_CB_SJTL_BASE_PACKAGES[2][1], CARRY_POST_CB_SJTL_BASE_PACKAGES[2][2],
        "939e6024928be84df809532ecd8b716b815a9b96ea498324fc5c30b712100e46"),
    "A028_FULL_CB_CHAIN_PAPER_CLOCK": (
        CARRY_POST_CB_SJTL_BASE_PACKAGES[3][1], CARRY_POST_CB_SJTL_BASE_PACKAGES[3][2],
        "59ba22b2c31bd04993989c16a7c37d1e5bb904c078ef9db979657de81e604701"),
    "A029_FULL_CB_CHAIN_3X3_CLOCK": (
        CARRY_POST_CB_SJTL_BASE_PACKAGES[4][1], CARRY_POST_CB_SJTL_BASE_PACKAGES[4][2],
        "d943765ab3e47c1607ab3c29ff08a1088f2444dfd8a3266e9670a1d75d24ac0f"),
}
CARRY_POST_CB_SJTL_RUN_IDS = (
    "A030_CARRY_POST_CB_SJTL_ALL_200", "A031_CARRY_POST_CB_SJTL_ALL_210",
    "A032_CARRY_POST_CB_SJTL_PAPER_210", "A033_CARRY_POST_CB_SJTL_3X3_210")
CARRY_POST_CB_SJTL_TASK = SERIES / "analysis" / "carry-post-cb-sjtl-20261010"
CARRY_SJTL_POSITION_TAG = "A034_A039_20261010"
CARRY_SJTL_POSITION_BASE_COMMIT = "9db7929608bf25fd8c2f86fb99e84b9a4387ba81"
CARRY_SJTL_POSITION_BASE_PACKAGE_NAME = f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_A030_A033_20261010_source.zip"
CARRY_SJTL_POSITION_BASE_PACKAGE_SHA256 = "a77b77cfc17ca76c7ba82ce622ba51911c6390b53abb6ca6c05f4932f744fa26"
CARRY_SJTL_POSITION_BASE_SOURCE_HEAD = "1c6abddf2c57d40ba2fb299c062a27d4764d9197"
CARRY_SJTL_POSITION_BASE_PACKAGES = (
    ("source", CARRY_SJTL_POSITION_BASE_PACKAGE_NAME, CARRY_SJTL_POSITION_BASE_PACKAGE_SHA256),
    ("runs_metadata", f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_A030_A033_20261010_runs_metadata.zip",
     "c05b2cc63ce6e40cb70d9f0da2760789d3da85f1efad9e4a15b8a3f899a9d3fc"),
    ("A030_CARRY_POST_CB_SJTL_ALL_200_raw",
     f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_A030_A033_20261010_A030_CARRY_POST_CB_SJTL_ALL_200_raw.zip",
     "a393be4167c0aedac90d65780efe9957f1f634440358b03735bdcbd2d840aec3"),
    ("A031_CARRY_POST_CB_SJTL_ALL_210_raw",
     f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_A030_A033_20261010_A031_CARRY_POST_CB_SJTL_ALL_210_raw.zip",
     "216ef1693050e783c7d5a4fe0e44817f49f5cca7d56a586a2a935afbb3725ac6"),
    ("A032_CARRY_POST_CB_SJTL_PAPER_210_raw",
     f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_A030_A033_20261010_A032_CARRY_POST_CB_SJTL_PAPER_210_raw.zip",
     "5e995c544f2f2d54e6e15b96262ae11af8e8fe048245c0e9b4993c1f38a87f3e"),
    ("A033_CARRY_POST_CB_SJTL_3X3_210_raw",
     f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_A030_A033_20261010_A033_CARRY_POST_CB_SJTL_3X3_210_raw.zip",
     "1b0a694d35a58d6693e19898c0af6c7936227543388280879d64fb20fea10f24"),
)
CARRY_SJTL_POSITION_RUN_IDS = (
    "A034_D2_ONLY_POST_CB_SJTL_ALL_200", "A035_D2_ONLY_POST_CB_SJTL_PAPER_200",
    "A036_PRE_CB_SJTL_ALL_200", "A037_PRE_CB_SJTL_ALL_210",
    "A038_PRE_CB_SJTL_PAPER_210", "A039_PRE_CB_SJTL_3X3_210")
CARRY_SJTL_POSITION_TASK = SERIES / "analysis" / "carry-sjtl-position-20261010"
CARRY_D3_TIMING_TAG = "A040_A041_20261010"
CARRY_D3_TIMING_TASK = SERIES / "analysis" / "d3-carry-timing-20261010"
CARRY_D3_TIMING_PACKAGE_DIFF_START = "d7089ace75f1450b0f48c76762373c8d105d4549"
CARRY_D3_TIMING_BASE_SOURCE_HEAD = "cf0dfb0f8aee68a56e454d146401885d8f0b483b"
CARRY_D3_TIMING_BASE_PACKAGES = (
    ("source", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_source.zip",
     "4aae6f15b29c41e5f436adf7c74282b6b73ab655e667f0ceab7b9c1682bb6cfe"),
    ("runs_metadata", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_runs_metadata.zip",
     "9ab0304367c57710a0aacb5671bfbfc6765f2a22b258a973ca7b4211f686c1e0"),
    ("A034_raw", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_A034_D2_ONLY_POST_CB_SJTL_ALL_200_raw.zip",
     "980759212b7026feb65be2cb4dbb3740f85857b4be279186fa481a054fef154d"),
    ("A035_raw", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_A035_D2_ONLY_POST_CB_SJTL_PAPER_200_raw.zip",
     "fa7c7bf07a2d78e5af256a4ee9542f74009f8b8d335991699aae4c1bb0413b0f"),
    ("A036_raw", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_A036_PRE_CB_SJTL_ALL_200_raw.zip",
     "9c2ed658418f1615d9360512992c4f5d50482a527fe26c0d6ee6f96bdae03886"),
    ("A037_raw", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_A037_PRE_CB_SJTL_ALL_210_raw.zip",
     "e27d0298517074c22597105c00194b8f829b20b95a21dd0b2cb4fc82a5b7062f"),
    ("A038_raw", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_A038_PRE_CB_SJTL_PAPER_210_raw.zip",
     "3e6bf075c7dafce0038d701a1c9f88edbf2a696b9602ed2905b9ae797cd6b23a"),
    ("A039_raw", f"{SERIES.name}_delta_CARRY_SJTL_POSITION_A034_A039_20261010_A039_PRE_CB_SJTL_3X3_210_raw.zip",
     "f496d3fcd1fe79e3c6fd9fcc3fa3bcce821e1095b74a609b8d83b11723d72f2f"),
)
CARRY_D3_TIMING_RUN_IDS = ("A040_D3_PRE_CB_SJTL_0_ALL_200", "A041_D3_PRE_CB_SJTL_2_ALL_200")
D3_MANUAL_SUPPLEMENT_TAG = "MANUAL_SUPPLEMENT_A042_A044_20261010"
D3_MANUAL_SUPPLEMENT_TASK = SERIES / "analysis" / "d3-carry-timing-supplement-20261010"
D3_MANUAL_SUPPLEMENT_RUN_IDS = (
    "A042_MANUAL_D3_CARRY_SJTL3_200",
    "A043_MANUAL_D3_CARRY_SJTL3_200",
    "A044_MANUAL_D3_CARRY_SJTL3_200",
)
D3_MANUAL_SUPPLEMENT_BASE_COMMIT = "0721b23e27b57b988123b0807c196db85a1a4f68"
D3_MANUAL_SUPPLEMENT_SOURCE_HEAD = "7db1148cfce76851f5361eeb6ff5ad7cb37bc0db"
D3_MANUAL_SUPPLEMENT_BASE_PACKAGES = (
    ("source", f"{SERIES.name}_delta_D3_CARRY_TIMING_A040_A041_20261010_source.zip",
     "c031a031710f0bb2393c1ee769fe6a9290c9fb3fe1c58b49abcc72082ddf5036"),
    ("runs_metadata", f"{SERIES.name}_delta_D3_CARRY_TIMING_A040_A041_20261010_runs_metadata.zip",
     "fc5e71ab6ed424dd655d677c69cd964402b9b916211b495a5e305ba67544bfd6"),
    ("A040_raw", f"{SERIES.name}_delta_D3_CARRY_TIMING_A040_A041_20261010_A040_D3_PRE_CB_SJTL_0_ALL_200_raw.zip",
     "7afb832e8d76336b9c795192c68903ac1ce8d77b187db1dd4fedcc5ca9e65600"),
    ("A041_raw", f"{SERIES.name}_delta_D3_CARRY_TIMING_A040_A041_20261010_A041_D3_PRE_CB_SJTL_2_ALL_200_raw.zip",
     "7bb96e3815868016338df78367816833156ac203107b8fe4f78e9b1a59b13c11"),
)
D3_MANUAL_SUPPLEMENT_RAW_SHA256 = {
    "A042_MANUAL_D3_CARRY_SJTL3_200": "3c605c64d67367616496d035896f0d3fe73c351ce1b99e017186d1449008bf03",
    "A043_MANUAL_D3_CARRY_SJTL3_200": "10c2ec0e4adaf8231f3c1bef6f746f2960ee0b38b5c6114e6bfa3799a12f845d",
    "A044_MANUAL_D3_CARRY_SJTL3_200": "d9cf83c4ca864ab9c92529c58c846586e2033880779e5aa30c50c8e59029feee",
}
CARRY4_SUPPLEMENT_TAG = "MANUAL_SUPPLEMENT_A045_A047_20261010"
CARRY4_SUPPLEMENT_TASK = SERIES / "analysis" / "carry4-manual-supplement-20261010"
CARRY4_SUPPLEMENT_RUN_IDS = (
    "A045_MANUAL_CARRY4_15x15_210",
    "A046_MANUAL_CARRY4_11x13_210",
    "A047_MANUAL_CARRY4_3x3_210",
)
CARRY4_SUPPLEMENT_BASE_COMMIT = "833f8ce2c0100457785ce359262240e2d5c5e733"
CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD = "99e32cc951a1fe7efff1db615a81c0d9121f4582"
CARRY4_SUPPLEMENT_BASE_PACKAGES = (
    ("source", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A042_A044_20261010_source.zip",
     "0e4df2074e5bac99a7f7a2b9389bec33303adda15d93285b44bff72370b49230"),
    ("runs_metadata", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A042_A044_20261010_runs_metadata.zip",
     "0b15a37801a004dc4d046fc1c343cef1bd574beb5ce7a9e7854fcaea51bba2ac"),
    ("A042_raw", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A042_A044_20261010_A042_MANUAL_D3_CARRY_SJTL3_200_raw.zip",
     "06c37e4464e5cdb765271aa0ac711b7cf0aaf995b2d78d691fb4c5241f5f2a60"),
    ("A043_raw", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A042_A044_20261010_A043_MANUAL_D3_CARRY_SJTL3_200_raw.zip",
     "691d923ad6f4d6a1fbb9168775316759cb0a52bbd311104169167c48294b33c9"),
    ("A044_raw", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A042_A044_20261010_A044_MANUAL_D3_CARRY_SJTL3_200_raw.zip",
     "23b6828cb1b65f043ef0f5a307fee9617a6d42e18c4b333e1408b8c4981237d5"),
)
CARRY4_SUPPLEMENT_RAW_SHA256 = {
    "A045_MANUAL_CARRY4_15x15_210": "a81a47b4dbbf8f967aa879440c8fc36e1b11b1647da61500a56127c665b55134",
    "A046_MANUAL_CARRY4_11x13_210": "6e20b7aeafcb278302c0c25c1c928ffaaf0903bbf68bf457b2d3361998cdacfe",
    "A047_MANUAL_CARRY4_3x3_210": "3226c4610e92ad317d3b395e937e9e21ad106d2243acab9b904dcad30ebe80bc",
}
C4R28_TAG = "CARRY4_FUNCTIONAL_28_20261010"
C4R28_ANALYSIS_DIR = SERIES / "analysis" / "carry4-functional-28-20261010"
C4R28_PLOT_DIR = SERIES / "plots" / "carry4-functional-28-20261010"
C4R28_PARENT_HEAD = "e246b41421e4341bf43f5a6c92797dd990cc6889"
C4R28_BASE_SOURCE_HEAD = "db73e1f24ca733294a01b5659c22c7b53fc529de"
C4R28_PAIRS = (
    (15, 14), (14, 15), (14, 14), (15, 13), (13, 15), (15, 11), (11, 15),
    (15, 7), (7, 15), (7, 7), (7, 14), (14, 7), (9, 13), (13, 9),
    (5, 10), (10, 5), (1, 1), (1, 15), (15, 1), (2, 15), (15, 2),
    (4, 15), (15, 4), (8, 15), (15, 8), (0, 0), (0, 15), (15, 0),
)
C4R28_BASE_PACKAGES = (
    ("source_analysis", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A045_A047_20261010_source.zip",
     "1bc3b8a504c3a5450ca8bf9127647715440031a0f4f0a10dd044f0b6cbdd8706"),
    ("runs_metadata", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A045_A047_20261010_runs_metadata.zip",
     "2439af490a86caf627b1183d41e3ed50ccc3766d42fd35af2390a5fdbf24ea26"),
    ("A045_raw", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A045_A047_20261010_A045_MANUAL_CARRY4_15x15_210_raw.zip",
     "e0117102b4368f08e40535c98d05d68d93334224da401a416c09c41cd5232ae7"),
    ("A046_raw", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A045_A047_20261010_A046_MANUAL_CARRY4_11x13_210_raw.zip",
     "e87edf926755bd4afef2ffa2a0bcd36ffb0b5d0d0577c265396f7459ec4b41fa"),
    ("A047_raw", f"{SERIES.name}_delta_MANUAL_SUPPLEMENT_A045_A047_20261010_A047_MANUAL_CARRY4_3x3_210_raw.zip",
     "e1a03660733e11ae823b949f8ddfd56f675c649098159d08364bfa77b4ce91c2"),
)
C4R28_MAX_METADATA_GROUP_BYTES = 75_000_000
C4R28_PACKAGE_FINAL_HEAD = "312a711f2a7b227be739a7bfa7bc2c11b93b6977"
MANUAL_RUN_CHECKPOINTS_PATH = SERIES / "analysis" / "MANUAL_RUN_DELTA_CHECKPOINTS.json"
MANUAL_RUN_REQUIRED_FILES = {
    "deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt", "USER_CASE.snapshot.env",
    "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env", "CBU_PARAMS.snapshot.env",
    "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env", "stimulus.inc", "case_manifest.json",
    "metadata.json", "provenance.json", "source_manifest.json", "topology_manifest.json",
    "probe_manifest.json", "static_qa.json", "stimulus_manifest.json", "metrics.json",
    "raw_qa.json", "chain_qa.json", "qa.json", "plot_manifest.json", "plot_qa.json",
    "result.json", "RESULT_BRIEF.md",
}
MANUAL_RUN_METADATA_GROUP_BYTES = 75_000_000
CARRY_POST_CB_SJTL_BASE_COMMIT = "a5168f187e97b23685863d3d0964e898bbf19863"
CARRY_POST_CB_SJTL_BASE_SOURCE_HEAD = "71a38854f1b08e878aeb7c93e07340a17334371b"
CARRY_POST_CB_SJTL_BASE_SOURCE_NAME = f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_source.zip"
CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256 = "ef0da398613b065b4c3cb896040a1e6b8089f469d56f111dfdbf2950e546b955"
CARRY_POST_CB_SJTL_BASE_PACKAGES = (
    ("source", CARRY_POST_CB_SJTL_BASE_SOURCE_NAME, CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256),
    ("runs_metadata", f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_runs_metadata.zip",
     "8a6a05168ef34928032735dd073ccfd3ff6ac8a72ec28bb1f04bf80995efface"),
    ("A027_FULL_CB_CHAIN_ALL_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_A027_FULL_CB_CHAIN_ALL_CLOCK_raw.zip",
     "a25a320aaaf189c408660e4c626afd4069ca7a5510e2727a939fea2b7d66ede6"),
    ("A028_FULL_CB_CHAIN_PAPER_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_A028_FULL_CB_CHAIN_PAPER_CLOCK_raw.zip",
     "c142a628039b8e7e9980c32081721c0081bd4d73e0b920fbea26ad491935e013"),
    ("A029_FULL_CB_CHAIN_3X3_CLOCK_raw",
     f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_A027_A029_20261009_A029_FULL_CB_CHAIN_3X3_CLOCK_raw.zip",
     "7c03c9af6f9007bc1cf9ae101e80d0599fb22f3f674758da2282666f06c80745"),
)
CARRY_POST_CB_SJTL_BASE_RAW_PACKAGES = {
    "A027_FULL_CB_CHAIN_ALL_CLOCK": (
        CARRY_POST_CB_SJTL_BASE_PACKAGES[2][1], CARRY_POST_CB_SJTL_BASE_PACKAGES[2][2],
        "939e6024928be84df809532ecd8b716b815a9b96ea498324fc5c30b712100e46"),
    "A028_FULL_CB_CHAIN_PAPER_CLOCK": (
        CARRY_POST_CB_SJTL_BASE_PACKAGES[3][1], CARRY_POST_CB_SJTL_BASE_PACKAGES[3][2],
        "59ba22b2c31bd04993989c16a7c37d1e5bb904c078ef9db979657de81e604701"),
    "A029_FULL_CB_CHAIN_3X3_CLOCK": (
        CARRY_POST_CB_SJTL_BASE_PACKAGES[4][1], CARRY_POST_CB_SJTL_BASE_PACKAGES[4][2],
        "d943765ab3e47c1607ab3c29ff08a1088f2444dfd8a3266e9670a1d75d24ac0f"),
}
CARRY_POST_CB_SJTL_RUN_IDS = (
    "A030_CARRY_POST_CB_SJTL_ALL_200", "A031_CARRY_POST_CB_SJTL_ALL_210",
    "A032_CARRY_POST_CB_SJTL_PAPER_210", "A033_CARRY_POST_CB_SJTL_3X3_210")
CARRY_POST_CB_SJTL_TASK = SERIES / "analysis" / "carry-post-cb-sjtl-20261010"
LEGACY_RUN_IDS = tuple(f"A{i:03d}_{case}" for i, case in enumerate(
    ("D3_N0", "D3_N1", "D3_N2", "D3_N3", "D3_N4", "PAPER_1101_1101"), start=1))
BASE_METADATA_NAME = f"{SERIES.name}_metadata_v2_BVM4X4_20261009.zip"
BASE_METADATA_QA = HANDOFF / f"{Path(BASE_METADATA_NAME).stem}_PACKAGE_QA.json"
BASE_METADATA_SHA256 = "19af77800333d2c596b25606c26ac84fbd0ae4101b5b14f83fefc121c5975be1"
BASE_METADATA_SOURCE_COMMIT = "364dd2b6dc0589f1ca1de614a16583a32331a51d"
BASE_RUN_PACKAGE_SHA256 = {
    "A001_D3_N0": "a720b89bfc318937c22e8c456cad80000b5aa47527d1470e4577b2413c851585",
    "A002_D3_N1": "8e3d18c8ca9d24c4c88a2cd7bb34826154a2556d8d4b034a81d3bdf78c7ee063",
    "A003_D3_N2": "a41e44a10b6021560a329047490b2b79b18a2f49d5d6bef145d81b46bba8a306",
    "A004_D3_N3": "b8af1acc2241e56c77374734336f49719f1e476717c5b1337592c1409bb874f9",
    "A005_D3_N4": "83e7d33b8ea44af3e80a7254596a93bf2b73ce51315add066a3f14a8dde1ec4d",
    "A006_PAPER_1101_1101": "c3cd4bd7477b3b5b43b78313a9392808d78da9949d3a8feb593ca72bfbf28c46",
}
BASE_RUN_RAW_SHA256 = {
    "A001_D3_N0": "af13bc5105c12919b7d93817d21ebd4a3f31123fb18f1e1d39b6a90958199c4d",
    "A002_D3_N1": "f977347a31d24a932262d2a87a145d344b96b56393bce99ebf592cf6dd7a2be2",
    "A003_D3_N2": "62301133c8faa92e078032270091920710ff361ba052450c4c006092308e9ec4",
    "A004_D3_N3": "79357f4a5401f11cae7fc5ec1ba496b81a30fec24c6d426982f42c6fcbb56908",
    "A005_D3_N4": "3b8cb325ed025ae83c3be83226284473357d5e7ec3a472dda6c75fcdd4050060",
    "A006_PAPER_1101_1101": "a318d8c09a958886ab1b3ec8ed636bf42c7b46b7fc9055353cff47ae0432b9cc",
}
DELTA_GLOBAL_PATHS = {
    "AGENTS.md", "CLAUDE.md", ".agents/skills/josim-experiment/SKILL.md",
    ".agents/skills/josim-experiment/agents/openai.yaml",
    "docs/EXPERIMENT_CONTRACT.md", "docs/research/EXPERIMENT_WORKFLOW_V1.md",
    "docs/research/COMPACT_WORKFLOW_V2.md", "memory/EXECUTOR_NOW.md",
    "memory/BVM_CURRENT_CONTEXT.md", "memory/LUNA_EXECUTOR_MEMORY.md",
    "memory/skill-usage.md", "scripts/README.md", "scripts/submit.py",
}


def load_root_submit() -> Any:
    spec = importlib.util.spec_from_file_location("josim_root_submit", ROOT_SUBMIT_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load repository submit helper: {ROOT_SUBMIT_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def git(*args: str, check: bool = True) -> str:
    return subprocess.run(["git", *args], cwd=REPO, text=True,
                          capture_output=True, check=check).stdout.strip()


def included_files(root: Path) -> list[Path]:
    files = []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(SERIES)
        if (not path.is_file() or path.is_symlink() or "handoff" in relative.parts
                or "__pycache__" in relative.parts or path.suffix.lower() in {".html", ".pyc", ".tmp"}):
            continue
        files.append(path)
    return files


def base_records(root: Any) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Verify prior package identities from QA sidecars without reopening old raw or ZIP members."""
    metadata = json.loads(BASE_METADATA_QA.read_text(encoding="utf-8"))
    metadata_path = HANDOFF / BASE_METADATA_NAME
    if (metadata.get("status") != "PASS" or metadata.get("package_sha256") != BASE_METADATA_SHA256 or
            metadata.get("source_commit") != BASE_METADATA_SOURCE_COMMIT or
            not metadata_path.is_file() or root.sha256(metadata_path) != BASE_METADATA_SHA256 or
            metadata.get("package_bytes") != metadata_path.stat().st_size):
        raise RuntimeError("bound metadata-v2 base identity/QA does not match the registered checkpoint")
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    recorded_raw = {item.get("run_id"): item.get("raw_sha256") for item in manifest.get("runs", [])}
    records = []
    for run_id in LEGACY_RUN_IDS:
        package_name = f"{SERIES.name}_raw_handoff_{run_id}_BVM4X4_20261009.zip"
        package = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        raw_sha = qa.get("raw_sha256_by_run", {}).get(run_id)
        expected_package_sha = BASE_RUN_PACKAGE_SHA256[run_id]
        expected_raw_sha = BASE_RUN_RAW_SHA256[run_id]
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_package_sha or
                qa.get("package_bytes") != package.stat().st_size or
                root.sha256(package) != expected_package_sha or raw_sha != expected_raw_sha or
                recorded_raw.get(run_id) != expected_raw_sha):
            raise RuntimeError(f"registered legacy package/raw identity mismatch: {run_id}")
        records.append({"run_id": run_id,
                        "raw_path": f"runs/{run_id}/raw.csv",
                        "raw_sha256": expected_raw_sha,
                        "source_package_name": package_name,
                        "source_package_sha256": expected_package_sha})
    return metadata, records


def _excluded_delta_path(path: Path) -> bool:
    parts = path.parts
    return ("handoff" in parts or "plots" in parts or "__pycache__" in parts or
            path.suffix.lower() in {".html", ".pyc", ".tmp"})


def is_allowed_delta_run_path(rel_path: str) -> bool:
    parts = Path(rel_path).parts
    if len(parts) < 6 or parts[:4] != ("test", "exploration", SERIES.name, "runs"):
        return False
    run_id = parts[4]
    if run_id in DELTA_RUN_IDS:
        return True
    return False


def verify_prior_bus400_delta(root: Any, legacy_refs: list[dict[str, Any]]) -> tuple[
        dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    package = HANDOFF / BUS400_DELTA_NAME
    qa_path = HANDOFF / f"{Path(BUS400_DELTA_NAME).stem}_PACKAGE_QA.json"
    qa = root.verify_existing_bundle(package, qa_path)
    if (qa.get("status") != "PASS" or qa.get("package_sha256") != BUS400_DELTA_SHA256 or
            qa.get("source_commit") != BUS400_DELTA_HEAD or
            qa.get("base_package_name") != BASE_METADATA_NAME or
            qa.get("base_package_sha256") != BASE_METADATA_SHA256):
        raise RuntimeError("registered A007/A008 delta package identity or QA mismatch")
    with zipfile.ZipFile(package, "r") as archive:
        prior_manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
    if (prior_manifest.get("head_commit") != BUS400_DELTA_HEAD or
            prior_manifest.get("base_package_name") != BASE_METADATA_NAME or
            prior_manifest.get("base_package_sha256") != BASE_METADATA_SHA256):
        raise RuntimeError("registered A007/A008 delta manifest lineage mismatch")
    manifest_raw = prior_manifest.get("raw_sha256_by_run", {})
    if set(manifest_raw) != set(BUS400_RUN_IDS):
        raise RuntimeError("registered A007/A008 delta raw closure is incomplete")
    manifest_rows = {item.get("run_id"): item for item in
                     json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8")).get("runs", [])}
    added_refs = []
    for run_id in BUS400_RUN_IDS:
        result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
        raw = RUNS / run_id / "raw.csv"
        if (manifest_raw.get(run_id) != result.get("raw_sha256") or
                not manifest_rows.get(run_id) or
                manifest_rows[run_id].get("raw_sha256") != result.get("raw_sha256") or
                root.sha256(raw) != result.get("raw_sha256")):
            raise RuntimeError(f"A007/A008 raw identity no longer matches its delta base: {run_id}")
        added_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                           "raw_sha256": result["raw_sha256"],
                           "source_package_name": BUS400_DELTA_NAME,
                           "source_package_sha256": BUS400_DELTA_SHA256})
    return qa, prior_manifest, legacy_refs + added_refs


def verify_prior_a009_delta(root: Any, prior_refs: list[dict[str, Any]]) -> tuple[
        dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    expected_prior_refs = list(prior_refs)
    package = HANDOFF / A009_DELTA_NAME
    qa_path = HANDOFF / f"{Path(A009_DELTA_NAME).stem}_PACKAGE_QA.json"
    qa = root.verify_existing_bundle(package, qa_path)
    if (qa.get("status") != "PASS" or qa.get("package_sha256") != A009_DELTA_SHA256 or
            qa.get("source_commit") != A009_DELTA_HEAD or
            qa.get("base_package_name") != BUS400_DELTA_NAME or
            qa.get("base_package_sha256") != BUS400_DELTA_SHA256):
        raise RuntimeError("registered A009 delta package identity or QA mismatch")
    with zipfile.ZipFile(package, "r") as archive:
        prior_manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
    if (prior_manifest.get("head_commit") != A009_DELTA_HEAD or
            prior_manifest.get("base_package_name") != BUS400_DELTA_NAME or
            prior_manifest.get("base_package_sha256") != BUS400_DELTA_SHA256):
        raise RuntimeError("registered A009 delta manifest lineage mismatch")
    recorded_prior_refs = prior_manifest.get("referenced_existing_raw_sha256", [])
    prior_identities = {(item.get("run_id"), item.get("raw_sha256"), item.get("source_package_name"),
                         item.get("source_package_sha256")) for item in recorded_prior_refs}
    expected_identities = {(item["run_id"], item["raw_sha256"], item["source_package_name"],
                            item["source_package_sha256"]) for item in expected_prior_refs}
    if len(prior_identities) != len(recorded_prior_refs) or prior_identities != expected_identities:
        raise RuntimeError("registered A009 delta existing-raw references are malformed")
    raw_map = prior_manifest.get("raw_sha256_by_run", {})
    if set(raw_map) != set(A009_RUN_IDS):
        raise RuntimeError("registered A009 delta raw closure is incomplete")
    manifest_rows = {item.get("run_id"): item for item in
                     json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8")).get("runs", [])}
    added_refs = []
    for run_id in A009_RUN_IDS:
        result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
        raw = RUNS / run_id / "raw.csv"
        if (raw_map.get(run_id) != result.get("raw_sha256") or
                not manifest_rows.get(run_id) or
                manifest_rows[run_id].get("raw_sha256") != result.get("raw_sha256") or
                root.sha256(raw) != result.get("raw_sha256")):
            raise RuntimeError(f"A009 raw identity no longer matches its delta base: {run_id}")
        added_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                           "raw_sha256": result["raw_sha256"],
                           "source_package_name": A009_DELTA_NAME,
                           "source_package_sha256": A009_DELTA_SHA256})
    return qa, prior_manifest, recorded_prior_refs + added_refs


def verify_prior_a010_a012_checkpoint(root: Any, prior_refs: list[dict[str, Any]]) -> tuple[
        list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    """Verify the complete source + A010/A011/A012 checkpoint without repackaging its raw."""
    expected_prior = {(item["run_id"], item["raw_sha256"], item["source_package_name"],
                       item["source_package_sha256"]) for item in prior_refs}
    manifest_rows = {item.get("run_id"): item for item in
                     json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8")).get("runs", [])}
    package_items = [("source", A010_A012_SOURCE_NAME, A010_A012_SOURCE_SHA256)]
    for run_id, (package_sha, _raw_sha) in A010_A012_RUN_PACKAGES.items():
        package_items.append((run_id, f"{SERIES.name}_delta_{A010_A012_TAG}_{run_id}.zip", package_sha))

    package_set = []
    combined_hashes: dict[str, str] = {}
    prior_run_refs: list[dict[str, Any]] = []
    for group, package_name, expected_package_sha in package_items:
        package = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_package_sha or
                qa.get("source_commit") != A010_A012_SOURCE_HEAD or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"A010-A012 checkpoint package identity/QA mismatch: {package_name}")
        with zipfile.ZipFile(package, "r") as archive:
            manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
        if (manifest.get("head_commit") != A010_A012_SOURCE_HEAD or
                manifest.get("base_commit") != A009_DELTA_HEAD or
                manifest.get("base_package_name") != A009_DELTA_NAME or
                manifest.get("base_package_sha256") != A009_DELTA_SHA256 or
                manifest.get("package_group") != group):
            raise RuntimeError(f"A010-A012 checkpoint manifest lineage mismatch: {package_name}")
        included = manifest.get("included_files", [])
        member_hashes = manifest.get("included_file_sha256", {})
        if {item.get("archive_path"): item.get("sha256") for item in included} != member_hashes:
            raise RuntimeError(f"A010-A012 checkpoint member/hash closure mismatch: {package_name}")
        for member, digest in member_hashes.items():
            previous = combined_hashes.setdefault(member, digest)
            if previous != digest:
                raise RuntimeError(f"A010-A012 checkpoint has conflicting member hashes: {member}")
        recorded_refs = manifest.get("referenced_existing_raw_sha256", [])
        identities = {(item.get("run_id"), item.get("raw_sha256"), item.get("source_package_name"),
                       item.get("source_package_sha256")) for item in recorded_refs}
        if identities != expected_prior or len(identities) != len(recorded_refs):
            raise RuntimeError(f"A010-A012 checkpoint existing-raw references mismatch: {package_name}")

        if group in A010_A012_RUN_PACKAGES:
            expected_raw_sha = A010_A012_RUN_PACKAGES[group][1]
            raw_map = manifest.get("raw_sha256_by_run", {})
            result = json.loads((RUNS / group / "result.json").read_text(encoding="utf-8"))
            raw = RUNS / group / "raw.csv"
            row = manifest_rows.get(group)
            qa_raw = qa.get("raw_sha256_by_run", {}).get(group)
            if (set(raw_map) != {group} or raw_map.get(group) != expected_raw_sha or
                    result.get("raw_sha256") != expected_raw_sha or qa_raw != expected_raw_sha or
                    not row or row.get("raw_sha256") != expected_raw_sha or
                    root.sha256(raw) != expected_raw_sha):
                raise RuntimeError(f"A010-A012 raw/package identity mismatch: {group}")
            prior_run_refs.append({"run_id": group, "raw_path": f"runs/{group}/raw.csv",
                                   "raw_sha256": expected_raw_sha,
                                   "source_package_name": package_name,
                                   "source_package_sha256": expected_package_sha})
        elif manifest.get("raw_sha256_by_run") != {}:
            raise RuntimeError("A010-A012 source checkpoint unexpectedly includes a run raw")
        package_set.append({"package_name": package_name, "package_sha256": expected_package_sha,
                            "source_commit": A010_A012_SOURCE_HEAD, "package_group": group})

    if {item["run_id"] for item in prior_run_refs} != set(A010_A012_RUN_IDS):
        raise RuntimeError("A010-A012 raw reference closure is incomplete")
    return package_set, prior_refs + prior_run_refs, combined_hashes


def verify_prior_t1_a013_a016_checkpoint(root: Any,
                                         prior_packages: list[dict[str, Any]],
                                         prior_refs: list[dict[str, Any]],
                                         prior_hashes: dict[str, str]) -> tuple[
        list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    """Verify the five-package A013-A016 checkpoint and extend exact raw/member closure."""
    expected_prior = {(item["run_id"], item["raw_sha256"], item["source_package_name"],
                       item["source_package_sha256"]) for item in prior_refs}
    manifest_rows = {item.get("run_id"): item for item in
                     json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8")).get("runs", [])}
    package_items = [("source", T1_A013_A016_SOURCE_NAME, T1_A013_A016_SOURCE_SHA256)]
    for run_id, (package_sha, _raw_sha) in T1_A013_A016_RUN_PACKAGES.items():
        package_items.append((run_id, f"{SERIES.name}_delta_{T1_A013_A016_TAG}_{run_id}.zip", package_sha))

    checkpoint_packages = []
    checkpoint_hashes: dict[str, str] = {}
    added_raw_refs = []
    for group, package_name, expected_package_sha in package_items:
        package = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_package_sha or
                qa.get("source_commit") != T1_A013_A016_SOURCE_HEAD or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"A013-A016 checkpoint package identity/QA mismatch: {package_name}")
        with zipfile.ZipFile(package, "r") as archive:
            manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
        if (manifest.get("head_commit") != T1_A013_A016_SOURCE_HEAD or
                manifest.get("base_commit") != "c42ad75d39cf796cfe863b836f6f8154388a048a" or
                manifest.get("base_package_name") != A010_A012_SOURCE_NAME or
                manifest.get("base_package_sha256") != A010_A012_SOURCE_SHA256 or
                manifest.get("package_group") != group or
                manifest.get("base_delta_packages") != prior_packages):
            raise RuntimeError(f"A013-A016 checkpoint lineage mismatch: {package_name}")

        included = manifest.get("included_files", [])
        member_hashes = manifest.get("included_file_sha256", {})
        if {item.get("archive_path"): item.get("sha256") for item in included} != member_hashes:
            raise RuntimeError(f"A013-A016 checkpoint member/hash closure mismatch: {package_name}")
        for member, digest in member_hashes.items():
            previous = checkpoint_hashes.setdefault(member, digest)
            if previous != digest:
                raise RuntimeError(f"A013-A016 checkpoint has conflicting member hashes: {member}")

        recorded_refs = manifest.get("referenced_existing_raw_sha256", [])
        identities = {(item.get("run_id"), item.get("raw_sha256"), item.get("source_package_name"),
                       item.get("source_package_sha256")) for item in recorded_refs}
        if identities != expected_prior or len(identities) != len(recorded_refs):
            raise RuntimeError(f"A013-A016 checkpoint existing-raw references mismatch: {package_name}")
        if manifest.get("base_run_packages") != prior_refs:
            raise RuntimeError(f"A013-A016 checkpoint base-run package references mismatch: {package_name}")

        if group in T1_A013_A016_RUN_PACKAGES:
            expected_raw_sha = T1_A013_A016_RUN_PACKAGES[group][1]
            raw_map = manifest.get("raw_sha256_by_run", {})
            result = json.loads((RUNS / group / "result.json").read_text(encoding="utf-8"))
            raw = RUNS / group / "raw.csv"
            row = manifest_rows.get(group)
            qa_raw = qa.get("raw_sha256_by_run", {}).get(group)
            raw_member = f"test/exploration/{SERIES.name}/runs/{group}/raw.csv"
            if (set(raw_map) != {group} or raw_map.get(group) != expected_raw_sha or
                    result.get("raw_sha256") != expected_raw_sha or qa_raw != expected_raw_sha or
                    not row or row.get("raw_sha256") != expected_raw_sha or
                    member_hashes.get(raw_member) != expected_raw_sha or
                    root.sha256(raw) != expected_raw_sha):
                raise RuntimeError(f"A013-A016 raw/package identity mismatch: {group}")
            added_raw_refs.append({"run_id": group, "raw_path": f"runs/{group}/raw.csv",
                                   "raw_sha256": expected_raw_sha,
                                   "source_package_name": package_name,
                                   "source_package_sha256": expected_package_sha})
        elif manifest.get("raw_sha256_by_run") != {}:
            raise RuntimeError("A013-A016 source checkpoint unexpectedly includes a run raw")

        checkpoint_packages.append({"package_name": package_name, "package_sha256": expected_package_sha,
                                    "source_commit": T1_A013_A016_SOURCE_HEAD, "package_group": group})

    if {item["run_id"] for item in added_raw_refs} != set(T1_A013_A016_RUN_IDS):
        raise RuntimeError("A013-A016 raw reference closure is incomplete")
    combined_hashes = {**prior_hashes, **checkpoint_hashes}
    return checkpoint_packages, prior_refs + added_raw_refs, combined_hashes


def verify_t1_a017_a019_checkpoint(root: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    """Verify the latest immutable A017-A019 source/raw checkpoint and exact raw lineage."""
    metadata, legacy_refs = base_records(root)
    _bus400_qa, _bus400_manifest, bus400_refs = verify_prior_bus400_delta(root, legacy_refs)
    _a009_qa, _a009_manifest, a009_refs = verify_prior_a009_delta(root, bus400_refs)
    a010_packages, a012_refs, a012_hashes = verify_prior_a010_a012_checkpoint(root, a009_refs)
    a013_packages, a013_refs, prior_hashes = verify_prior_t1_a013_a016_checkpoint(
        root, a010_packages, a012_refs, a012_hashes)
    source_path = HANDOFF / T1_CHAIN_BASE_SOURCE_NAME
    source_qa_path = HANDOFF / f"{Path(T1_CHAIN_BASE_SOURCE_NAME).stem}_PACKAGE_QA.json"
    source_qa = root.verify_existing_bundle(source_path, source_qa_path)
    if (source_qa.get("status") != "PASS" or
            source_qa.get("package_sha256") != T1_CHAIN_BASE_SOURCE_SHA256 or
            source_qa.get("source_commit") != T1_CHAIN_BASE_SOURCE_HEAD or
            source_qa.get("package_bytes") != source_path.stat().st_size):
        raise RuntimeError("A017-A019 source checkpoint ZIP/QA identity mismatch")
    with zipfile.ZipFile(source_path, "r") as archive:
        source_manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
    if (source_manifest.get("head_commit") != T1_CHAIN_BASE_SOURCE_HEAD or
            source_manifest.get("base_package_name") != T1_A013_A016_SOURCE_NAME or
            source_manifest.get("base_package_sha256") != T1_A013_A016_SOURCE_SHA256 or
            source_manifest.get("package_group") != "source" or
            source_manifest.get("raw_sha256_by_run") != {}):
        raise RuntimeError("A017-A019 source checkpoint lineage mismatch")
    member_hashes = source_manifest.get("included_file_sha256", {})
    if {item.get("archive_path"): item.get("sha256")
            for item in source_manifest.get("included_files", [])} != member_hashes:
        raise RuntimeError("A017-A019 source checkpoint member/hash map mismatch")
    prior_refs = source_manifest.get("referenced_existing_raw_sha256", [])
    if {(item.get("run_id"), item.get("raw_sha256"), item.get("source_package_name"),
         item.get("source_package_sha256")) for item in prior_refs} != {
            (item["run_id"], item["raw_sha256"], item["source_package_name"], item["source_package_sha256"])
            for item in a013_refs} or len(prior_refs) != len(a013_refs):
        raise RuntimeError("A017-A019 checkpoint historical raw-reference closure mismatch")
    checkpoint_hashes = dict(prior_hashes)
    # The latest checkpoint legitimately replaces member identities that its
    # own manifest marks modified relative to A013-A016.
    checkpoint_hashes.update(member_hashes)

    manifest_rows = {item.get("run_id"): item for item in
                     json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8")).get("runs", [])}
    added_refs = []
    packages = list(source_manifest.get("base_delta_packages", []))
    packages.append({"package_name": T1_CHAIN_BASE_SOURCE_NAME,
                     "package_sha256": T1_CHAIN_BASE_SOURCE_SHA256,
                     "source_commit": T1_CHAIN_BASE_SOURCE_HEAD, "package_group": "source"})
    for run_id, (expected_package_sha, expected_raw_sha, expected_artifact) in T1_CHAIN_BASE_RUN_PACKAGES.items():
        package_name = f"{SERIES.name}_delta_T1_A017_A019_20261009_{run_id}.zip"
        package = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_package_sha or
                qa.get("source_commit") != T1_CHAIN_BASE_SOURCE_HEAD or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"A017-A019 run package identity/QA mismatch: {run_id}")
        with zipfile.ZipFile(package, "r") as archive:
            manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
        if (manifest.get("head_commit") != T1_CHAIN_BASE_SOURCE_HEAD or
                manifest.get("package_group") != run_id or
                manifest.get("base_package_name") != T1_A013_A016_SOURCE_NAME or
                manifest.get("base_package_sha256") != T1_A013_A016_SOURCE_SHA256):
            raise RuntimeError(f"A017-A019 run package lineage mismatch: {run_id}")
        raw_map = manifest.get("raw_sha256_by_run", {})
        result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
        raw = RUNS / run_id / "raw.csv"
        row = manifest_rows.get(run_id)
        raw_member = f"test/exploration/{SERIES.name}/runs/{run_id}/raw.csv"
        qa_raw = qa.get("raw_sha256_by_run", {}).get(run_id)
        if (set(raw_map) != {run_id} or raw_map.get(run_id) != expected_raw_sha or
                result.get("raw_sha256") != expected_raw_sha or qa_raw != expected_raw_sha or
                not row or row.get("raw_sha256") != expected_raw_sha or
                manifest.get("included_file_sha256", {}).get(raw_member) != expected_raw_sha or
                root.sha256(raw) != expected_raw_sha or result.get("artifact_status") != expected_artifact):
            raise RuntimeError(f"A017-A019 raw identity/status mismatch: {run_id}")
        added_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                           "raw_sha256": expected_raw_sha,
                           "source_package_name": package_name,
                           "source_package_sha256": expected_package_sha})
        packages.append({"package_name": package_name, "package_sha256": expected_package_sha,
                         "source_commit": T1_CHAIN_BASE_SOURCE_HEAD, "package_group": run_id})
        for member, digest in manifest.get("included_file_sha256", {}).items():
            if member in checkpoint_hashes and checkpoint_hashes[member] != digest:
                raise RuntimeError(f"A017-A019 checkpoint has conflicting member hash: {member}")
            checkpoint_hashes[member] = digest
    expected_runs = set(LEGACY_RUN_IDS + BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS +
                        T1_A013_A016_RUN_IDS + T1_CHAIN_BASE_RUN_IDS)
    if {item["run_id"] for item in prior_refs + added_refs} != expected_runs:
        raise RuntimeError("A017-A019 checkpoint raw closure is not exactly A001-A019")
    return packages, prior_refs + added_refs, checkpoint_hashes


def partition_delta_sources(sources: list[tuple[Path, str]]) -> tuple[
        dict[str, list[tuple[Path, str]]], list[tuple[Path, str]]]:
    by_run = {run_id: [] for run_id in DELTA_RUN_IDS}
    shared = []
    for item in sources:
        parts = Path(item[1]).parts
        if len(parts) >= 5 and parts[:4] == ("test", "exploration", SERIES.name, "runs") and parts[4] in by_run:
            by_run[parts[4]].append(item)
        else:
            shared.append(item)
    members = [member for _source, member in shared]
    members.extend(member for group in by_run.values() for _source, member in group)
    if len(members) != len(sources) or len(members) != len(set(members)):
        raise RuntimeError("delta source partition is incomplete or contains duplicate members")
    missing = [run_id for run_id, group in by_run.items()
               if not any(Path(member).name == "raw.csv" for _source, member in group)]
    if missing:
        raise RuntimeError(f"delta partition is missing run raw files: {missing}")
    if not shared:
        raise RuntimeError("delta has no shared source/config/manifest files")
    return by_run, shared


def _delta_sources(root: Any) -> tuple[list[tuple[Path, str]], list[str], list[str]]:
    changes = dict(root.committed_changes(DELTA_BASE_COMMIT, git("rev-parse", "HEAD")))
    changes.update(root.working_changes())
    for path in root.untracked_files():
        changes.setdefault(path, "??")
    sources: dict[str, Path] = {}
    excluded_html: set[str] = set()
    changed_paths: set[str] = set()
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if not (root.in_scope(rel_path, [SERIES]) or rel_path in DELTA_GLOBAL_PATHS):
            continue
        if status == "D":
            raise RuntimeError(f"delta submission refuses file deletion: {rel_path}")
        if path.parts[:2] == ("test", "exploration") and path.parts[2:3] == (SERIES.name,):
            if len(path.parts) >= 4 and path.parts[3] == "runs":
                if not is_allowed_delta_run_path(rel_path):
                    raise RuntimeError(f"delta submission detected a historical run edit: {rel_path}")
        if _excluded_delta_path(path):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        source = REPO / path
        if source.is_file() and not source.is_symlink():
            sources[rel_path] = source
            changed_paths.add(rel_path)

    # Run evidence may be ignored by Git until the submission explicitly stages it.
    for run_id in DELTA_RUN_IDS:
        run_dir = RUNS / run_id
        if not run_dir.is_dir():
            raise RuntimeError(f"new authorized run directory is missing: {run_id}")
        for path in included_files(run_dir):
            rel_path = path.relative_to(REPO).as_posix()
            sources[rel_path] = path
            changed_paths.add(rel_path)

    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())

    # The repository globally ignores JSON outputs, so explicitly inventory the
    # new task's preregistration, static QA, batch closure and derived summary.
    task_analysis = SERIES / "analysis" / "t1-array-20261009"
    for path in sorted(task_analysis.rglob("*")):
        if not path.is_file() or _excluded_delta_path(path.relative_to(REPO)):
            continue
        rel_path = path.relative_to(REPO).as_posix()
        sources[rel_path] = path
        changed_paths.add(rel_path)

    required_valid_run_files = {"deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt",
                                "USER_CASE.snapshot.env", "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env",
                                "stimulus.inc", "case_manifest.json", "metadata.json", "provenance.json",
                                "source_manifest.json", "topology_manifest.json", "probe_manifest.json",
                                "static_qa.json", "stimulus_manifest.json", "metrics.json", "raw_qa.json",
                                "qa.json", "t1_array_qa.json", "plot_manifest.json", "plot_qa.json",
                                "result.json", "RESULT_BRIEF.md"}
    required_invalid_run_files = {"deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt",
                                  "USER_CASE.snapshot.env", "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env",
                                  "stimulus.inc", "case_manifest.json", "source_manifest.json",
                                  "topology_manifest.json", "probe_manifest.json", "static_qa.json",
                                  "stimulus_manifest.json", "result.json"}
    for run_id in DELTA_RUN_IDS:
        run_prefix = ("test", "exploration", SERIES.name, "runs", run_id)
        run_members = {item for item in sources if Path(item).parts[:5] == run_prefix}
        have = {Path(item).name for item in run_members}
        required = (required_invalid_run_files if run_id in INVALID_PRESERVED_DELTA_RUN_IDS
                    else required_valid_run_files)
        missing = required - have
        if (run_id in INVALID_PRESERVED_DELTA_RUN_IDS and
                f"test/exploration/{SERIES.name}/runs/{run_id}/sources/t1_cell_tunable.cir" not in run_members):
            missing.add("sources/t1_cell_tunable.cir")
        if missing:
            raise RuntimeError(f"{run_id} delta evidence is incomplete: {sorted(missing)}")

    # Every existing, non-HTML change from the registered Git base must appear.
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if status == "D" or _excluded_delta_path(path):
            continue
        if root.in_scope(rel_path, [SERIES]) or rel_path in DELTA_GLOBAL_PATHS:
            if path.parts[:2] == ("test", "exploration") and path.parts[2:3] == (SERIES.name,):
                if len(path.parts) >= 4 and path.parts[3] == "runs":
                    continue
            if (REPO / path).is_file() and rel_path not in sources:
                raise RuntimeError(f"changed evidence/source omitted from delta inventory: {rel_path}")
    ordered = [(sources[key], key) for key in sorted(sources)]
    return ordered, sorted(changed_paths), sorted(excluded_html)


def _t1_chain_delta_sources(root: Any) -> tuple[list[tuple[Path, str]], dict[str, str], list[str]]:
    head = git("rev-parse", "HEAD")
    changes = dict(root.committed_changes(T1_CHAIN_BASE_COMMIT, head))
    changes.update(root.working_changes())
    for path in root.untracked_files():
        changes.setdefault(path, "??")
    sources: dict[str, Path] = {}
    excluded_html: set[str] = set()
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if not root.in_scope(rel_path, [SERIES]):
            raise RuntimeError(f"chain delta found a changed path outside this series: {rel_path}")
        if status == "D":
            raise RuntimeError(f"chain delta refuses deletions: {rel_path}")
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            if len(path.parts) < 5 or path.parts[4] not in T1_CHAIN_DELTA_RUN_IDS:
                raise RuntimeError(f"chain delta detected an edit to historical run evidence: {rel_path}")
            continue
        if _excluded_delta_path(path):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        source = REPO / path
        if source.is_file() and not source.is_symlink():
            sources[rel_path] = source

    # New run trees and ignored task-analysis JSON are explicitly inventoried.
    for run_id in T1_CHAIN_DELTA_RUN_IDS:
        run_dir = RUNS / run_id
        if not run_dir.is_dir():
            raise RuntimeError(f"chain delta run directory is missing: {run_id}")
        for path in included_files(run_dir):
            sources[path.relative_to(REPO).as_posix()] = path
    task_analysis = SERIES / "analysis" / "t1-chain-20261009"
    if not task_analysis.is_dir():
        raise RuntimeError("chain work-unit analysis directory is missing")
    for path in sorted(task_analysis.rglob("*")):
        if path.is_file() and not _excluded_delta_path(path.relative_to(REPO)):
            sources[path.relative_to(REPO).as_posix()] = path

    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())

    # Every in-scope changed, non-HTML file must be represented in the source or
    # one of the new run groups; no recent-edit-only packaging is permitted.
    members = set(sources)
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if status == "D" or _excluded_delta_path(path):
            continue
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            continue
        if root.in_scope(rel_path, [SERIES]) and (REPO / path).is_file() and rel_path not in members:
            raise RuntimeError(f"changed source/evidence omitted from chain delta: {rel_path}")
    return [(sources[key], key) for key in sorted(sources)], changes, sorted(excluded_html)


def verify_cb_direct_d1_base_checkpoint(root: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    """Verify the committed A020-A022 five-package checkpoint and close A001-A022 raw references."""
    prior_packages, prior_refs, member_hashes = verify_t1_a017_a019_checkpoint(root)
    expected_prior_ids = {item["run_id"] for item in prior_refs}
    if len(prior_refs) != 19 or expected_prior_ids != {
            *LEGACY_RUN_IDS, *BUS400_RUN_IDS, *A009_RUN_IDS, *A010_A012_RUN_IDS,
            *T1_A013_A016_RUN_IDS, *T1_CHAIN_BASE_RUN_IDS}:
        raise RuntimeError("A017-A019 checkpoint did not close exactly A001-A019")

    experiment = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    manifest_rows = {row.get("run_id"): row for row in experiment.get("runs", [])}
    base_run_refs = list(prior_refs)
    package_records = list(prior_packages)
    a020_refs = []
    raw_by_run = {run_id: raw_sha for run_id, (_package_sha, raw_sha) in
                  CB_DIRECT_D1_BASE_RUN_PACKAGES.items()}
    for group, package_name, expected_package_sha in CB_DIRECT_D1_BASE_PACKAGE_GROUPS:
        package_path = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package_path, qa_path)
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_package_sha or
                qa.get("source_commit") != CB_DIRECT_D1_BASE_COMMIT or
                qa.get("package_bytes") != package_path.stat().st_size):
            raise RuntimeError(f"A020-A022 checkpoint package identity/QA mismatch: {package_name}")
        with zipfile.ZipFile(package_path) as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError(f"A020-A022 checkpoint ZIP CRC failure: {package_name}/{bad}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            members = set(archive.namelist())
            included = delta.get("included_files", [])
            hashes = delta.get("included_file_sha256", {})
            if {item.get("archive_path"): item.get("sha256") for item in included} != hashes:
                raise RuntimeError(f"A020-A022 checkpoint file/hash manifest mismatch: {package_name}")
            for member, digest in hashes.items():
                if member not in members or hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"A020-A022 checkpoint member hash mismatch: {package_name}/{member}")
        if (delta.get("head_commit") != CB_DIRECT_D1_BASE_COMMIT or
                delta.get("base_commit") != T1_CHAIN_BASE_COMMIT or
                delta.get("base_package_name") != T1_CHAIN_BASE_SOURCE_NAME or
                delta.get("base_package_sha256") != T1_CHAIN_BASE_SOURCE_SHA256 or
                delta.get("package_group") != group):
            raise RuntimeError(f"A020-A022 checkpoint lineage mismatch: {package_name}")
        refs = delta.get("referenced_existing_raw_sha256", [])
        if {(item.get("run_id"), item.get("raw_sha256"), item.get("source_package_name"),
             item.get("source_package_sha256")) for item in refs} != {
                (item["run_id"], item["raw_sha256"], item["source_package_name"], item["source_package_sha256"])
                for item in prior_refs} or len(refs) != len(prior_refs):
            raise RuntimeError(f"A020-A022 checkpoint A001-A019 raw closure mismatch: {package_name}")

        for member, digest in hashes.items():
            member_hashes[member] = digest

        expected_runs = set(T1_CHAIN_DELTA_RUN_IDS)
        if group == "source":
            if delta.get("raw_sha256_by_run") != {}:
                raise RuntimeError("A020-A022 source checkpoint unexpectedly contains a raw")
        elif group == "runs_metadata":
            if (delta.get("raw_sha256_by_run") != {} or
                    delta.get("associated_raw_sha256_by_run") != raw_by_run or
                    set(delta.get("associated_raw_sha256_by_run", {})) != expected_runs):
                raise RuntimeError("A020-A022 metadata checkpoint raw association is incomplete")
        else:
            run_id = group.removesuffix("_raw")
            expected_raw_sha = raw_by_run[run_id]
            member = f"test/exploration/{SERIES.name}/runs/{run_id}/raw.csv"
            result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
            raw = RUNS / run_id / "raw.csv"
            qa_raw = qa.get("raw_sha256_by_run", {}).get(run_id)
            if (delta.get("raw_sha256_by_run") != {run_id: expected_raw_sha} or
                    hashes.get(member) != expected_raw_sha or qa_raw != expected_raw_sha or
                    root.sha256(raw) != expected_raw_sha or result.get("raw_sha256") != expected_raw_sha):
                raise RuntimeError(f"A020-A022 raw/package identity mismatch: {run_id}")
            row = manifest_rows.get(run_id)
            if not row or row.get("raw_sha256") != expected_raw_sha:
                raise RuntimeError(f"A020-A022 experiment manifest raw SHA mismatch: {run_id}")
            a020_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                              "raw_sha256": expected_raw_sha, "source_package_name": package_name,
                              "source_package_sha256": expected_package_sha})
        package_records.append({"package_name": package_name, "package_sha256": expected_package_sha,
                                "source_commit": CB_DIRECT_D1_BASE_COMMIT, "package_group": group})
    if {item["run_id"] for item in a020_refs} != expected_runs:
        raise RuntimeError("A020-A022 checkpoint raw package closure is incomplete")
    existing_refs = base_run_refs + a020_refs
    expected_all = expected_prior_ids | set(T1_CHAIN_DELTA_RUN_IDS)
    if len(existing_refs) != 22 or {item["run_id"] for item in existing_refs} != expected_all:
        raise RuntimeError("verified base raw reference closure is not exactly A001-A022")
    return package_records, existing_refs, member_hashes


def _cb_direct_d1_delta_sources(root: Any) -> tuple[list[tuple[Path, str]], dict[str, str], list[str]]:
    head = git("rev-parse", "HEAD")
    changes = dict(root.committed_changes(CB_DIRECT_D1_BASE_COMMIT, head))
    changes.update(root.working_changes())
    for path in root.untracked_files():
        changes.setdefault(path, "??")
    sources: dict[str, Path] = {}
    excluded_html: set[str] = set()
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if not root.in_scope(rel_path, [SERIES]):
            raise RuntimeError(f"CB_DIRECT D1 DELTA found an out-of-scope change: {rel_path}")
        if status == "D":
            raise RuntimeError(f"CB_DIRECT D1 DELTA refuses deletions: {rel_path}")
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            if len(path.parts) < 5 or path.parts[4] not in CB_DIRECT_D1_RUN_IDS:
                raise RuntimeError(f"CB_DIRECT D1 DELTA detected historical run edit: {rel_path}")
            continue
        if _excluded_delta_path(path):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        source = REPO / path
        if source.is_file() and not source.is_symlink():
            sources[rel_path] = source

    for run_id in CB_DIRECT_D1_RUN_IDS:
        run_dir = RUNS / run_id
        if not run_dir.is_dir():
            raise RuntimeError(f"new authorized run directory is missing: {run_id}")
        for path in included_files(run_dir):
            sources[path.relative_to(REPO).as_posix()] = path

    task_analysis = SERIES / "analysis" / "cb-direct-d1-20261009"
    for path in sorted(task_analysis.rglob("*")):
        if not path.is_file() or _excluded_delta_path(path.relative_to(REPO)):
            continue
        sources[path.relative_to(REPO).as_posix()] = path

    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())

    for rel_path, status in changes.items():
        path = Path(rel_path)
        if status == "D" or _excluded_delta_path(path):
            continue
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            continue
        if root.in_scope(rel_path, [SERIES]) and (REPO / path).is_file() and rel_path not in sources:
            raise RuntimeError(f"changed source/evidence omitted from CB_DIRECT D1 DELTA: {rel_path}")
    return [(sources[key], key) for key in sorted(sources)], changes, sorted(excluded_html)


def validate_cb_direct_d1_scope(root: Any) -> dict[str, Any]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("CB_DIRECT D1 DELTA expects the existing master branch")
    if subprocess.run(["git", "merge-base", "--is-ancestor", CB_DIRECT_D1_BASE_COMMIT,
                       git("rev-parse", "HEAD")], cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("CB_DIRECT D1 HEAD is not descended from the A020-A022 source checkpoint")
    expected_run_dirs = list(LEGACY_RUN_IDS + BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS +
                             T1_A013_A016_RUN_IDS + T1_CHAIN_BASE_RUN_IDS + T1_CHAIN_DELTA_RUN_IDS +
                             CB_DIRECT_D1_RUN_IDS)
    actual_run_dirs = sorted(path.name for path in RUNS.iterdir()
                             if path.is_dir() and re.fullmatch(r"A\d{3}_.+", path.name))
    if actual_run_dirs != expected_run_dirs:
        raise RuntimeError(f"CB_DIRECT D1 run closure mismatch: expected {expected_run_dirs}, found {actual_run_dirs}")

    base_packages, existing_raw_refs, base_member_hashes = verify_cb_direct_d1_base_checkpoint(root)
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    manifest_rows = {item.get("run_id"): item for item in manifest.get("runs", [])}
    if int(manifest.get("physical_solve_count", -1)) != 24:
        raise RuntimeError(f"experiment_manifest physical_solve_count should be 24, got {manifest.get('physical_solve_count')}")
    auth = [item for item in manifest.get("authorization_batches", [])
            if item.get("batch_id") == "BVM4X4_CB_DIRECT_D1_20261009"]
    if (len(auth) != 1 or auth[0].get("authorized_physical_solve_count") != 2 or
            auth[0].get("physical_solve_count_completed") != 2 or
            auth[0].get("run_ids") != list(CB_DIRECT_D1_RUN_IDS) or
            auth[0].get("execution_preflight_attempt") != 2):
        raise RuntimeError("CB_DIRECT D1 authorization completion is not exactly A023/A024")

    task_root = SERIES / "analysis" / "cb-direct-d1-20261009"
    attempt = task_root / "attempts" / "002"
    batch = json.loads((attempt / "BATCH_MANIFEST.json").read_text(encoding="utf-8"))
    comparison = json.loads((task_root / "CB_DIRECT_D1_COMPARISON.json").read_text(encoding="utf-8"))
    comparison_qa = json.loads((task_root / "COMPARISON_PLOT_QA.json").read_text(encoding="utf-8"))
    if (batch.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            batch.get("authorized_run_ids") != list(CB_DIRECT_D1_RUN_IDS) or
            [item.get("run_id") for item in batch.get("runs", [])] != list(CB_DIRECT_D1_RUN_IDS) or
            batch.get("physical_solve_count_completed") != 2 or
            comparison.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            comparison.get("physical_solve_count") != 2 or comparison_qa.get("status") != "PASS"):
        raise RuntimeError("CB_DIRECT D1 batch, comparison, or plot QA is not mechanically closed")

    handoff = json.loads((task_root / "RAW_ANALYSIS_HANDOFF_MANIFEST.json").read_text(encoding="utf-8"))
    handoff_refs = handoff.get("existing_raw_references", [])
    expected_refs = {(item["run_id"], item["raw_sha256"], item["source_package_name"], item["source_package_sha256"])
                     for item in existing_raw_refs}
    actual_refs = {(item.get("run_id"), item.get("raw_sha256"), item.get("source_package_name"),
                    item.get("source_package_sha256")) for item in handoff_refs}
    if len(existing_raw_refs) != 22 or len(actual_refs) != len(handoff_refs) or actual_refs != expected_refs:
        raise RuntimeError("CB_DIRECT D1 raw handoff manifest does not bind exactly A001-A022")

    incident = json.loads((task_root / "GATE_INCIDENT_001.json").read_text(encoding="utf-8"))
    first_attempt = json.loads((task_root / "BATCH_MANIFEST.json").read_text(encoding="utf-8"))
    if (incident.get("physical_solve_count") != 0 or incident.get("transient_solver_invoked") is not False or
            first_attempt.get("status") != "STOPPED_BEFORE_PHYSICAL_SOLVE" or
            first_attempt.get("physical_solve_count_completed") != 0):
        raise RuntimeError("attempt-1 gate stop/zero-solve incident is not preserved")

    raw_sha_by_run, run_status = {}, {}
    for run_id in CB_DIRECT_D1_RUN_IDS:
        run_dir = RUNS / run_id
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "chain_qa.json").read_text(encoding="utf-8"))
        metrics = json.loads((run_dir / "metrics.json").read_text(encoding="utf-8"))
        provenance = json.loads((run_dir / "provenance.json").read_text(encoding="utf-8"))
        source = json.loads((run_dir / "source_manifest.json").read_text(encoding="utf-8"))
        topology = json.loads((run_dir / "topology_manifest.json").read_text(encoding="utf-8"))
        case = json.loads((run_dir / "case_manifest.json").read_text(encoding="utf-8")).get("case", {})
        plot = json.loads((run_dir / "plot_qa.json").read_text(encoding="utf-8"))
        raw = run_dir / "raw.csv"
        digest = root.sha256(raw)
        row = manifest_rows.get(run_id)
        expected_bits = ("1111", "1111") if run_id == CB_DIRECT_D1_RUN_IDS[0] else ("1101", "1101")
        if (result.get("run_id") != run_id or result.get("artifact_status") != "VALID" or
                result.get("physical_solve_count") != 1 or result.get("raw_sha256") != digest or
                qa.get("status") != "PASS" or qa.get("raw_sha256_before_analysis") != digest or
                qa.get("raw_sha256_after_analysis") != digest or raw_qa.get("status") != "PASS" or
                raw_qa.get("raw_sha256_after_analysis") != digest or metrics.get("raw_sha256") != digest or
                provenance.get("raw_sha256") != digest or plot.get("status") != "PASS" or
                plot.get("raw_sha256_after") != digest or not row or row.get("raw_sha256") != digest or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES or
                (result.get("row_bits"), result.get("column_bits")) != expected_bits):
            raise RuntimeError(f"A023/A024 run raw/provenance/mechanical identity failed: {run_id}")
        if (source.get("sources", {}).get("CBU_D1_DIRECT", {}).get("sha256") !=
                "70a6af05acccb7c354799d5b1b7542c86c677970681473f559bbf0f7e4d6d370" or
                topology.get("cbu_type_by_stage", {}).get("D1") != "CB" or
                topology.get("cbu_type_by_stage", {}).get("D2") != "THmitll_MERGE" or
                case.get("CBU_OVERRIDE_D1") != "CB_DIRECT"):
            raise RuntimeError(f"D1 direct CB source/topology provenance mismatch: {run_id}")
        for page in plot.get("pages", []):
            page_path = SERIES / page["path"]
            if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
                raise RuntimeError(f"A023/A024 standalone plot identity mismatch: {run_id}/{page.get('path')}")
        raw_sha_by_run[run_id] = digest
        run_status[run_id] = {"status": result.get("status"), "artifact_status": result.get("artifact_status"),
                              "physical_solve_count": result.get("physical_solve_count"),
                              "qa_status": qa.get("status"), "raw_bytes": raw.stat().st_size}
    for page in comparison_qa.get("pages", []):
        page_path = SERIES / page["path"]
        if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
            raise RuntimeError(f"paired comparison plot hash mismatch: {page.get('path')}")

    sources, changes, excluded_html = _cb_direct_d1_delta_sources(root)
    run_prefix = {run_id: ("test", "exploration", SERIES.name, "runs", run_id)
                  for run_id in CB_DIRECT_D1_RUN_IDS}
    run_files = {run_id: [(source, member) for source, member in sources
                          if Path(member).parts[:5] == run_prefix[run_id]]
                 for run_id in CB_DIRECT_D1_RUN_IDS}
    for run_id, files in run_files.items():
        if not files or not any(Path(member).name == "raw.csv" for _source, member in files):
            raise RuntimeError(f"CB_DIRECT D1 DELTA inventory is incomplete for {run_id}")
    shared = [(source, member) for source, member in sources
              if Path(member).parts[:4] != ("test", "exploration", SERIES.name, "runs")]
    if not shared:
        raise RuntimeError("CB_DIRECT D1 DELTA has no source or analysis evidence")
    return {"base_packages": base_packages, "existing_raw_refs": existing_raw_refs,
            "base_member_hashes": base_member_hashes, "raw_sha256_by_run": raw_sha_by_run,
            "run_artifact_status_by_run": run_status, "sources": sources,
            "run_files": run_files, "shared_sources": shared,
            "changes": changes, "excluded_html": excluded_html,
            "batch": batch, "comparison": comparison}


def validate_cb_direct_d1_scope(root: Any) -> dict[str, Any]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("CB_DIRECT D1 DELTA expects the existing master branch")
    if subprocess.run(["git", "merge-base", "--is-ancestor", CB_DIRECT_D1_BASE_COMMIT,
                       git("rev-parse", "HEAD")], cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("CB_DIRECT D1 HEAD is not descended from the A020-A022 package source commit")
    expected_run_dirs = list(LEGACY_RUN_IDS + BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS +
                             T1_A013_A016_RUN_IDS + T1_CHAIN_BASE_RUN_IDS + T1_CHAIN_DELTA_RUN_IDS +
                             CB_DIRECT_D1_RUN_IDS)
    actual_run_dirs = sorted(path.name for path in RUNS.iterdir()
                             if path.is_dir() and re.fullmatch(r"A\d{3}_.+", path.name))
    if actual_run_dirs != expected_run_dirs:
        raise RuntimeError(f"CB_DIRECT D1 run closure mismatch: expected {expected_run_dirs}, found {actual_run_dirs}")

    base_packages, existing_raw_refs, base_member_hashes = verify_cb_direct_d1_base_checkpoint(root)
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    run_rows = {item.get("run_id"): item for item in manifest.get("runs", [])}
    if int(manifest.get("physical_solve_count", -1)) != 24:
        raise RuntimeError(f"experiment manifest physical_solve_count should be 24, got {manifest.get('physical_solve_count')}")
    auth = [item for item in manifest.get("authorization_batches", [])
            if item.get("batch_id") == "BVM4X4_CB_DIRECT_D1_20261009"]
    if (len(auth) != 1 or auth[0].get("authorized_physical_solve_count") != 2 or
            auth[0].get("physical_solve_count_completed") != 2 or
            auth[0].get("run_ids") != list(CB_DIRECT_D1_RUN_IDS) or
            auth[0].get("execution_preflight_attempt") != 2):
        raise RuntimeError("CB_DIRECT D1 authorization completion record is not exactly A023/A024")

    attempt = SERIES / "analysis" / "cb-direct-d1-20261009" / "attempts" / "002"
    preflight_path = attempt / "PREFLIGHT.md"
    static_qa_path = attempt / "STATIC_QA.json"
    probes_path = attempt / "PROBE_MANIFEST.json"
    work_unit = json.loads((attempt / "WORK_UNIT.json").read_text(encoding="utf-8"))
    static_qa = json.loads(static_qa_path.read_text(encoding="utf-8"))
    batch = json.loads((attempt / "BATCH_MANIFEST.json").read_text(encoding="utf-8"))
    comparison = json.loads((SERIES / "analysis/cb-direct-d1-20261009/CB_DIRECT_D1_COMPARISON.json").read_text(encoding="utf-8"))
    plot_qa = json.loads((SERIES / "analysis/cb-direct-d1-20261009/COMPARISON_PLOT_QA.json").read_text(encoding="utf-8"))
    numerical_recheck_path = SERIES / "analysis/cb-direct-d1-20261009/NUMERICAL_RECHECK.json"
    numerical_recheck = json.loads(numerical_recheck_path.read_text(encoding="utf-8"))
    if (batch.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            batch.get("authorized_run_ids") != list(CB_DIRECT_D1_RUN_IDS) or
            [row.get("run_id") for row in batch.get("runs", [])] != list(CB_DIRECT_D1_RUN_IDS) or
            batch.get("physical_solve_count_completed") != 2 or
            static_qa.get("status") != "PASS" or static_qa.get("physical_solve_count") != 0 or
            work_unit.get("authorized_run_ids") != list(CB_DIRECT_D1_RUN_IDS) or
            work_unit.get("preflight_sha256") != root.sha256(preflight_path) or
            work_unit.get("static_qa_sha256") != root.sha256(static_qa_path) or
            work_unit.get("probe_manifest_sha256") != root.sha256(probes_path) or
            batch.get("preflight_sha256") != root.sha256(preflight_path) or
            batch.get("static_qa_sha256") != root.sha256(static_qa_path) or
            batch.get("probe_manifest_sha256") != root.sha256(probes_path) or
            comparison.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            comparison.get("physical_solve_count") != 2 or plot_qa.get("status") != "PASS" or
            numerical_recheck.get("status") != "PASS_RAW_RECOMPUTATION_MATCHES_METRICS" or
            numerical_recheck.get("physical_solve_count") != 0 or
            numerical_recheck.get("same_jj_window_checks") != 80 or
            batch.get("numerical_recheck_sha256") != root.sha256(numerical_recheck_path)):
        raise RuntimeError("CB_DIRECT D1 batch/comparison/plot QA is not mechanically closed")
    raw_handoff = json.loads((SERIES / "analysis/cb-direct-d1-20261009/RAW_ANALYSIS_HANDOFF_MANIFEST.json").read_text(encoding="utf-8"))
    handoff_refs = raw_handoff.get("existing_raw_references", [])
    expected_ref_ids = {item["run_id"] for item in existing_raw_refs}
    handoff_identities = {(item.get("run_id"), item.get("raw_sha256"), item.get("source_package_name"),
                           item.get("source_package_sha256")) for item in handoff_refs}
    expected_identities = {(item["run_id"], item["raw_sha256"], item["source_package_name"],
                            item["source_package_sha256"]) for item in existing_raw_refs}
    if (len(existing_raw_refs) != 22 or {item.get("run_id") for item in handoff_refs} != expected_ref_ids or
            len(handoff_identities) != len(handoff_refs) or handoff_identities != expected_identities):
        raise RuntimeError("raw handoff manifest does not reference exactly A001-A022")
    for incident_file in (SERIES / "analysis/cb-direct-d1-20261009/GATE_INCIDENT_001.json",
                          SERIES / "analysis/cb-direct-d1-20261009/BATCH_MANIFEST.json"):
        if not incident_file.is_file():
            raise RuntimeError("pre-solver gate incident history is not preserved")
    failed_gate = json.loads((SERIES / "analysis/cb-direct-d1-20261009/GATE_INCIDENT_001.json").read_text(encoding="utf-8"))
    first_batch = json.loads((SERIES / "analysis/cb-direct-d1-20261009/BATCH_MANIFEST.json").read_text(encoding="utf-8"))
    if (failed_gate.get("physical_solve_count") != 0 or failed_gate.get("transient_solver_invoked") is not False or
            first_batch.get("status") != "STOPPED_BEFORE_PHYSICAL_SOLVE" or
            first_batch.get("physical_solve_count_completed") != 0):
        raise RuntimeError("attempt-1 gate incident does not clearly record zero transient solves")

    raw_sha_by_run, run_status = {}, {}
    for run_id in CB_DIRECT_D1_RUN_IDS:
        run_dir = RUNS / run_id
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        chain_qa = json.loads((run_dir / "chain_qa.json").read_text(encoding="utf-8"))
        metrics = json.loads((run_dir / "metrics.json").read_text(encoding="utf-8"))
        provenance = json.loads((run_dir / "provenance.json").read_text(encoding="utf-8"))
        source = json.loads((run_dir / "source_manifest.json").read_text(encoding="utf-8"))
        topology = json.loads((run_dir / "topology_manifest.json").read_text(encoding="utf-8"))
        case_manifest = json.loads((run_dir / "case_manifest.json").read_text(encoding="utf-8"))
        case = case_manifest.get("case", {})
        probe = json.loads((run_dir / "probe_manifest.json").read_text(encoding="utf-8"))
        plot = json.loads((run_dir / "plot_qa.json").read_text(encoding="utf-8"))
        raw = run_dir / "raw.csv"
        digest = root.sha256(raw)
        row = run_rows.get(run_id)
        expected_bits = ("1111", "1111") if run_id == CB_DIRECT_D1_RUN_IDS[0] else ("1101", "1101")
        if (result.get("run_id") != run_id or result.get("artifact_status") != "VALID" or
                result.get("physical_solve_count") != 1 or result.get("raw_sha256") != digest or
                qa.get("status") != "PASS" or qa.get("raw_sha256_before_analysis") != digest or
                qa.get("raw_sha256_after_analysis") != digest or chain_qa.get("status") != "PASS" or
                chain_qa.get("raw_sha256_after_analysis") != digest or metrics.get("raw_sha256") != digest or
                provenance.get("raw_sha256") != digest or
                provenance.get("preflight_sha256") != root.sha256(preflight_path) or
                provenance.get("metric_spec_sha256") != root.sha256(SERIES / "analysis/cb-direct-d1-20261009/METRIC_SPEC.json") or
                plot.get("status") != "PASS" or
                plot.get("raw_sha256_after") != digest or not row or row.get("raw_sha256") != digest or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES or
                (result.get("row_bits"), result.get("column_bits")) != expected_bits):
            raise RuntimeError(f"A023/A024 run raw/provenance/mechanical identity failed: {run_id}")
        if (source.get("sources", {}).get("CBU_D1_DIRECT", {}).get("sha256") !=
                "70a6af05acccb7c354799d5b1b7542c86c677970681473f559bbf0f7e4d6d370" or
                topology.get("cbu_type_by_stage", {}).get("D1") != "CB" or
                topology.get("cbu_type_by_stage", {}).get("D2") != "THmitll_MERGE" or
                case.get("CBU_OVERRIDE_D1") != "CB_DIRECT"):
            raise RuntimeError(f"D1 direct CB source/topology provenance mismatch: {run_id}")
        for page in plot.get("pages", []):
            plot_path = SERIES / page["path"]
            if not plot_path.is_file() or root.sha256(plot_path) != page.get("sha256"):
                raise RuntimeError(f"A023/A024 standalone plot identity mismatch: {run_id}/{page.get('path')}")
        raw_sha_by_run[run_id] = digest
        run_status[run_id] = {"status": result.get("status"), "artifact_status": result.get("artifact_status"),
                              "physical_solve_count": result.get("physical_solve_count"),
                              "qa_status": qa.get("status"), "raw_bytes": raw.stat().st_size}
    for page in plot_qa.get("pages", []):
        page_path = SERIES / page["path"]
        if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
            raise RuntimeError(f"paired comparison plot hash mismatch: {page.get('path')}")

    sources, changes, excluded_html = _cb_direct_d1_delta_sources(root)
    run_dir_prefixes = {run_id: ("test", "exploration", SERIES.name, "runs", run_id)
                        for run_id in CB_DIRECT_D1_RUN_IDS}
    run_files = {run_id: [(source, member) for source, member in sources
                          if Path(member).parts[:5] == run_dir_prefixes[run_id]]
                 for run_id in CB_DIRECT_D1_RUN_IDS}
    for run_id, files in run_files.items():
        if not files or not any(Path(member).name == "raw.csv" for _source, member in files):
            raise RuntimeError(f"DELTA inventory lacks raw/evidence for {run_id}")
    shared = [(source, member) for source, member in sources
              if Path(member).parts[:4] != ("test", "exploration", SERIES.name, "runs")]
    if not shared:
        raise RuntimeError("CB_DIRECT D1 DELTA has no source/analysis evidence")
    return {"base_packages": base_packages, "existing_raw_refs": existing_raw_refs,
            "base_member_hashes": base_member_hashes, "raw_sha256_by_run": raw_sha_by_run,
            "run_artifact_status_by_run": run_status, "sources": sources,
            "run_files": run_files, "shared_sources": shared,
            "changes": changes, "excluded_html": excluded_html,
            "batch": batch, "comparison": comparison}


def validate_t1_chain_scope(root: Any) -> dict[str, Any]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("chain DELTA expects the existing master branch")
    if git("rev-parse", "--is-inside-work-tree") != "true":
        raise RuntimeError("not in a Git worktree")
    if subprocess.run(["git", "merge-base", "--is-ancestor", T1_CHAIN_BASE_COMMIT,
                       git("rev-parse", "HEAD")], cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("chain DELTA HEAD is not descended from the A017-A019 package checkpoint")
    if not (RUNS / T1_CHAIN_DELTA_RUN_IDS[-1]).is_dir():
        raise RuntimeError("A020-A022 chain batch is incomplete")
    all_run_dirs = sorted(path.name for path in RUNS.iterdir()
                          if path.is_dir() and re.fullmatch(r"A\d{3}_.+", path.name))
    expected = list(LEGACY_RUN_IDS + BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS +
                    T1_A013_A016_RUN_IDS + T1_CHAIN_BASE_RUN_IDS + T1_CHAIN_DELTA_RUN_IDS)
    if all_run_dirs != expected:
        raise RuntimeError(f"chain run closure mismatch; expected {expected}, found {all_run_dirs}")
    base_packages, existing_refs, base_member_hashes = verify_t1_a017_a019_checkpoint(root)
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    run_rows = {item.get("run_id"): item for item in manifest.get("runs", [])}
    batch = json.loads((SERIES / "analysis/t1-chain-20261009/BATCH_MANIFEST.json").read_text(encoding="utf-8"))
    results = json.loads((SERIES / "analysis/t1-chain-20261009/T1_CHAIN_RESULTS.json").read_text(encoding="utf-8"))
    if (batch.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            batch.get("authorized_run_ids") != list(T1_CHAIN_DELTA_RUN_IDS) or
            batch.get("physical_solve_count_completed") != 3 or
            results.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            results.get("physical_solve_count") != 3):
        raise RuntimeError("A020-A022 batch/summary is not mechanically closed")
    chain_refs = []
    raw_sha_by_run = {}
    run_status = {}
    for run_id in T1_CHAIN_DELTA_RUN_IDS:
        run_dir = RUNS / run_id
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "chain_qa.json").read_text(encoding="utf-8"))
        provenance = json.loads((run_dir / "provenance.json").read_text(encoding="utf-8"))
        plot_qa = json.loads((run_dir / "plot_qa.json").read_text(encoding="utf-8"))
        raw = run_dir / "raw.csv"
        raw_sha = root.sha256(raw)
        if (result.get("run_id") != run_id or result.get("artifact_status") != "VALID" or
                result.get("physical_solve_count") != 1 or result.get("raw_sha256") != raw_sha or
                qa.get("status") != "PASS" or qa.get("raw_sha256_before_analysis") != raw_sha or
                raw_qa.get("status") != "PASS" or raw_qa.get("raw_sha256_after_analysis") != raw_sha or
                plot_qa.get("status") != "PASS" or plot_qa.get("raw_sha256_after") != raw_sha or
                provenance.get("raw_sha256") != raw_sha or
                not run_rows.get(run_id) or run_rows[run_id].get("raw_sha256") != raw_sha):
            raise RuntimeError(f"A020-A022 raw/provenance/mechanical QA identity failed: {run_id}")
        for page in plot_qa.get("pages", []):
            plot_path = SERIES / page["path"]
            if not plot_path.is_file() or root.sha256(plot_path) != page.get("sha256"):
                raise RuntimeError(f"chain visualization QA/raw link mismatch: {run_id}/{page.get('path')}")
        raw_sha_by_run[run_id] = raw_sha
        run_status[run_id] = {"status": result.get("status"), "artifact_status": result.get("artifact_status"),
                              "physical_solve_count": result.get("physical_solve_count"), "qa_status": qa.get("status")}
        chain_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv", "raw_sha256": raw_sha,
                           "source_package_name": "THIS_DELTA", "source_package_sha256": "BOUND_AFTER_ARCHIVE"})
    sources, changes, excluded_html = _t1_chain_delta_sources(root)
    return {"base_packages": base_packages, "existing_raw_refs": existing_refs,
            "base_member_hashes": base_member_hashes, "raw_sha256_by_run": raw_sha_by_run,
            "run_artifact_status_by_run": run_status, "chain_raw_refs": chain_refs,
            "sources": sources, "changes": changes, "excluded_html": excluded_html,
            "batch": batch, "results": results}


def t1_chain_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not root.TAG_RE.fullmatch(tag):
        raise RuntimeError(f"invalid chain DELTA tag: {tag!r}")
    context = validate_t1_chain_scope(root)
    changes = context["changes"]
    sources = context["sources"]
    experiment_manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    limit_audit = {
        "recorded_physical_solve_count": experiment_manifest.get("physical_solve_count"),
        "declared_maximum_physical_solve_count": experiment_manifest.get("maximum_physical_solve_count"),
        "status": ("EXCEEDED_PRESERVED" if int(experiment_manifest.get("physical_solve_count", 0)) >
                   int(experiment_manifest.get("maximum_physical_solve_count", 0)) else "WITHIN_DECLARED_MAXIMUM"),
        "manifest_modified_by_packaging": False,
    }
    shared = [(source, member) for source, member in sources
              if Path(member).parts[:4] != ("test", "exploration", SERIES.name, "runs")]
    run_files = {run_id: [(source, member) for source, member in sources
                          if Path(member).parts[:5] == ("test", "exploration", SERIES.name, "runs", run_id)]
                 for run_id in T1_CHAIN_DELTA_RUN_IDS}
    if not shared or any(not group for group in run_files.values()):
        raise RuntimeError("chain DELTA must have source metadata and one evidence group per new raw")
    groups = [("source", "source", shared, None, 0)]
    all_run_evidence = []
    for run_id in T1_CHAIN_DELTA_RUN_IDS:
        evidence = [(source, member) for source, member in run_files[run_id]
                    if Path(member).name != "raw.csv"]
        raw = [(source, member) for source, member in run_files[run_id]
               if Path(member).name == "raw.csv"]
        if len(raw) != 1 or not evidence:
            raise RuntimeError(f"chain run must split into one raw and non-empty metadata: {run_id}")
        all_run_evidence.extend(evidence)
    groups.append(("runs_metadata", "evidence", all_run_evidence, None, 3))
    for run_id in T1_CHAIN_DELTA_RUN_IDS:
        groups.append((f"{run_id}_raw", "raw", [item for item in run_files[run_id]
                                                       if Path(item[1]).name == "raw.csv"], run_id, 0))
    specs, package_plans = [], []
    for group_name, group_kind, group_sources, run_id, solve_count in groups:
        source_records = root.file_records(group_sources)
        source_bytes = sum(record["bytes"] for record in source_records)
        included_hashes = {record["archive_path"]: record["sha256"] for record in source_records}
        new_files, modified_files = [], []
        for record in source_records:
            member = record["archive_path"]
            status = changes.get(member, "??")
            if status in {"A", "??"} or member not in context["base_member_hashes"]:
                new_files.append(member)
            else:
                modified_files.append(member)
        package_name = f"{SERIES.name}_delta_T1_CHAIN_A020_A022_{tag}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_target = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_target.exists():
            raise FileExistsError(f"refusing to overwrite immutable chain DELTA package: {package_name}")
        raw_map = ({run_id: context["raw_sha256_by_run"][run_id]} if group_kind == "raw" and run_id else {})
        associated_raw = ({run_id: context["raw_sha256_by_run"][run_id]
                           for run_id in T1_CHAIN_DELTA_RUN_IDS} if group_kind == "evidence" else {})
        base_refs = context["existing_raw_refs"]
        manifest = {
            "schema": "bvm-4x4-t1-chain-evidence-delta-v1",
            "package_type": "directory_snapshot_delta",
            "package_group": group_name,
            "base_commit": T1_CHAIN_BASE_COMMIT,
            "head_commit": "PENDING_EVIDENCE_COMMIT",
            "base_package_name": T1_CHAIN_BASE_SOURCE_NAME,
            "base_package_sha256": T1_CHAIN_BASE_SOURCE_SHA256,
            "base_package_source_commit": T1_CHAIN_BASE_SOURCE_HEAD,
            "base_delta_packages": context["base_packages"],
            "referenced_existing_cases": base_refs,
            "referenced_existing_raw_sha256": base_refs,
            "included_files": source_records,
            "included_file_sha256": included_hashes,
            "new_files": sorted(new_files),
            "modified_files": sorted(modified_files),
            "deleted_files": [],
            "new_physical_solve_count": solve_count,
            "reused_point_count": 0,
            "raw_sha256_by_run": raw_map,
            "associated_raw_sha256_by_run": associated_raw,
            "paired_evidence_package_name": (f"{SERIES.name}_delta_T1_CHAIN_A020_A022_{tag}_runs_metadata.zip"
                                             if group_kind == "raw" and run_id else None),
            "run_artifact_status_by_run": ({run_id: context["run_artifact_status_by_run"][run_id]}
                                            if run_id else context["run_artifact_status_by_run"]),
            "preexisting_experiment_manifest_limit_audit": limit_audit,
            "excluded_html": context["excluded_html"],
            "generated_from_head": git("rev-parse", "HEAD"),
            "scientific_interpretation_performed": False,
        }
        extra = {"DELTA_MANIFEST.json": (json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")}
        if source_bytes + sum(len(value) for value in extra.values()) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{group_name} chain DELTA exceeds the 100MB uncompressed guard: {source_bytes}")
        spec = {"name": package_name, "kind": "bvm_4x4_t1_chain_delta_v1", "scope": SERIES,
                "target": target, "qa_path": qa_target, "sources": group_sources,
                "extra_members": extra,
                "readme": (f"Incremental evidence DELTA for {SERIES.name}; tag={tag}; group={group_name}.\n"
                           f"Base checkpoint: {T1_CHAIN_BASE_SOURCE_NAME} ({T1_CHAIN_BASE_SOURCE_SHA256})\n"
                           "A001-A019 raw is referenced by exact package/raw SHA; it is not recopied.\n"
                           "This package contains only new source/config, run metadata, or one raw file.\n"
                           "Large raw files are split from their run metadata so each uncompressed group stays below the ordinary Git file guard.\n"
                           "Generated HTML is excluded; no scientific interpretation.\n").encode(),
                "base_name": T1_CHAIN_BASE_SOURCE_NAME, "base_sha": T1_CHAIN_BASE_SOURCE_SHA256,
                "raw_by_run": raw_map, "delta_manifest": manifest, "group_kind": group_kind,
                "run_id": run_id}
        specs.append(spec)
        package_plans.append({"package": package_name, "group": group_name,
                              "group_kind": group_kind,
                              "new_raw_files": [f"runs/{run_id}/raw.csv"] if group_kind == "raw" else [],
                              "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                              "source_file_count": len(group_sources), "uncompressed_source_bytes": source_bytes,
                              "raw_bytes": sum(record["bytes"] for record in source_records
                                               if Path(record["archive_path"]).name == "raw.csv"),
                              "new_files": sorted(new_files), "modified_files": sorted(modified_files),
                              "qa": qa_target.relative_to(REPO).as_posix()})
    plan = {"base_commit": T1_CHAIN_BASE_COMMIT,
            "generated_from_head": git("rev-parse", "HEAD"),
            "base_package_name": T1_CHAIN_BASE_SOURCE_NAME,
            "base_package_sha256": T1_CHAIN_BASE_SOURCE_SHA256,
            "base_package_source_commit": T1_CHAIN_BASE_SOURCE_HEAD,
            "base_delta_packages": context["base_packages"],
            "referenced_existing_cases": context["existing_raw_refs"],
            "new_physical_solve_count": 3, "reused_point_count": 0,
            "html_included": False, "excluded_html_count": len(context["excluded_html"]),
            "total_uncompressed_source_bytes": sum(item["uncompressed_source_bytes"] for item in package_plans),
            "package_count": len(specs), "packages": package_plans,
            "run_artifact_status_by_run": context["run_artifact_status_by_run"]}
    return specs, {"plan": plan, "source_paths": [member for _source, member in sources],
                   "total_new_physical_solve_count": 3,
                   "referenced_existing_cases": context["existing_raw_refs"]}


def cb_direct_d1_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not root.TAG_RE.fullmatch(tag):
        raise RuntimeError(f"invalid CB_DIRECT D1 DELTA tag: {tag!r}")
    context = validate_cb_direct_d1_scope(root)
    sources = context["sources"]
    changes = context["changes"]
    shared = context["shared_sources"]
    run_files = context["run_files"]
    if not shared or any(not group for group in run_files.values()):
        raise RuntimeError("CB_DIRECT D1 DELTA requires source metadata and both run evidence groups")

    groups: list[tuple[str, str, list[tuple[Path, str]], str | None, int]] = [
        ("source", "source", shared, None, 0)]
    run_metadata = []
    for run_id in CB_DIRECT_D1_RUN_IDS:
        evidence = [(source, member) for source, member in run_files[run_id]
                    if Path(member).name != "raw.csv"]
        raw = [(source, member) for source, member in run_files[run_id]
               if Path(member).name == "raw.csv"]
        if len(raw) != 1 or not evidence:
            raise RuntimeError(f"run delta must contain one immutable raw and non-empty metadata: {run_id}")
        run_metadata.extend(evidence)
    groups.append(("runs_metadata", "evidence", run_metadata, None, 2))
    for run_id in CB_DIRECT_D1_RUN_IDS:
        groups.append((f"{run_id}_raw", "raw", [item for item in run_files[run_id]
                                                     if Path(item[1]).name == "raw.csv"], run_id, 0))

    specs: list[dict[str, Any]] = []
    plans: list[dict[str, Any]] = []
    for group_name, group_kind, group_sources, run_id, solve_count in groups:
        records = root.file_records(group_sources)
        source_bytes = sum(item["bytes"] for item in records)
        included_hashes = {item["archive_path"]: item["sha256"] for item in records}
        new_files, modified_files = [], []
        for record in records:
            member, digest = record["archive_path"], record["sha256"]
            if member not in context["base_member_hashes"]:
                new_files.append(member)
            elif context["base_member_hashes"][member] != digest:
                modified_files.append(member)
        package_name = f"{SERIES.name}_delta_CB_DIRECT_D1_{tag}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_target = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_target.exists():
            raise FileExistsError(f"refusing to overwrite immutable CB_DIRECT D1 DELTA package: {package_name}")
        raw_map = ({run_id: context["raw_sha256_by_run"][run_id]}
                   if group_kind == "raw" and run_id else {})
        associated_raw = ({item: context["raw_sha256_by_run"][item]
                           for item in CB_DIRECT_D1_RUN_IDS} if group_kind == "evidence" else {})
        manifest = {
            "schema": "bvm-4x4-cb-direct-d1-evidence-delta-v1",
            "package_type": "directory_snapshot_delta",
            "package_group": group_name,
            "base_commit": CB_DIRECT_D1_BASE_COMMIT,
            "head_commit": "PENDING_EVIDENCE_COMMIT",
            "base_package_name": CB_DIRECT_D1_BASE_SOURCE_NAME,
            "base_package_sha256": CB_DIRECT_D1_BASE_SOURCE_SHA256,
            "base_package_source_commit": CB_DIRECT_D1_BASE_COMMIT,
            "base_delta_packages": context["base_packages"],
            "base_run_packages": context["existing_raw_refs"],
            "referenced_existing_cases": context["existing_raw_refs"],
            "referenced_existing_raw_sha256": context["existing_raw_refs"],
            "included_files": records,
            "included_file_sha256": included_hashes,
            "new_files": sorted(new_files),
            "modified_files": sorted(modified_files),
            "deleted_files": [],
            "new_physical_solve_count": solve_count,
            "reused_point_count": 0,
            "raw_sha256_by_run": raw_map,
            "associated_raw_sha256_by_run": associated_raw,
            "paired_evidence_package_name": (f"{SERIES.name}_delta_CB_DIRECT_D1_{tag}_runs_metadata.zip"
                                             if group_kind == "raw" else None),
            "run_artifact_status_by_run": ({run_id: context["run_artifact_status_by_run"][run_id]}
                                            if run_id else context["run_artifact_status_by_run"]),
            "excluded_html": context["excluded_html"],
            "generated_from_head": git("rev-parse", "HEAD"),
            "scientific_interpretation_performed": False,
        }
        extra = {"DELTA_MANIFEST.json": (json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")}
        if source_bytes + sum(len(value) for value in extra.values()) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{group_name} CB_DIRECT D1 package exceeds the 100MB uncompressed guard: {source_bytes}")
        spec = {"name": package_name, "kind": "bvm_4x4_cb_direct_d1_delta_v1", "scope": SERIES,
                "target": target, "qa_path": qa_target, "sources": group_sources,
                "extra_members": extra, "delta_manifest": manifest,
                "readme": (f"Incremental CB_DIRECT D1 evidence for {SERIES.name}; tag={tag}; group={group_name}.\n"
                           f"Base checkpoint source: {CB_DIRECT_D1_BASE_SOURCE_NAME} ({CB_DIRECT_D1_BASE_SOURCE_SHA256})\n"
                           "A001-A022 raw is referenced by exact package/raw SHA and is not recopied.\n"
                           "Only A023/A024 are new physical solves. Generated HTML is excluded.\n"
                           "Mechanical evidence only; no event classification or scientific interpretation.\n").encode(),
                "base_name": CB_DIRECT_D1_BASE_SOURCE_NAME,
                "base_sha": CB_DIRECT_D1_BASE_SOURCE_SHA256,
                "raw_by_run": raw_map, "group_kind": group_kind, "run_id": run_id}
        specs.append(spec)
        plans.append({"package": package_name, "group": group_name, "group_kind": group_kind,
                      "source_file_count": len(group_sources), "uncompressed_source_bytes": source_bytes,
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                      "new_files": sorted(new_files), "modified_files": sorted(modified_files),
                      "qa": qa_target.relative_to(REPO).as_posix()})
    plan = {"base_commit": CB_DIRECT_D1_BASE_COMMIT,
            "generated_from_head": git("rev-parse", "HEAD"),
            "base_package_name": CB_DIRECT_D1_BASE_SOURCE_NAME,
            "base_package_sha256": CB_DIRECT_D1_BASE_SOURCE_SHA256,
            "base_delta_packages": context["base_packages"],
            "referenced_existing_raw_count": len(context["existing_raw_refs"]),
            "referenced_existing_raw_sha256": context["existing_raw_refs"],
            "new_physical_solve_count": 2, "reused_point_count": 0,
            "html_included": False, "excluded_html_count": len(context["excluded_html"]),
            "total_uncompressed_source_bytes": sum(item["uncompressed_source_bytes"] for item in plans),
            "package_count": len(specs), "packages": plans,
            "run_artifact_status_by_run": context["run_artifact_status_by_run"]}
    return specs, {"plan": plan, "source_paths": [member for _source, member in sources],
                   "new_physical_solve_count": 2,
                   "referenced_existing_raw": context["existing_raw_refs"]}


def delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not root.TAG_RE.fullmatch(tag):
        raise RuntimeError(f"invalid delta tag: {tag!r}")
    metadata, legacy_raw_refs = base_records(root)
    bus400_qa, _bus400_manifest, bus400_refs = verify_prior_bus400_delta(root, legacy_raw_refs)
    _prior_delta_qa, _prior_delta_manifest, a009_raw_refs = verify_prior_a009_delta(root, bus400_refs)
    a010_packages, a012_raw_refs, a012_hashes = verify_prior_a010_a012_checkpoint(root, a009_raw_refs)
    checkpoint_packages, existing_raw_refs, prior_hashes = verify_prior_t1_a013_a016_checkpoint(
        root, a010_packages, a012_raw_refs, a012_hashes)
    if git("rev-parse", "HEAD") != DELTA_BASE_COMMIT:
        raise RuntimeError(f"T1 delta requires exact checkpoint HEAD {DELTA_BASE_COMMIT}")
    sources, changed_paths, excluded_html = _delta_sources(root)
    current_sources = []
    for source, member in sources:
        digest = root.sha256(source)
        if prior_hashes.get(member) != digest:
            current_sources.append((source, member))
    if not current_sources:
        raise RuntimeError("delta has no source or evidence changes since the A013-A016 checkpoint")
    per_run_sources, shared_sources = partition_delta_sources(current_sources)
    current_head = git("rev-parse", "HEAD")
    run_raw_sha = {}
    run_artifact_status = {}
    for run_id in DELTA_RUN_IDS:
        result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
        run_raw_sha[run_id] = result["raw_sha256"]
        run_artifact_status[run_id] = {"status": result.get("status"),
                                       "artifact_status": result.get("artifact_status"),
                                       "physical_solve_count": result.get("physical_solve_count")}
    experiment_manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    manifest_limit_audit = {
        "recorded_physical_solve_count": experiment_manifest.get("physical_solve_count"),
        "declared_maximum_physical_solve_count": experiment_manifest.get("maximum_physical_solve_count"),
        "status": ("EXCEEDED_PRESERVED" if
                   int(experiment_manifest.get("physical_solve_count", 0)) >
                   int(experiment_manifest.get("maximum_physical_solve_count", 0)) else "WITHIN_DECLARED_MAXIMUM"),
        "manifest_modified_by_packaging": False,
    }
    groups = [("source", shared_sources, None)] + [
        (run_id, per_run_sources[run_id], run_id) for run_id in DELTA_RUN_IDS]
    specs, plans = [], []
    for label, group_sources, run_id in groups:
        if not group_sources:
            raise RuntimeError(f"delta package group is empty: {label}")
        source_records = root.file_records(group_sources)
        source_bytes = sum(record["bytes"] for record in source_records)
        included_hashes = {record["archive_path"]: record["sha256"] for record in source_records}
        new_files, modified_files = [], []
        for record in source_records:
            member, digest = record["archive_path"], record["sha256"]
            if member not in prior_hashes:
                new_files.append(member)
            elif prior_hashes[member] != digest:
                modified_files.append(member)
        package_name = f"{SERIES.name}_delta_{tag}_{label}.zip"
        target = HANDOFF / package_name
        qa_target = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_target.exists():
            raise FileExistsError(f"refusing to overwrite immutable delta package: {package_name}")
        package_raw_sha = {run_id: run_raw_sha[run_id]} if run_id else {}
        solve_count = 1 if run_id else 0
        manifest = {
            "schema": "bvm-4x4-incremental-evidence-delta-v3",
            "package_type": "directory_snapshot_delta",
            "package_group": label,
            "base_commit": DELTA_BASE_COMMIT,
            "head_commit": "PENDING_EVIDENCE_COMMIT",
            "base_package_name": DELTA_BASE_PACKAGE_NAME,
            "base_package_sha256": DELTA_BASE_PACKAGE_SHA256,
            "base_package_source_commit": DELTA_BASE_PACKAGE_SOURCE_HEAD,
            "base_delta_packages": checkpoint_packages,
            "base_metadata_package_name": BASE_METADATA_NAME,
            "base_metadata_package_sha256": metadata["package_sha256"],
            "base_metadata_source_commit": metadata["source_commit"],
            "base_run_packages": existing_raw_refs,
            "included_files": source_records,
            "included_file_sha256": included_hashes,
            "new_files": new_files,
            "modified_files": modified_files,
            "deleted_files": [],
            "referenced_existing_cases": existing_raw_refs,
            "referenced_existing_raw_sha256": existing_raw_refs,
            "new_physical_solve_count": solve_count,
            "reused_point_count": 0,
            "raw_sha256_by_run": package_raw_sha,
            "run_artifact_status_by_run": ({run_id: run_artifact_status[run_id]} if run_id else
                                            run_artifact_status),
            "preexisting_experiment_manifest_limit_audit": manifest_limit_audit,
            "excluded_html": excluded_html,
            "generated_from_head": current_head,
        }
        extra = {"DELTA_MANIFEST.json": (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")}
        if source_bytes + sum(len(value) for value in extra.values()) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{label} delta exceeds the 100MB uncompressed archive guard: {source_bytes}")
        spec = {"name": package_name, "kind": "bvm_4x4_evidence_delta_v1", "scope": SERIES,
                "target": target, "qa_path": qa_target, "sources": group_sources,
                "extra_members": extra, "delta_manifest": manifest,
                "readme": (f"Incremental evidence delta for {SERIES.name}; tag={tag}; group={label}.\n"
                           f"Base delta: {DELTA_BASE_PACKAGE_NAME} ({DELTA_BASE_PACKAGE_SHA256})\n"
                           f"Base source HEAD: {DELTA_BASE_COMMIT}\n"
                           f"Batch additions: {', '.join(DELTA_RUN_IDS)}.\n"
                           "A001-A016 raw is referenced by exact package/raw SHA; no previous raw is copied again.\n"
                           "A017 postprocess-invalid raw is preserved and clearly tagged INVALID in the manifest.\n"
                           "Generated HTML is excluded. No scientific interpretation.\n").encode(),
                "excluded_files": excluded_html, "base_name": DELTA_BASE_PACKAGE_NAME,
                "base_sha": DELTA_BASE_PACKAGE_SHA256, "raw_by_run": package_raw_sha}
        specs.append(spec)
        plans.append({"package": package_name, "group": label,
                      "new_raw_files": [f"runs/{run_id}/raw.csv"] if run_id else [],
                      "raw_sha256_by_run": package_raw_sha,
                      "run_artifact_status_by_run": ({run_id: run_artifact_status[run_id]} if run_id else
                                                      run_artifact_status),
                      "raw_bytes_by_run": {run_id: (RUNS / run_id / "raw.csv").stat().st_size} if run_id else {},
                      "new_physical_solve_count": solve_count,
                      "source_file_count": len(group_sources),
                      "uncompressed_source_bytes": source_bytes,
                      "new_files": new_files, "modified_files": modified_files,
                      "qa": qa_target.relative_to(REPO).as_posix()})
    plan = {"base_commit": DELTA_BASE_COMMIT,
            "generated_from_head": current_head,
            "base_package_name": DELTA_BASE_PACKAGE_NAME,
            "base_package_sha256": DELTA_BASE_PACKAGE_SHA256,
            "base_delta_packages": checkpoint_packages,
            "base_metadata_package": BASE_METADATA_NAME,
            "base_metadata_sha256": metadata["package_sha256"],
            "packages": plans,
            "run_artifact_status_by_run": run_artifact_status,
            "referenced_existing_cases": existing_raw_refs,
            "new_physical_solve_count": len(DELTA_RUN_IDS),
            "reused_point_count": 0,
            "experiment_manifest_limit_audit": manifest_limit_audit,
            "excluded_html_count": len(excluded_html), "html_included": False,
            "total_uncompressed_source_bytes": sum(item["uncompressed_source_bytes"] for item in plans),
            "package_count": len(specs)}
    return specs, {"plan": plan, "source_paths": [rel for _, rel in sources],
                   "total_new_physical_solve_count": len(DELTA_RUN_IDS),
                   "referenced_existing_cases": existing_raw_refs}


def validate_scope(*, delta: bool = False) -> None:
    root = load_root_submit()
    if delta and git("rev-parse", "HEAD") != DELTA_BASE_COMMIT:
        raise RuntimeError(f"T1 delta requires exact checkpoint HEAD {DELTA_BASE_COMMIT}")
    changes = dict(root.committed_changes(DELTA_BASE_COMMIT, git("rev-parse", "HEAD"))) if delta else {}
    changes.update(root.working_changes())
    for path in root.untracked_files():
        changes.setdefault(path, "??")
    allowed = lambda path: root.in_scope(path, [SERIES]) or path in DELTA_GLOBAL_PATHS
    outside = sorted(path for path in changes if not allowed(path))
    if outside:
        raise RuntimeError("unrelated worktree changes outside this experiment: " + ", ".join(outside))
    if not RUNS.is_dir():
        raise RuntimeError("runs/ is missing; no completed physical batch found")
    run_dirs = sorted(path for path in RUNS.iterdir() if path.is_dir() and path.name.startswith("A"))
    expected = (list(LEGACY_RUN_IDS + BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS +
                     PREVIOUS_DELTA_RUN_IDS + DELTA_RUN_IDS) if delta else list(LEGACY_RUN_IDS))
    if [path.name for path in run_dirs] != expected:
        raise RuntimeError(f"run closure mismatch; expected {expected}, found {[p.name for p in run_dirs]}")
    check_dirs = [RUNS / run_id for run_id in DELTA_RUN_IDS] if delta else run_dirs
    for path in check_dirs:
        result = json.loads((path / "result.json").read_text(encoding="utf-8"))
        if result.get("run_id") != path.name:
            raise RuntimeError(f"run/result identity mismatch: {path.name}")
        if int(result.get("physical_solve_count", 0)) != 1:
            raise RuntimeError(f"run physical_solve_count is not one: {path.name}")
        raw = path / "raw.csv"
        if not raw.is_file() or root.sha256(raw) != result.get("raw_sha256"):
            raise RuntimeError(f"new raw does not match its result identity: {path.name}")
        if path.name in INVALID_PRESERVED_DELTA_RUN_IDS:
            static_qa = json.loads((path / "static_qa.json").read_text(encoding="utf-8"))
            probe = json.loads((path / "probe_manifest.json").read_text(encoding="utf-8"))
            log_text = (path / "run.log").read_text(encoding="utf-8")
            if (result.get("status") != "POSTPROCESS_FAILURE_RAW_PRESERVED" or
                    result.get("artifact_status") != "INVALID" or
                    "raw is missing required probes" not in result.get("error", "") or
                    static_qa.get("status") != "PASS" or
                    probe.get("profile") != "focus" or
                    "I(R_TERM_D0)" not in {item.get("label") for item in probe.get("signals", [])} or
                    "solver_exit_code=0" not in log_text or
                    f"raw_sha256={result['raw_sha256']}" not in log_text):
                raise RuntimeError("A017 invalid raw is not the expected preserved postprocess-failure artifact")
        else:
            qa = json.loads((path / "qa.json").read_text(encoding="utf-8"))
            t1_qa = json.loads((path / "t1_array_qa.json").read_text(encoding="utf-8"))
            if (result.get("artifact_status") != "VALID" or qa.get("status") != "PASS" or
                    t1_qa.get("status") != "PASS" or
                    qa.get("raw_sha256_before_analysis") != result.get("raw_sha256") or
                    t1_qa.get("raw_sha256_after_analysis") != result.get("raw_sha256") or
                    raw.stat().st_size != result.get("raw_bytes")):
                raise RuntimeError(f"run is not mechanically valid: {path.name}")
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    recorded = {item.get("run_id"): item for item in manifest.get("runs", [])}
    for path in check_dirs:
        result = json.loads((path / "result.json").read_text(encoding="utf-8"))
        row = recorded.get(path.name)
        if not row or row.get("raw_sha256") != result.get("raw_sha256"):
            raise RuntimeError(f"experiment_manifest raw identity missing/mismatched: {path.name}")
    if delta:
        batch = json.loads((SERIES / "analysis/t1-array-20261009/BATCH_MANIFEST.json").read_text(encoding="utf-8"))
        if (batch.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
                batch.get("authorized_run_ids") != list(T1_A013_A016_RUN_IDS) or
                batch.get("physical_solve_count_completed") != len(T1_A013_A016_RUN_IDS)):
            raise RuntimeError("registered A013-A016 T1 batch checkpoint is not closed")


def package_specs(tag: str, root: Any, *, dry_run: bool) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    run_dirs = sorted(path for path in RUNS.iterdir() if path.is_dir() and path.name.startswith("A"))
    meta_paths = [path for path in included_files(SERIES)
                  if path.relative_to(SERIES).parts[0] not in {"runs", "plots"}]
    specs = []
    plan = []
    all_raw: dict[str, str] = {}
    for run_dir in run_dirs:
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        raw = run_dir / "raw.csv"
        raw_hash = result.get("raw_sha256")
        if not isinstance(raw_hash, str) or len(raw_hash) != 64 or raw.stat().st_size == 0:
            raise RuntimeError(f"run result/raw identity is incomplete: {run_dir.name}")
        if result.get("raw_bytes") != raw.stat().st_size:
            raise RuntimeError(f"raw byte count disagrees with result manifest: {run_dir.name}")
        all_raw[run_dir.name] = raw_hash
        paths = included_files(run_dir)
        sources = [(path, path.relative_to(SERIES).as_posix()) for path in paths]
        uncompressed = sum(path.stat().st_size for path in paths)
        if uncompressed >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"single run bundle exceeds 100MB guard: {run_dir.name} ({uncompressed} bytes)")
        name = f"{SERIES.name}_raw_handoff_{run_dir.name}_{tag}.zip"
        target = HANDOFF / name
        qa_target = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_target.exists():
            raise FileExistsError(f"refusing to overwrite immutable package {name}")
        raw_map = {run_dir.name: raw_hash}
        spec = {"name": name, "kind": "directory_snapshot", "scope": SERIES,
                "target": target, "qa_path": qa_target, "sources": sources,
                "extra_members": {}, "excluded_files": [],
                "readme": (f"One-run evidence snapshot for {run_dir.name}.\n"
                           f"Raw SHA-256: {raw_hash}\n"
                           "Generated HTML is intentionally excluded and remains local.\n"
                           "Mechanical artifact QA only; no scientific interpretation.\n").encode(),
                "base_name": None, "base_sha": None, "raw_by_run": raw_map}
        specs.append(spec)
        plan.append({"name": name, "file_count": len(paths), "uncompressed_bytes": uncompressed,
                     "raw_bytes": raw.stat().st_size, "new_physical_solve_count": result["physical_solve_count"]})

    metadata_sources = [(path, path.relative_to(SERIES).as_posix()) for path in meta_paths]
    metadata_bytes = sum(path.stat().st_size for path in meta_paths)
    if metadata_bytes >= root.MAX_GIT_FILE_BYTES:
        raise RuntimeError(f"shared metadata bundle exceeds 100MB guard: {metadata_bytes} bytes")
    metadata_name = f"{SERIES.name}_metadata_{tag}.zip"
    metadata_target = HANDOFF / metadata_name
    metadata_qa = HANDOFF / f"{Path(metadata_name).stem}_PACKAGE_QA.json"
    if metadata_target.exists() or metadata_qa.exists():
        raise FileExistsError(f"refusing to overwrite immutable package {metadata_name}")
    metadata_spec = {"name": metadata_name, "kind": "directory_snapshot", "scope": SERIES,
                     "target": metadata_target, "qa_path": metadata_qa,
                     "sources": metadata_sources, "extra_members": {}, "excluded_files": [],
                     "readme": (f"Shared metadata snapshot for {SERIES.name}.\n"
                                f"Authorized runs: {', '.join(all_raw)}\n"
                                "Per-run raw files are stored only in their own handoff archives.\n"
                                "Generated HTML/Plotly JS and historical artifacts are excluded.\n"
                                "No new physical solve or scientific interpretation by packaging.\n").encode(),
                     "base_name": None, "base_sha": None, "raw_by_run": all_raw}
    specs.append(metadata_spec)
    plan.append({"name": metadata_name, "file_count": len(meta_paths),
                 "uncompressed_bytes": metadata_bytes, "raw_bytes": 0,
                 "new_physical_solve_count": 0})
    excluded_html = [p.relative_to(SERIES).as_posix() for p in SERIES.rglob("*.html") if p.is_file()]
    if dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "scope": SERIES.relative_to(REPO).as_posix(),
                          "head": git("rev-parse", "HEAD"),
                          "package_count": len(specs), "raw_references_not_copied": [],
                          "excluded_html_count": len(excluded_html),
                          "html_included": False, "new_physical_solve_count_in_package": 6,
                          "packages": plan,
                          "notes": ["New experiment has no previous archive base; run archives are standalone snapshots.",
                                    "Shared metadata archive contains no raw.csv; each raw is included once in its run archive."]},
                         ensure_ascii=False, indent=2))
    return specs, {"plan": plan, "excluded_html": excluded_html, "raw_sha256_by_run": all_raw}


def update_summary_with_packages(results: list[dict[str, Any]], package_table_marker: str = "<!-- PACKAGE_TABLE -->") -> None:
    summary = SERIES / "BATCH_SUMMARY.md"
    text = summary.read_text(encoding="utf-8")
    rows = ["| Archive | Bytes | SHA-256 |", "|---|---:|---|"]
    for item in results:
        name = Path(item["path"]).name
        rows.append(f"| `{name}` | {item['bytes']} | `{item['sha256']}` |")
    total = sum(int(item["bytes"]) for item in results)
    replacement = (f"{package_table_marker}\n" + "\n".join(rows) +
                   f"\n\nSix per-run ZIP total: **{total:,} bytes**.\n"
                   "<!-- METADATA_PACKAGE -->\n"
                   "The metadata ZIP carries this run-package table; its own identity is appended below after creation.\n"
                   "Each ZIP's detached PACKAGE_QA.json is the member/CRC/SHA authority.\n")
    if package_table_marker not in text:
        raise RuntimeError("BATCH_SUMMARY package table marker is missing")
    summary.write_text(text.replace(package_table_marker, replacement), encoding="utf-8")


def submit_metadata_v2(args: argparse.Namespace, root: Any) -> int:
    summary = SERIES / "BATCH_SUMMARY.md"
    package_name = f"{SERIES.name}_metadata_v2_{args.tag}.zip"
    target = HANDOFF / package_name
    qa_target = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
    if target.exists() or qa_target.exists():
        raise FileExistsError(f"refusing to overwrite immutable metadata-v2 package {package_name}")
    metadata_paths = [path for path in included_files(SERIES)
                      if path.relative_to(SERIES).parts[0] not in {"runs", "plots"}]
    source_bytes = sum(path.stat().st_size for path in metadata_paths)
    if source_bytes >= root.MAX_GIT_FILE_BYTES:
        raise RuntimeError(f"metadata-v2 input exceeds 100MB guard: {source_bytes}")
    rel_paths = [path.relative_to(REPO).as_posix() for path in metadata_paths]
    if rel_paths:
        subprocess.run(["git", "add", "-A", "-f", "--", *rel_paths], cwd=REPO, check=True)
    staged_empty = subprocess.run(["git", "diff", "--cached", "--quiet"],
                                   cwd=REPO, check=False).returncode == 0
    if not staged_empty:
        subprocess.run(["git", "commit", "-m", "docs: supersede unbound 4x4 metadata archive"],
                       cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")
    raw_by_run = {d.name: json.loads((d / "result.json").read_text(encoding="utf-8"))["raw_sha256"]
                  for d in sorted(RUNS.iterdir()) if d.is_dir() and d.name.startswith("A")}
    sources = [(path, path.relative_to(SERIES).as_posix()) for path in metadata_paths]
    spec = {"name": package_name, "kind": "directory_snapshot", "scope": SERIES,
            "target": target, "qa_path": qa_target, "sources": sources,
            "extra_members": {}, "excluded_files": [],
            "readme": (f"Bound shared metadata v2 for {SERIES.name}.\n"
                       f"Source commit: {source_commit}\n"
                       "Supersedes only the unbound first metadata snapshot; all six raw-run ZIPs are unchanged.\n"
                       "No new physical solve or scientific interpretation.\n").encode(),
            "base_name": None, "base_sha": None, "raw_by_run": raw_by_run}
    result = root.archive_bundle(spec, source_commit)
    subprocess.run(["git", "add", "-f", "--", result["path"], result["qa_path"]], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", "package: add bound 4x4 metadata v2"], cwd=REPO, check=True)
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
    mirror = root.copy_mirror([target], Path(args.mirror_dir).expanduser().resolve())
    print(json.dumps({"status": "METADATA_V2_COMPLETE", "source_commit": source_commit,
                      "final_commit": git("rev-parse", "HEAD"), "push": "SKIPPED" if args.no_push else "PASS",
                      "supersedes": "metadata_BVM4X4_20261009.zip",
                      "package": result, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def submit_delta(args: argparse.Namespace, root: Any) -> int:
    validate_scope(delta=True)
    specs, context = delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
    collisions = [str(mirror_dir / spec["name"]) for spec in specs
                  if (mirror_dir / spec["name"]).exists()]
    if collisions:
        raise FileExistsError("same-name mirror target already exists: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "scope": SERIES.relative_to(REPO).as_posix(),
                          "package_mode": "DELTA",
                          **context["plan"],
                          "push": "SKIPPED" if args.no_push else "bvm/master",
                          "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    stage_paths = context["source_paths"]
    if stage_paths:
        subprocess.run(["git", "add", "-A", "-f", "--", *stage_paths], cwd=REPO, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO, check=False).returncode != 0:
        subprocess.run(["git", "commit", "-m", args.message or "experiment: record BVM4x4 T1 A017-A019 evidence"],
                       cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")

    # Bind each precomputed, hash-listed source group to the evidence commit.
    package_results = []
    for spec in specs:
        manifest = spec["delta_manifest"]
        if spec.get("group_kind") == "raw":
            evidence_name = manifest.get("paired_evidence_package_name")
            evidence_result = next((item for item in package_results
                                    if Path(item["path"]).name == evidence_name), None)
            if evidence_result is None:
                raise RuntimeError(f"paired run metadata package must be created before raw: {evidence_name}")
            manifest["paired_evidence_package_sha256"] = evidence_result["sha256"]
        manifest["head_commit"] = source_commit
        manifest["generated_from_head"] = source_commit
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        package_result = root.archive_bundle(spec, source_commit)
        qa_path = REPO / package_result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "DELTA_SPLIT_BY_RUN", "base_commit": manifest["base_commit"],
                   "head_commit": source_commit, "base_package_name": manifest["base_package_name"],
                   "base_package_sha256": manifest["base_package_sha256"],
                   "base_package_source_commit": manifest["base_package_source_commit"],
                   "base_delta_packages": manifest["base_delta_packages"],
                   "delta_included_files": manifest["included_files"],
                   "delta_included_file_sha256": manifest["included_file_sha256"],
                   "new_files": manifest["new_files"], "modified_files": manifest["modified_files"],
                   "referenced_existing_cases": manifest["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": manifest["referenced_existing_raw_sha256"],
                   "new_physical_solve_count": manifest["new_physical_solve_count"],
                   "reused_point_count": manifest["reused_point_count"],
                   "html_included": False,
                   "package_group": manifest["package_group"],
                   "run_artifact_status_by_run": manifest["run_artifact_status_by_run"],
                   "preexisting_experiment_manifest_limit_audit": manifest["preexisting_experiment_manifest_limit_audit"],
                   "raw_sha256_by_run": manifest["raw_sha256_by_run"]})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(spec["target"]) or
                qa.get("package_bytes") != spec["target"].stat().st_size):
            raise RuntimeError(f"delta PACKAGE_QA identity failed: {spec['name']}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        package_results.append(package_result)

    package_paths = [path for result in package_results for path in (result["path"], result["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive BVM4x4 T1 A017-A019 delta {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "DELTA_SUBMIT_COMPLETE", "source_commit": source_commit,
                      "final_commit": git("rev-parse", "HEAD"), "push": push_status,
                      "packages": package_results,
                      "base_commit": specs[0]["delta_manifest"]["base_commit"],
                      "base_package": specs[0]["delta_manifest"]["base_package_name"],
                      "referenced_existing_raw_count": len(context["referenced_existing_cases"]),
                      "new_physical_solve_count": context["total_new_physical_solve_count"],
                      "mirror": mirror},
                     ensure_ascii=False, indent=2))
    return 0


def submit_t1_chain_delta(args: argparse.Namespace, root: Any) -> int:
    specs, context = t1_chain_delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
    collisions = [str(mirror_dir / spec["name"]) for spec in specs
                  if (mirror_dir / spec["name"]).exists()]
    if collisions:
        raise FileExistsError("same-name chain DELTA mirror target already exists: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "scope": SERIES.relative_to(REPO).as_posix(),
                          "package_mode": "T1_CHAIN_DELTA", **context["plan"],
                          "push": "SKIPPED" if args.no_push else git("rev-parse", "--abbrev-ref", "@{upstream}"),
                          "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    source_paths = context["source_paths"]
    if source_paths:
        subprocess.run(["git", "add", "-A", "-f", "--", *source_paths], cwd=REPO, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO, check=False).returncode != 0:
        subprocess.run(["git", "commit", "-m", args.message or
                        "experiment: record BVM4x4 T1 chain A020-A022 evidence"], cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")

    package_results = []
    for spec in specs:
        manifest = spec["delta_manifest"]
        manifest["head_commit"] = source_commit
        manifest["generated_from_head"] = source_commit
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")
        package_result = root.archive_bundle(spec, source_commit)
        package_path = REPO / package_result["path"]
        qa_path = REPO / package_result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "T1_CHAIN_DELTA_SPLIT_BY_RUN",
                   "base_commit": manifest["base_commit"], "head_commit": source_commit,
                   "base_package_name": manifest["base_package_name"],
                   "base_package_sha256": manifest["base_package_sha256"],
                   "base_package_source_commit": manifest["base_package_source_commit"],
                   "base_delta_packages": manifest["base_delta_packages"],
                   "delta_included_files": manifest["included_files"],
                   "delta_included_file_sha256": manifest["included_file_sha256"],
                   "new_files": manifest["new_files"], "modified_files": manifest["modified_files"],
                   "referenced_existing_cases": manifest["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": manifest["referenced_existing_raw_sha256"],
                   "new_physical_solve_count": manifest["new_physical_solve_count"],
                   "reused_point_count": manifest["reused_point_count"],
                   "html_included": False, "package_group": manifest["package_group"],
                   "run_artifact_status_by_run": manifest["run_artifact_status_by_run"],
                   "raw_sha256_by_run": manifest["raw_sha256_by_run"],
                   "associated_raw_sha256_by_run": manifest.get("associated_raw_sha256_by_run", {}),
                   "paired_evidence_package_name": manifest.get("paired_evidence_package_name"),
                   "paired_evidence_package_sha256": manifest.get("paired_evidence_package_sha256")})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(package_path) or
                qa.get("package_bytes") != package_path.stat().st_size):
            raise RuntimeError(f"chain DELTA PACKAGE_QA identity failed: {spec['name']}")
        with zipfile.ZipFile(package_path, "r") as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError(f"chain DELTA archive CRC failure in {spec['name']}: {bad}")
            archived_manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
            names = set(archive.namelist())
            for member, expected_sha in archived_manifest.get("included_file_sha256", {}).items():
                if member not in names:
                    raise RuntimeError(f"chain DELTA is missing declared archive member {member}")
                actual_sha = hashlib.sha256(archive.read(member)).hexdigest()
                if actual_sha != expected_sha:
                    raise RuntimeError(f"chain DELTA member SHA mismatch: {member}")
        if archived_manifest.get("head_commit") != source_commit:
            raise RuntimeError(f"chain DELTA manifest HEAD mismatch: {spec['name']}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        package_results.append(package_result)

    package_paths = [path for result in package_results for path in (result["path"], result["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive BVM4x4 T1 chain A020-A022 delta {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "T1_CHAIN_DELTA_SUBMIT_COMPLETE", "source_commit": source_commit,
                      "final_commit": git("rev-parse", "HEAD"), "push": push_status,
                      "packages": package_results, "base_commit": T1_CHAIN_BASE_COMMIT,
                      "base_package": T1_CHAIN_BASE_SOURCE_NAME,
                      "referenced_existing_raw_count": len(context["referenced_existing_cases"]),
                      "new_physical_solve_count": 3, "package_count": len(package_results),
                      "html_included": False, "mirror": mirror},
                     ensure_ascii=False, indent=2))
    return 0


def submit_cb_direct_d1_delta(args: argparse.Namespace, root: Any) -> int:
    specs, context = cb_direct_d1_delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
    local_collisions = [str(spec["target"]) for spec in specs
                        if spec["target"].exists() or spec["qa_path"].exists()]
    mirror_collisions = [str(mirror_dir / spec["name"]) for spec in specs
                         if (mirror_dir / spec["name"]).exists()]
    if local_collisions or mirror_collisions:
        raise FileExistsError("refusing to overwrite package/mirror targets: " +
                              ", ".join(local_collisions + mirror_collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "scope": SERIES.relative_to(REPO).as_posix(),
                          "package_mode": "CB_DIRECT_D1_DELTA", **context["plan"],
                          "push": git("rev-parse", "--abbrev-ref", "@{upstream}"),
                          "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    source_paths = context["source_paths"]
    if not source_paths:
        raise RuntimeError("CB_DIRECT D1 DELTA source inventory is empty")
    subprocess.run(["git", "add", "-A", "-f", "--", *source_paths], cwd=REPO, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO,
                      check=False).returncode != 0:
        subprocess.run(["git", "commit", "-m", args.message or
                        "experiment: record CB_DIRECT D1 A023-A024 evidence"], cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")

    package_results = []
    for spec in specs:
        manifest = spec["delta_manifest"]
        if spec.get("group_kind") == "raw":
            evidence_name = manifest.get("paired_evidence_package_name")
            evidence_result = next((item for item in package_results
                                    if Path(item["path"]).name == evidence_name), None)
            if evidence_result is None:
                raise RuntimeError(f"paired run-metadata package must be created before raw: {evidence_name}")
            manifest["paired_evidence_package_sha256"] = evidence_result["sha256"]
        manifest["head_commit"] = source_commit
        manifest["generated_from_head"] = source_commit
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")
        result = root.archive_bundle(spec, source_commit)
        package_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "CB_DIRECT_D1_DELTA_SPLIT_BY_RUN",
                   "base_commit": manifest["base_commit"], "head_commit": source_commit,
                   "base_package_name": manifest["base_package_name"],
                   "base_package_sha256": manifest["base_package_sha256"],
                   "base_delta_packages": manifest["base_delta_packages"],
                   "delta_included_files": manifest["included_files"],
                   "delta_included_file_sha256": manifest["included_file_sha256"],
                   "new_files": manifest["new_files"], "modified_files": manifest["modified_files"],
                   "referenced_existing_cases": manifest["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": manifest["referenced_existing_raw_sha256"],
                   "new_physical_solve_count": manifest["new_physical_solve_count"],
                   "reused_point_count": 0, "html_included": False,
                   "package_group": manifest["package_group"],
                   "raw_sha256_by_run": manifest["raw_sha256_by_run"],
                   "associated_raw_sha256_by_run": manifest["associated_raw_sha256_by_run"],
                   "run_artifact_status_by_run": manifest["run_artifact_status_by_run"],
                   "paired_evidence_package_name": manifest.get("paired_evidence_package_name"),
                   "paired_evidence_package_sha256": manifest.get("paired_evidence_package_sha256")})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(package_path) or
                qa.get("package_bytes") != package_path.stat().st_size):
            raise RuntimeError(f"CB_DIRECT D1 PACKAGE_QA identity failed: {spec['name']}")
        with zipfile.ZipFile(package_path) as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError(f"CB_DIRECT D1 ZIP CRC failure: {spec['name']}/{bad}")
            archived_manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
            names = set(archive.namelist())
            if archived_manifest.get("head_commit") != source_commit:
                raise RuntimeError(f"CB_DIRECT D1 archived HEAD mismatch: {spec['name']}")
            for member, expected_sha in archived_manifest.get("included_file_sha256", {}).items():
                if member not in names:
                    raise RuntimeError(f"CB_DIRECT D1 package member missing: {member}")
                if hashlib.sha256(archive.read(member)).hexdigest() != expected_sha:
                    raise RuntimeError(f"CB_DIRECT D1 package member SHA mismatch: {member}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"],
                       "status": qa["status"]})
        package_results.append(result)

    package_paths = [path for result in package_results for path in (result["path"], result["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive CB_DIRECT D1 A023-A024 delta {args.tag}"],
                   cwd=REPO, check=True)
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    else:
        push_status = "SKIPPED"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "CB_DIRECT_D1_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_commit, "final_commit": git("rev-parse", "HEAD"),
                      "push": push_status, "packages": package_results,
                      "base_commit": CB_DIRECT_D1_BASE_COMMIT,
                      "base_package": CB_DIRECT_D1_BASE_SOURCE_NAME,
                      "referenced_existing_raw_count": len(context["referenced_existing_raw"]),
                      "new_physical_solve_count": 2, "package_count": len(package_results),
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def _verify_cb_carry_buffer_base(root: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    packages, raw_refs, member_hashes = [], [], {}
    package_manifests = {}
    expected_run_ids = {f"A{i:03d}_{case}" for i, case in enumerate(
        ("D3_N0", "D3_N1", "D3_N2", "D3_N3", "D3_N4", "PAPER_1101_1101"), start=1)}
    expected_run_ids.update(BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS +
                            T1_A013_A016_RUN_IDS + T1_CHAIN_BASE_RUN_IDS +
                            T1_CHAIN_DELTA_RUN_IDS + CB_DIRECT_D1_RUN_IDS)
    for group, name, expected_sha in CB_CARRY_BUFFER_D1_BASE_PACKAGES:
        path = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        if not path.is_file() or root.sha256(path) != expected_sha:
            raise RuntimeError(f"CB_CARRY_BUFFER base package identity mismatch: {name}")
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_sha or
                qa.get("package_bytes") != path.stat().st_size):
            raise RuntimeError(f"CB_CARRY_BUFFER base PACKAGE_QA mismatch: {name}")
        with zipfile.ZipFile(path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"CB_CARRY_BUFFER base ZIP CRC failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            for member, digest in delta.get("included_file_sha256", {}).items():
                if member not in archive.namelist() or hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"CB_CARRY_BUFFER base package member hash failure: {name}/{member}")
                if member in member_hashes and member_hashes[member] != digest:
                    raise RuntimeError(f"CB_CARRY_BUFFER base package has conflicting member identity: {member}")
                member_hashes[member] = digest
        if delta.get("head_commit") != CB_CARRY_BUFFER_D1_BASE_SOURCE_HEAD:
            raise RuntimeError(f"CB_CARRY_BUFFER base package source HEAD mismatch: {name}")
        package_manifests[name] = delta
        packages.append({"package_name": name, "package_sha256": expected_sha,
                         "package_group": group, "source_commit": delta["head_commit"]})

    source_manifest = package_manifests[CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME]
    old_refs = source_manifest.get("referenced_existing_raw_sha256", [])
    if len(old_refs) != 22 or {item.get("run_id") for item in old_refs} != expected_run_ids - set(CB_DIRECT_D1_RUN_IDS):
        raise RuntimeError("CB_CARRY_BUFFER source checkpoint must close exactly A001-A022 raw")
    raw_refs.extend(old_refs)
    for group, name, expected_zip_sha in CB_CARRY_BUFFER_D1_BASE_PACKAGES[2:]:
        delta = package_manifests[name]
        run_ids = delta.get("raw_sha256_by_run", {})
        if len(run_ids) != 1:
            raise RuntimeError(f"CB_DIRECT base raw package does not bind exactly one run: {name}")
        run_id, raw_sha = next(iter(run_ids.items()))
        if run_id not in CB_DIRECT_D1_RUN_IDS or delta.get("package_group") != group:
            raise RuntimeError(f"CB_DIRECT base raw package has unexpected group/run: {name}")
        raw_members = [member for member, digest in delta.get("included_file_sha256", {}).items()
                       if member.endswith(f"/runs/{run_id}/raw.csv") and digest == raw_sha]
        if len(raw_members) != 1:
            raise RuntimeError(f"CB_DIRECT base raw package member/SHA mismatch: {name}")
        raw_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                         "raw_sha256": raw_sha, "source_package_name": name,
                         "source_package_sha256": expected_zip_sha})
    if len(raw_refs) != 24 or {item["run_id"] for item in raw_refs} != expected_run_ids:
        raise RuntimeError("CB_CARRY_BUFFER base raw reference closure is not exactly A001-A024")
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    manifest_rows = {item.get("run_id"): item for item in manifest.get("runs", [])}
    for item in raw_refs:
        row = manifest_rows.get(item["run_id"])
        if not row or row.get("raw_sha256") != item["raw_sha256"]:
            raise RuntimeError(f"base raw ref differs from experiment manifest: {item['run_id']}")
    return packages, raw_refs, member_hashes


def _cb_carry_buffer_sources(root: Any) -> tuple[list[tuple[Path, str]], dict[str, Any]]:
    head = git("rev-parse", "HEAD")
    changes = dict(root.committed_changes(CB_CARRY_BUFFER_D1_BASE_COMMIT, head))
    changes.update(root.working_changes())
    for path in root.untracked_files():
        changes.setdefault(path, "??")
    sources: dict[str, Path] = {}
    excluded_html: set[str] = set()
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if not root.in_scope(rel_path, [SERIES]):
            raise RuntimeError(f"CB_CARRY_BUFFER DELTA found out-of-scope change: {rel_path}")
        if status == "D":
            raise RuntimeError(f"CB_CARRY_BUFFER DELTA refuses deletions: {rel_path}")
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            if len(path.parts) < 5 or path.parts[4] not in CB_CARRY_BUFFER_D1_RUN_IDS:
                raise RuntimeError(f"CB_CARRY_BUFFER DELTA detected historical run edit: {rel_path}")
            continue
        if _excluded_delta_path(path):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        source = REPO / path
        if source.is_file() and not source.is_symlink():
            sources[rel_path] = source

    run_files: dict[str, list[tuple[Path, str]]] = {}
    raw_sha_by_run: dict[str, str] = {}
    status_by_run: dict[str, Any] = {}
    required = {"deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt",
                "USER_CASE.snapshot.env", "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env",
                "CBU_PARAMS.snapshot.env", "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env",
                "stimulus.inc", "case_manifest.json", "metadata.json", "provenance.json",
                "source_manifest.json", "topology_manifest.json", "probe_manifest.json", "static_qa.json",
                "stimulus_manifest.json", "metrics.json", "raw_qa.json", "chain_qa.json", "qa.json",
                "plot_manifest.json", "plot_qa.json", "result.json", "RESULT_BRIEF.md"}
    for run_id in CB_CARRY_BUFFER_D1_RUN_IDS:
        run_dir = RUNS / run_id
        if not run_dir.is_dir():
            raise RuntimeError(f"new authorized run directory is missing: {run_id}")
        files = [(path, path.relative_to(REPO).as_posix()) for path in included_files(run_dir)]
        names = {Path(member).name for _source, member in files}
        if required - names:
            raise RuntimeError(f"{run_id} delta evidence missing: {sorted(required - names)}")
        raw_path = run_dir / "raw.csv"
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "chain_qa.json").read_text(encoding="utf-8"))
        plot_qa = json.loads((run_dir / "plot_qa.json").read_text(encoding="utf-8"))
        digest = root.sha256(raw_path)
        if (result.get("artifact_status") != "VALID" or result.get("physical_solve_count") != 1 or
                result.get("raw_sha256") != digest or qa.get("status") != "PASS" or
                qa.get("raw_sha256_before_analysis") != digest or qa.get("raw_sha256_after_analysis") != digest or
                raw_qa.get("status") != "PASS" or raw_qa.get("raw_sha256_after_analysis") != digest or
                plot_qa.get("status") != "PASS" or plot_qa.get("raw_sha256_after") != digest or
                raw_path.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"new run artifact/raw/QA identity failed: {run_id}")
        for page in plot_qa.get("pages", []):
            page_path = SERIES / page["path"]
            if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
                raise RuntimeError(f"standalone HTML hash mismatch: {run_id}/{page.get('path')}")
        run_files[run_id] = files
        raw_sha_by_run[run_id] = digest
        status_by_run[run_id] = {"artifact_status": result.get("artifact_status"),
                                 "qa_status": qa.get("status"), "physical_solve_count": 1}
        for source, member in files:
            sources[member] = source

    task_analysis = CB_CARRY_BUFFER_D1_TASK
    if not task_analysis.is_dir():
        raise RuntimeError("carry-buffer analysis directory is missing")
    for path in sorted(task_analysis.rglob("*")):
        if not path.is_file():
            continue
        rel_path = path.relative_to(REPO).as_posix()
        if _excluded_delta_path(Path(rel_path)):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        sources[rel_path] = path
    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())

    for rel_path, status in changes.items():
        path = Path(rel_path)
        if status == "D" or _excluded_delta_path(path):
            continue
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            continue
        if root.in_scope(rel_path, [SERIES]) and (REPO / path).is_file() and rel_path not in sources:
            raise RuntimeError(f"changed source/evidence omitted from DELTA: {rel_path}")

    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    if int(manifest.get("physical_solve_count", -1)) != 26:
        raise RuntimeError(f"experiment_manifest should contain 26 solves, found {manifest.get('physical_solve_count')}")
    authorization = [item for item in manifest.get("authorization_batches", [])
                     if item.get("batch_id") == "BVM4X4_CB_CARRY_BUFFER_D1_20261009"]
    if (len(authorization) != 1 or authorization[0].get("authorized_physical_solve_count") != 2 or
            authorization[0].get("physical_solve_count_completed") != 2 or
            authorization[0].get("run_ids") != list(CB_CARRY_BUFFER_D1_RUN_IDS)):
        raise RuntimeError("experiment manifest authorization is not closed for exactly A025/A026")
    batch_path = CB_CARRY_BUFFER_D1_TASK / "BATCH_MANIFEST.json"
    analysis_path = CB_CARRY_BUFFER_D1_TASK / "BATCH_ANALYSIS.json"
    if (not batch_path.is_file() or not analysis_path.is_file() or
            json.loads(batch_path.read_text(encoding="utf-8")).get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            json.loads(analysis_path.read_text(encoding="utf-8")).get("status") != "PASS"):
        raise RuntimeError("carry-buffer batch/analysis is not closed with mechanical QA PASS")

    all_source_files = [(sources[key], key) for key in sorted(sources)]
    if len({member for _path, member in all_source_files}) != len(all_source_files):
        raise RuntimeError("duplicate source member in carry-buffer DELTA inventory")
    return all_source_files, {"changes": changes, "excluded_html": sorted(excluded_html),
                              "run_files": run_files, "raw_sha256_by_run": raw_sha_by_run,
                              "run_status_by_run": status_by_run, "all_sources": all_source_files}


def cb_carry_buffer_d1_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not root.TAG_RE.fullmatch(tag):
        raise RuntimeError(f"invalid CB_CARRY_BUFFER D1 DELTA tag: {tag!r}")
    if git("branch", "--show-current") != "master":
        raise RuntimeError("CB_CARRY_BUFFER DELTA expects the existing master branch")
    if subprocess.run(["git", "merge-base", "--is-ancestor", CB_CARRY_BUFFER_D1_BASE_COMMIT,
                       git("rev-parse", "HEAD")], cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("current HEAD is not descended from the A023/A024 package checkpoint")
    base_packages, existing_refs, base_hashes = _verify_cb_carry_buffer_base(root)
    sources, context = _cb_carry_buffer_sources(root)
    all_source_paths = context["all_sources"]
    by_run = context["run_files"]
    source_group = [(path, member) for path, member in all_source_paths
                    if len(Path(member).parts) < 5 or
                    Path(member).parts[:4] != ("test", "exploration", SERIES.name, "runs")]
    metadata_group = [(path, member) for run_id in CB_CARRY_BUFFER_D1_RUN_IDS
                      for path, member in by_run[run_id] if Path(member).name != "raw.csv"]
    raw_groups = {run_id: [(path, member) for path, member in by_run[run_id]
                           if Path(member).name == "raw.csv"] for run_id in CB_CARRY_BUFFER_D1_RUN_IDS}
    if not source_group or not metadata_group or any(len(items) != 1 for items in raw_groups.values()):
        raise RuntimeError("carry-buffer DELTA requires source, per-run metadata, and exactly one raw per run")
    groups: list[tuple[str, str, list[tuple[Path, str]], str | None, int]] = [
        ("source", "source", source_group, None, 0),
        ("runs_metadata", "evidence", metadata_group, None, 2),
        *((f"{run_id}_raw", "raw", raw_groups[run_id], run_id, 0)
          for run_id in CB_CARRY_BUFFER_D1_RUN_IDS),
    ]
    specs, plans = [], []
    for group_name, group_kind, group_sources, run_id, solve_count in groups:
        records = root.file_records(group_sources)
        source_bytes = sum(item["bytes"] for item in records)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files = sorted(member for member, digest in included.items() if member not in base_hashes)
        modified_files = sorted(member for member, digest in included.items()
                                if member in base_hashes and base_hashes[member] != digest)
        package_name = f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_{tag}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_path.exists():
            raise FileExistsError(f"refusing to overwrite immutable DELTA package: {package_name}")
        raw_map = ({run_id: context["raw_sha256_by_run"][run_id]}
                   if group_kind == "raw" and run_id else {})
        associated = ({run: context["raw_sha256_by_run"][run]
                       for run in CB_CARRY_BUFFER_D1_RUN_IDS} if group_kind == "evidence" else {})
        manifest = {
            "schema": "bvm-4x4-cb-carry-buffer-d1-evidence-delta-v1",
            "package_type": "directory_snapshot_delta", "package_group": group_name,
            "base_commit": CB_CARRY_BUFFER_D1_BASE_COMMIT,
            "head_commit": "PENDING_EVIDENCE_COMMIT",
            "base_package_name": CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME,
            "base_package_sha256": CB_CARRY_BUFFER_D1_BASE_SOURCE_SHA256,
            "base_package_source_commit": CB_CARRY_BUFFER_D1_BASE_SOURCE_HEAD,
            "base_delta_packages": base_packages,
            "referenced_existing_cases": existing_refs,
            "referenced_existing_raw_sha256": existing_refs,
            "included_files": records, "included_file_sha256": included,
            "new_files": new_files, "modified_files": modified_files, "deleted_files": [],
            "new_physical_solve_count": solve_count, "reused_point_count": 0,
            "raw_sha256_by_run": raw_map,
            "associated_raw_sha256_by_run": associated,
            "paired_evidence_package_name": (f"{SERIES.name}_delta_CB_CARRY_BUFFER_D1_{tag}_runs_metadata.zip"
                                             if group_kind == "raw" else None),
            "run_artifact_status_by_run": ({run_id: context["run_status_by_run"][run_id]}
                                            if run_id else context["run_status_by_run"]),
            "excluded_html": context["excluded_html"],
            "generated_from_head": git("rev-parse", "HEAD"),
            "scientific_interpretation_performed": False,
        }
        extra = {"DELTA_MANIFEST.json": (json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")}
        if source_bytes + sum(len(value) for value in extra.values()) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{group_name} uncompressed DELTA exceeds 100MB safety guard: {source_bytes}")
        spec = {"name": package_name, "kind": "bvm_4x4_cb_carry_buffer_d1_delta_v1",
                "scope": SERIES, "target": target, "qa_path": qa_path,
                "sources": group_sources, "extra_members": extra,
                "delta_manifest": manifest, "base_name": CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME,
                "base_sha": CB_CARRY_BUFFER_D1_BASE_SOURCE_SHA256,
                "raw_by_run": raw_map, "group_kind": group_kind, "run_id": run_id,
                "readme": (f"Incremental D1 carry-side CB_0928 evidence for {SERIES.name}; tag={tag}; group={group_name}.\n"
                           f"Base checkpoint: {CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME} ({CB_CARRY_BUFFER_D1_BASE_SOURCE_SHA256}).\n"
                           "A001-A024 raw is referenced by exact package/raw SHA and is not recopied.\n"
                           "Only A025/A026 are new physical solves. Generated HTML is excluded.\n"
                           "Mechanical evidence only; no SFQ event classification or scientific interpretation.\n").encode()}
        specs.append(spec)
        plans.append({"package": package_name, "package_group": group_name,
                      "file_count": len(records), "uncompressed_source_bytes": source_bytes,
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                      "new_files": new_files, "modified_files": modified_files,
                      "qa_path": qa_path.relative_to(REPO).as_posix()})
    plan = {"base_commit": CB_CARRY_BUFFER_D1_BASE_COMMIT,
            "generated_from_head": git("rev-parse", "HEAD"),
            "base_package_name": CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME,
            "base_package_sha256": CB_CARRY_BUFFER_D1_BASE_SOURCE_SHA256,
            "base_delta_packages": base_packages,
            "referenced_existing_raw_count": len(existing_refs),
            "referenced_existing_raw_sha256": existing_refs,
            "new_physical_solve_count": 2, "reused_point_count": 0,
            "html_included": False, "excluded_html_count": len(context["excluded_html"]),
            "package_count": len(specs), "packages": plans}
    return specs, {"plan": plan, "source_paths": [member for _path, member in sources],
                   "base_packages": base_packages, "referenced_existing_raw": existing_refs}


def submit_cb_carry_buffer_d1_delta(args: argparse.Namespace, root: Any) -> int:
    specs, context = cb_carry_buffer_d1_delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
    local_collisions = [str(spec["target"]) for spec in specs
                        if spec["target"].exists() or spec["qa_path"].exists()]
    mirror_collisions = [str(mirror_dir / spec["name"]) for spec in specs
                         if (mirror_dir / spec["name"]).exists()]
    if local_collisions or mirror_collisions:
        raise FileExistsError("refusing immutable package/mirror target overwrite: " +
                              ", ".join(local_collisions + mirror_collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "scope": SERIES.relative_to(REPO).as_posix(),
                          "package_mode": "CB_CARRY_BUFFER_D1_DELTA", **context["plan"],
                          "push_target": git("rev-parse", "--abbrev-ref", "@{upstream}"),
                          "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    if not context["source_paths"]:
        raise RuntimeError("carry-buffer DELTA source inventory is empty")
    subprocess.run(["git", "add", "-A", "-f", "--", *context["source_paths"]], cwd=REPO, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO,
                      check=False).returncode != 0:
        subprocess.run(["git", "commit", "-m", args.message or
                        "experiment: record D1 carry-side CB buffer A025-A026"], cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")
    package_results = []
    for spec in specs:
        manifest = spec["delta_manifest"]
        if spec["group_kind"] == "raw":
            paired_name = manifest.get("paired_evidence_package_name")
            paired = next((item for item in package_results if Path(item["path"]).name == paired_name), None)
            if paired is None:
                raise RuntimeError(f"runs_metadata package must precede raw archive: {paired_name}")
            manifest["paired_evidence_package_sha256"] = paired["sha256"]
        manifest["head_commit"] = source_commit
        manifest["generated_from_head"] = source_commit
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")
        result = root.archive_bundle(spec, source_commit)
        package_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "CB_CARRY_BUFFER_D1_DELTA_SPLIT_BY_RUN",
                   "base_commit": manifest["base_commit"], "head_commit": source_commit,
                   "base_package_name": manifest["base_package_name"],
                   "base_package_sha256": manifest["base_package_sha256"],
                   "base_package_source_commit": manifest["base_package_source_commit"],
                   "base_delta_packages": manifest["base_delta_packages"],
                   "delta_included_files": manifest["included_files"],
                   "delta_included_file_sha256": manifest["included_file_sha256"],
                   "new_files": manifest["new_files"], "modified_files": manifest["modified_files"],
                   "referenced_existing_cases": manifest["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": manifest["referenced_existing_raw_sha256"],
                   "new_physical_solve_count": manifest["new_physical_solve_count"],
                   "reused_point_count": 0, "html_included": False,
                   "package_group": manifest["package_group"],
                   "raw_sha256_by_run": manifest["raw_sha256_by_run"],
                   "associated_raw_sha256_by_run": manifest["associated_raw_sha256_by_run"],
                   "paired_evidence_package_name": manifest.get("paired_evidence_package_name"),
                   "paired_evidence_package_sha256": manifest.get("paired_evidence_package_sha256")})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(package_path) or
                qa.get("package_bytes") != package_path.stat().st_size or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"CB_CARRY_BUFFER PACKAGE_QA identity/member check failed: {spec['name']}")
        with zipfile.ZipFile(package_path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"CB_CARRY_BUFFER ZIP CRC failure: {spec['name']}")
            packed_delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if packed_delta.get("head_commit") != source_commit:
                raise RuntimeError(f"CB_CARRY_BUFFER archived DELTA head mismatch: {spec['name']}")
            for member, digest in packed_delta.get("included_file_sha256", {}).items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"CB_CARRY_BUFFER archive member SHA mismatch: {spec['name']}/{member}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        package_results.append(result)

    package_paths = [path for result in package_results for path in (result["path"], result["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive CB carry buffer D1 A025-A026 delta {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "CB_CARRY_BUFFER_D1_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_commit, "final_commit": git("rev-parse", "HEAD"),
                      "push": push_status, "packages": package_results,
                      "base_commit": CB_CARRY_BUFFER_D1_BASE_COMMIT,
                      "base_package": CB_CARRY_BUFFER_D1_BASE_SOURCE_NAME,
                      "referenced_existing_raw_count": len(context["referenced_existing_raw"]),
                      "new_physical_solve_count": 2, "package_count": len(package_results),
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def _verify_cb_carry_buffer_all_base(root: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    packages, existing_refs, member_hashes = _verify_cb_carry_buffer_base(root)
    for run_id, (name, expected_zip_sha, expected_raw_sha) in CB_CARRY_BUFFER_ALL_BASE_RAW_PACKAGES.items():
        zip_path = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        raw_path = RUNS / run_id / "raw.csv"
        result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        if (not zip_path.is_file() or root.sha256(zip_path) != expected_zip_sha or
                qa.get("status") != "PASS" or qa.get("package_sha256") != expected_zip_sha or
                qa.get("raw_sha256_by_run") != {run_id: expected_raw_sha} or
                result.get("raw_sha256") != expected_raw_sha or root.sha256(raw_path) != expected_raw_sha):
            raise RuntimeError(f"A025/A026 checkpoint raw/package identity mismatch: {run_id}")
        with zipfile.ZipFile(zip_path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"A025/A026 checkpoint raw ZIP CRC failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            member = f"test/exploration/{SERIES.name}/runs/{run_id}/raw.csv"
            if (delta.get("raw_sha256_by_run") != {run_id: expected_raw_sha} or
                    delta.get("included_file_sha256", {}).get(member) != expected_raw_sha or
                    hashlib.sha256(archive.read(member)).hexdigest() != expected_raw_sha):
                raise RuntimeError(f"A025/A026 base raw archive member hash mismatch: {run_id}")
            for path, digest in delta.get("included_file_sha256", {}).items():
                if path in member_hashes and member_hashes[path] != digest:
                    raise RuntimeError(f"A025/A026 base member identity conflicts with earlier checkpoint: {path}")
                member_hashes[path] = digest
        existing_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                              "raw_sha256": expected_raw_sha, "source_package_name": name,
                              "source_package_sha256": expected_zip_sha})
        packages.append({"package_name": name, "package_sha256": expected_zip_sha,
                         "package_group": run_id, "source_commit": CB_CARRY_BUFFER_ALL_BASE_SOURCE_HEAD})
    if len(existing_refs) != 26 or len({item["run_id"] for item in existing_refs}) != 26:
        raise RuntimeError("full-chain DELTA base must reference exactly A001-A026 raw")
    return packages, existing_refs, member_hashes


def _cb_carry_buffer_all_sources(root: Any) -> tuple[list[tuple[Path, str]], dict[str, Any]]:
    head = git("rev-parse", "HEAD")
    changes = dict(root.committed_changes(CB_CARRY_BUFFER_ALL_BASE_COMMIT, head))
    changes.update(root.working_changes())
    for path in root.untracked_files():
        changes.setdefault(path, "??")
    sources: dict[str, Path] = {}
    excluded_html: set[str] = set()
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if not root.in_scope(rel_path, [SERIES]):
            raise RuntimeError(f"CB_CARRY_BUFFER_ALL DELTA found out-of-scope change: {rel_path}")
        if status == "D":
            raise RuntimeError(f"CB_CARRY_BUFFER_ALL DELTA refuses deletions: {rel_path}")
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            if len(path.parts) < 5 or path.parts[4] not in CB_CARRY_BUFFER_ALL_RUN_IDS:
                raise RuntimeError(f"CB_CARRY_BUFFER_ALL DELTA detected historical run edit: {rel_path}")
            continue
        if _excluded_delta_path(path):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        source = REPO / path
        if source.is_file() and not source.is_symlink():
            sources[rel_path] = source

    run_files: dict[str, list[tuple[Path, str]]] = {}
    raw_sha_by_run: dict[str, str] = {}
    status_by_run: dict[str, Any] = {}
    required = {"deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt",
                "USER_CASE.snapshot.env", "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env",
                "CBU_PARAMS.snapshot.env", "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env",
                "stimulus.inc", "case_manifest.json", "metadata.json", "provenance.json",
                "source_manifest.json", "topology_manifest.json", "probe_manifest.json", "static_qa.json",
                "stimulus_manifest.json", "metrics.json", "raw_qa.json", "chain_qa.json", "qa.json",
                "plot_manifest.json", "plot_qa.json", "result.json", "RESULT_BRIEF.md"}
    for run_id in CB_CARRY_BUFFER_ALL_RUN_IDS:
        run_dir = RUNS / run_id
        if not run_dir.is_dir():
            raise RuntimeError(f"authorized full-chain run directory is missing: {run_id}")
        files = [(path, path.relative_to(REPO).as_posix()) for path in included_files(run_dir)]
        names = {Path(member).name for _path, member in files}
        missing = required - names
        if missing:
            raise RuntimeError(f"{run_id} full-chain evidence files missing: {sorted(missing)}")
        raw = run_dir / "raw.csv"
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "chain_qa.json").read_text(encoding="utf-8"))
        plot_qa = json.loads((run_dir / "plot_qa.json").read_text(encoding="utf-8"))
        case = json.loads((run_dir / "case_manifest.json").read_text(encoding="utf-8"))["case"]
        digest = root.sha256(raw)
        if (case.get("CBU_CHAIN_TOPOLOGY") != "CB_CARRY_BUFFER_ALL" or
                case.get("CBU_OVERRIDE_D1") != "NONE" or
                result.get("artifact_status") != "VALID" or result.get("physical_solve_count") != 1 or
                result.get("raw_sha256") != digest or qa.get("status") != "PASS" or
                qa.get("raw_sha256_before_analysis") != digest or qa.get("raw_sha256_after_analysis") != digest or
                raw_qa.get("status") != "PASS" or raw_qa.get("raw_sha256_after_analysis") != digest or
                plot_qa.get("status") != "PASS" or plot_qa.get("raw_sha256_after") != digest or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"full-chain raw/provenance/mechanical identity failure: {run_id}")
        for page in plot_qa.get("pages", []):
            page_path = SERIES / page["path"]
            if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
                raise RuntimeError(f"standalone plot hash mismatch: {run_id}/{page.get('path')}")
        run_files[run_id] = files
        raw_sha_by_run[run_id] = digest
        status_by_run[run_id] = {"artifact_status": "VALID", "qa_status": "PASS",
                                 "physical_solve_count": 1}
        for source, member in files:
            sources[member] = source

    if not CB_CARRY_BUFFER_ALL_TASK.is_dir():
        raise RuntimeError("full-chain task analysis directory is missing")
    for path in sorted(CB_CARRY_BUFFER_ALL_TASK.rglob("*")):
        if not path.is_file():
            continue
        rel_path = path.relative_to(REPO).as_posix()
        if _excluded_delta_path(Path(rel_path)):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        sources[rel_path] = path
    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if status == "D" or _excluded_delta_path(path):
            continue
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            continue
        if root.in_scope(rel_path, [SERIES]) and (REPO / path).is_file() and rel_path not in sources:
            raise RuntimeError(f"changed full-chain source/evidence omitted from DELTA: {rel_path}")

    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    if int(manifest.get("physical_solve_count", -1)) != 29:
        raise RuntimeError(f"experiment manifest should contain 29 solves, found {manifest.get('physical_solve_count')}")
    authorization = [item for item in manifest.get("authorization_batches", [])
                     if item.get("batch_id") == "BVM4X4_CB_CARRY_BUFFER_ALL_20261009"]
    if (len(authorization) != 1 or authorization[0].get("authorized_physical_solve_count") != 3 or
            authorization[0].get("physical_solve_count_completed") != 3 or
            authorization[0].get("run_ids") != list(CB_CARRY_BUFFER_ALL_RUN_IDS)):
        raise RuntimeError("experiment manifest authorization is not closed for exactly A027-A029")
    batch_path = CB_CARRY_BUFFER_ALL_TASK / "BATCH_MANIFEST.json"
    if not batch_path.is_file():
        raise RuntimeError("full-chain batch manifest is missing")
    batch_manifest = json.loads(batch_path.read_text(encoding="utf-8"))
    summary_path = SERIES / batch_manifest.get("analysis_path", "")
    if (batch_manifest.get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            not summary_path.is_file() or root.sha256(summary_path) != batch_manifest.get("analysis_sha256") or
            json.loads(summary_path.read_text(encoding="utf-8")).get("status") != "PASS"):
        raise RuntimeError("full-chain batch/analysis is not mechanically complete")
    members = [(sources[key], key) for key in sorted(sources)]
    return members, {"changes": changes, "run_files": run_files,
                     "raw_sha256_by_run": raw_sha_by_run, "run_status_by_run": status_by_run,
                     "excluded_html": sorted(excluded_html)}


def cb_carry_buffer_all_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not root.TAG_RE.fullmatch(tag):
        raise RuntimeError(f"invalid full-chain DELTA tag: {tag!r}")
    if git("branch", "--show-current") != "master":
        raise RuntimeError("full CB-chain DELTA expects the existing master branch")
    if subprocess.run(["git", "merge-base", "--is-ancestor", CB_CARRY_BUFFER_ALL_BASE_COMMIT,
                       git("rev-parse", "HEAD")], cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("current HEAD is not descended from the A025/A026 package checkpoint")
    base_packages, existing_refs, base_hashes = _verify_cb_carry_buffer_base(root)
    for run_id, (name, zip_sha, raw_sha) in CB_CARRY_BUFFER_ALL_BASE_RAW_PACKAGES.items():
        zip_path = HANDOFF / name
        if not zip_path.is_file() or root.sha256(zip_path) != zip_sha:
            raise RuntimeError(f"A025/A026 raw base package changed: {name}")
        with zipfile.ZipFile(zip_path, "r") as archive:
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
        existing_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                              "raw_sha256": raw_sha, "source_package_name": name,
                              "source_package_sha256": zip_sha})
        base_packages.append({"package_name": name, "package_sha256": zip_sha,
                              "package_group": delta.get("package_group"),
                              "source_commit": CB_CARRY_BUFFER_ALL_BASE_SOURCE_HEAD})
        for member, digest in delta.get("included_file_sha256", {}).items():
            if member in base_hashes and base_hashes[member] != digest:
                raise RuntimeError(f"A025/A026 base package member conflict: {member}")
            base_hashes[member] = digest
    if len(existing_refs) != 26 or len({item["run_id"] for item in existing_refs}) != 26:
        raise RuntimeError("full-chain base closure must reference A001-A026 exactly")

    all_sources, context = _cb_carry_buffer_all_sources(root)
    run_files = context["run_files"]
    source_group = [(source, member) for source, member in all_sources
                    if not (len(Path(member).parts) >= 5 and
                            Path(member).parts[:4] == ("test", "exploration", SERIES.name, "runs"))]
    metadata_group = [(source, member) for run_id in CB_CARRY_BUFFER_ALL_RUN_IDS
                      for source, member in run_files[run_id] if Path(member).name != "raw.csv"]
    raw_groups = {run_id: [(source, member) for source, member in run_files[run_id]
                           if Path(member).name == "raw.csv"] for run_id in CB_CARRY_BUFFER_ALL_RUN_IDS}
    if not source_group or not metadata_group or any(len(items) != 1 for items in raw_groups.values()):
        raise RuntimeError("full-chain DELTA source/metadata/one-raw-per-run groups are incomplete")
    groups = [("source", "source", source_group, None, 0),
              ("runs_metadata", "evidence", metadata_group, None, 3)]
    groups.extend((f"{run_id}_raw", "raw", raw_groups[run_id], run_id, 0)
                  for run_id in CB_CARRY_BUFFER_ALL_RUN_IDS)
    specs, plans = [], []
    for group_name, group_kind, group_sources, run_id, solve_count in groups:
        records = root.file_records(group_sources)
        source_bytes = sum(item["bytes"] for item in records)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files = sorted(member for member in included if member not in base_hashes)
        modified_files = sorted(member for member, digest in included.items()
                                if member in base_hashes and base_hashes[member] != digest)
        name = f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_{tag}_{group_name}.zip"
        target, qa_target = HANDOFF / name, HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_target.exists():
            raise FileExistsError(f"refusing immutable full-chain package overwrite: {name}")
        raw_map = {run_id: context["raw_sha256_by_run"][run_id]} if group_kind == "raw" and run_id else {}
        associated = ({run: context["raw_sha256_by_run"][run]
                       for run in CB_CARRY_BUFFER_ALL_RUN_IDS} if group_kind == "evidence" else {})
        delta = {"schema": "bvm-4x4-cb-carry-buffer-all-delta-v1",
                 "package_type": "directory_snapshot_delta", "package_group": group_name,
                 "base_commit": CB_CARRY_BUFFER_ALL_BASE_COMMIT, "head_commit": "PENDING_SOURCE_COMMIT",
                 "base_package_name": CB_CARRY_BUFFER_ALL_BASE_SOURCE_NAME,
                 "base_package_sha256": CB_CARRY_BUFFER_ALL_BASE_SOURCE_SHA256,
                 "base_package_source_commit": CB_CARRY_BUFFER_ALL_BASE_SOURCE_HEAD,
                 "base_delta_packages": base_packages,
                 "referenced_existing_cases": existing_refs,
                 "referenced_existing_raw_sha256": existing_refs,
                 "included_files": records, "included_file_sha256": included,
                 "new_files": new_files, "modified_files": modified_files, "deleted_files": [],
                 "new_physical_solve_count": solve_count, "reused_point_count": 0,
                 "raw_sha256_by_run": raw_map, "associated_raw_sha256_by_run": associated,
                 "paired_evidence_package_name": (f"{SERIES.name}_delta_CB_CARRY_BUFFER_ALL_{tag}_runs_metadata.zip"
                                                  if group_kind == "raw" else None),
                 "run_artifact_status_by_run": ({run_id: context["run_status_by_run"][run_id]}
                                                 if run_id else context["run_status_by_run"]),
                 "excluded_html": context["excluded_html"], "generated_from_head": git("rev-parse", "HEAD"),
                 "scientific_interpretation_performed": False}
        extras = {"DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2)+"\n").encode("utf-8")}
        if source_bytes + sum(len(item) for item in extras.values()) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{group_name} uncompressed package exceeds 100MB limit: {source_bytes}")
        spec = {"name": name, "kind": "bvm_4x4_cb_carry_buffer_all_delta_v1",
                "scope": SERIES, "target": target, "qa_path": qa_target,
                "sources": group_sources, "extra_members": extras,
                "delta_manifest": delta, "base_name": CB_CARRY_BUFFER_ALL_BASE_SOURCE_NAME,
                "base_sha": CB_CARRY_BUFFER_ALL_BASE_SOURCE_SHA256,
                "raw_by_run": raw_map, "group_kind": group_kind, "run_id": run_id,
                "readme": (f"Incremental full CB-only Carry-chain evidence for {SERIES.name}; tag={tag}; group={group_name}.\n"
                           f"Base checkpoint: {CB_CARRY_BUFFER_ALL_BASE_SOURCE_NAME} ({CB_CARRY_BUFFER_ALL_BASE_SOURCE_SHA256}).\n"
                           "A001-A026 raw is referenced by exact package/raw SHA and is not recopied.\n"
                           "Only A027-A029 are new physical solves. Generated HTML is excluded.\n"
                           "Mechanical evidence only; no bit decode, event classification, or scientific interpretation.\n").encode()}
        specs.append(spec)
        plans.append({"package": name, "package_group": group_name, "file_count": len(records),
                      "uncompressed_source_bytes": source_bytes,
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                      "new_files": new_files, "modified_files": modified_files,
                      "qa_path": qa_target.relative_to(REPO).as_posix()})
    plan = {"base_commit": CB_CARRY_BUFFER_ALL_BASE_COMMIT,
            "generated_from_head": git("rev-parse", "HEAD"),
            "base_package_name": CB_CARRY_BUFFER_ALL_BASE_SOURCE_NAME,
            "base_package_sha256": CB_CARRY_BUFFER_ALL_BASE_SOURCE_SHA256,
            "base_delta_packages": base_packages, "referenced_existing_raw_count": len(existing_refs),
            "referenced_existing_raw_sha256": existing_refs, "new_physical_solve_count": 3,
            "reused_point_count": 0, "html_included": False,
            "excluded_html_count": len(context["excluded_html"]), "package_count": len(specs),
            "packages": plans}
    return specs, {"plan": plan, "source_paths": [member for _source, member in all_sources],
                   "base_packages": base_packages, "referenced_existing_raw": existing_refs}


def submit_cb_carry_buffer_all_delta(args: argparse.Namespace, root: Any) -> int:
    specs, context = cb_carry_buffer_all_delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
    local_collisions = [str(spec["target"]) for spec in specs
                        if spec["target"].exists() or spec["qa_path"].exists()]
    mirror_collisions = [str(mirror_dir / spec["name"]) for spec in specs
                         if (mirror_dir / spec["name"]).exists()]
    if local_collisions or mirror_collisions:
        raise FileExistsError("refusing to overwrite immutable package/mirror target: " +
                              ", ".join(local_collisions + mirror_collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "scope": SERIES.relative_to(REPO).as_posix(),
                          "package_mode": "CB_CARRY_BUFFER_ALL_DELTA", **context["plan"],
                          "push_target": git("rev-parse", "--abbrev-ref", "@{upstream}"),
                          "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    if not context["source_paths"]:
        raise RuntimeError("full-chain DELTA source inventory is empty")
    subprocess.run(["git", "add", "-A", "-f", "--", *context["source_paths"]], cwd=REPO, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO,
                      check=False).returncode != 0:
        subprocess.run(["git", "commit", "-m", args.message or
                        "experiment: record full CB-only Carry chain A027-A029"], cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")
    package_results = []
    for spec in specs:
        manifest = spec["delta_manifest"]
        if spec["group_kind"] == "raw":
            paired_name = manifest.get("paired_evidence_package_name")
            paired = next((item for item in package_results if Path(item["path"]).name == paired_name), None)
            if paired is None:
                raise RuntimeError(f"runs_metadata package must precede raw package: {paired_name}")
            manifest["paired_evidence_package_sha256"] = paired["sha256"]
        manifest["head_commit"] = source_commit
        manifest["generated_from_head"] = source_commit
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")
        result = root.archive_bundle(spec, source_commit)
        package_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "CB_CARRY_BUFFER_ALL_DELTA_SPLIT_BY_RUN",
                   "base_commit": manifest["base_commit"], "head_commit": source_commit,
                   "base_package_name": manifest["base_package_name"],
                   "base_package_sha256": manifest["base_package_sha256"],
                   "base_package_source_commit": manifest["base_package_source_commit"],
                   "base_delta_packages": manifest["base_delta_packages"],
                   "delta_included_files": manifest["included_files"],
                   "delta_included_file_sha256": manifest["included_file_sha256"],
                   "new_files": manifest["new_files"], "modified_files": manifest["modified_files"],
                   "referenced_existing_cases": manifest["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": manifest["referenced_existing_raw_sha256"],
                   "new_physical_solve_count": manifest["new_physical_solve_count"],
                   "reused_point_count": 0, "html_included": False,
                   "package_group": manifest["package_group"],
                   "raw_sha256_by_run": manifest["raw_sha256_by_run"],
                   "associated_raw_sha256_by_run": manifest["associated_raw_sha256_by_run"],
                   "paired_evidence_package_name": manifest.get("paired_evidence_package_name"),
                   "paired_evidence_package_sha256": manifest.get("paired_evidence_package_sha256")})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(package_path) or
                qa.get("package_bytes") != package_path.stat().st_size or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"full-chain PACKAGE_QA identity/member check failed: {spec['name']}")
        with zipfile.ZipFile(package_path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"full-chain ZIP CRC failure: {spec['name']}")
            packed_delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if packed_delta.get("head_commit") != source_commit:
                raise RuntimeError(f"full-chain archived DELTA head mismatch: {spec['name']}")
            if any(member.lower().endswith(".html") for member in archive.namelist()):
                raise RuntimeError(f"HTML unexpectedly included in full-chain package: {spec['name']}")
            for member, digest in packed_delta.get("included_file_sha256", {}).items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"full-chain archive member SHA mismatch: {spec['name']}/{member}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        package_results.append(result)

    package_paths = [path for result in package_results for path in (result["path"], result["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive CB-only full chain A027-A029 delta {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "CB_CARRY_BUFFER_ALL_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_commit, "final_commit": git("rev-parse", "HEAD"),
                      "push": push_status, "packages": package_results,
                      "base_commit": CB_CARRY_BUFFER_ALL_BASE_COMMIT,
                      "base_package": CB_CARRY_BUFFER_ALL_BASE_SOURCE_NAME,
                      "referenced_existing_raw_count": len(context["referenced_existing_raw"]),
                      "new_physical_solve_count": 3, "package_count": len(package_results),
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def _verify_carry_post_cb_sjtl_base(root: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    packages, raw_refs, member_hashes = [], [], {}
    manifests = {}
    for group, name, expected_zip_sha in CARRY_POST_CB_SJTL_BASE_PACKAGES:
        package = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        if not package.is_file() or root.sha256(package) != expected_zip_sha:
            raise RuntimeError(f"A027-A029 base package identity mismatch: {name}")
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_zip_sha or
                qa.get("package_bytes") != package.stat().st_size or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"A027-A029 base PACKAGE_QA mismatch: {name}")
        with zipfile.ZipFile(package, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"A027-A029 base ZIP CRC failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if delta.get("head_commit") != CARRY_POST_CB_SJTL_BASE_SOURCE_HEAD:
                raise RuntimeError(f"A027-A029 base package source HEAD mismatch: {name}")
            for member, digest in delta.get("included_file_sha256", {}).items():
                if member not in archive.namelist() or hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"A027-A029 base member SHA mismatch: {name}/{member}")
                if member in member_hashes and member_hashes[member] != digest:
                    raise RuntimeError(f"A027-A029 base member identity conflict: {member}")
                member_hashes[member] = digest
            if any(member.lower().endswith(".html") for member in archive.namelist()):
                raise RuntimeError(f"base ZIP unexpectedly includes HTML: {name}")
        manifests[name] = delta
        packages.append({"package_name": name, "package_sha256": expected_zip_sha,
                         "package_group": group, "source_commit": delta.get("head_commit")})

    source_manifest = manifests[CARRY_POST_CB_SJTL_BASE_SOURCE_NAME]
    referenced = source_manifest.get("referenced_existing_raw_sha256", [])
    expected_older_runs = {f"A{i:03d}_{case}" for i, case in enumerate(
        ("D3_N0", "D3_N1", "D3_N2", "D3_N3", "D3_N4", "PAPER_1101_1101"), start=1)}
    expected_older_runs.update(BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS +
                               T1_A013_A016_RUN_IDS + T1_CHAIN_BASE_RUN_IDS +
                               T1_CHAIN_DELTA_RUN_IDS + CB_DIRECT_D1_RUN_IDS + CB_CARRY_BUFFER_D1_RUN_IDS)
    if (source_manifest.get("head_commit") != CARRY_POST_CB_SJTL_BASE_SOURCE_HEAD or
            len(referenced) != 26 or {item.get("run_id") for item in referenced} != expected_older_runs):
        raise RuntimeError("A027-A029 source package does not close exactly A001-A026 raw")
    raw_refs.extend(referenced)
    for run_id, (name, package_sha, raw_sha) in CARRY_POST_CB_SJTL_BASE_RAW_PACKAGES.items():
        manifest = manifests[name]
        raw_path = f"test/exploration/{SERIES.name}/runs/{run_id}/raw.csv"
        local_raw = RUNS / run_id / "raw.csv"
        if (manifest.get("package_group") != f"{run_id}_raw" or
                manifest.get("raw_sha256_by_run") != {run_id: raw_sha} or
                manifest.get("included_file_sha256", {}).get(raw_path) != raw_sha or
                root.sha256(local_raw) != raw_sha):
            raise RuntimeError(f"A027-A029 raw package closure mismatch: {run_id}")
        raw_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                         "raw_sha256": raw_sha, "source_package_name": name,
                         "source_package_sha256": package_sha})
    expected_all = {f"A{i:03d}_{case}" for i, case in enumerate(
        ("D3_N0", "D3_N1", "D3_N2", "D3_N3", "D3_N4", "PAPER_1101_1101"), start=1)}
    expected_all.update(BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS + T1_A013_A016_RUN_IDS +
                        T1_CHAIN_BASE_RUN_IDS + T1_CHAIN_DELTA_RUN_IDS + CB_DIRECT_D1_RUN_IDS +
                        CB_CARRY_BUFFER_D1_RUN_IDS + CB_CARRY_BUFFER_ALL_RUN_IDS)
    if len(raw_refs) != 29 or {item.get("run_id") for item in raw_refs} != expected_all:
        raise RuntimeError("A027-A029 package closure must reference exactly A001-A029 raw")
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    recorded = {item.get("run_id"): item.get("raw_sha256") for item in manifest.get("runs", [])}
    for item in raw_refs:
        if recorded.get(item["run_id"]) != item["raw_sha256"]:
            raise RuntimeError(f"registered base raw ref differs from experiment_manifest: {item['run_id']}")
    return packages, raw_refs, member_hashes


def _carry_post_cb_sjtl_sources(root: Any) -> tuple[
        list[tuple[Path, str]], dict[str, Any]]:
    head = git("rev-parse", "HEAD")
    changes = dict(root.committed_changes(CARRY_POST_CB_SJTL_BASE_COMMIT, head))
    changes.update(root.working_changes())
    for rel_path in root.untracked_files():
        changes.setdefault(rel_path, "??")
    sources: dict[str, Path] = {}
    excluded_html: set[str] = set()
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if not root.in_scope(rel_path, [SERIES]):
            raise RuntimeError(f"post-CB-sJTL DELTA found out-of-scope change: {rel_path}")
        if status == "D":
            raise RuntimeError(f"post-CB-sJTL DELTA refuses deletions: {rel_path}")
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            if len(path.parts) < 5 or path.parts[4] not in CARRY_POST_CB_SJTL_RUN_IDS:
                raise RuntimeError(f"post-CB-sJTL DELTA detected historical run change: {rel_path}")
            continue
        if _excluded_delta_path(path):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        if path.parts[:4] == ("test", "exploration", SERIES.name, "analysis") and \
                len(path.parts) >= 5 and path.parts[4] == CARRY_POST_CB_SJTL_TASK.name:
            continue
        source = REPO / path
        if source.is_file() and not source.is_symlink():
            sources[rel_path] = source

    run_files: dict[str, list[tuple[Path, str]]] = {}
    raw_sha_by_run: dict[str, str] = {}
    run_status: dict[str, Any] = {}
    required = {"deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt",
                "USER_CASE.snapshot.env", "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env",
                "CBU_PARAMS.snapshot.env", "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env",
                "stimulus.inc", "case_manifest.json", "metadata.json", "provenance.json",
                "source_manifest.json", "topology_manifest.json", "probe_manifest.json", "static_qa.json",
                "stimulus_manifest.json", "metrics.json", "raw_qa.json", "chain_qa.json", "qa.json",
                "plot_manifest.json", "plot_qa.json", "result.json", "RESULT_BRIEF.md"}
    for run_id in CARRY_POST_CB_SJTL_RUN_IDS:
        run_dir = RUNS / run_id
        if not run_dir.is_dir():
            raise RuntimeError(f"authorized post-CB-sJTL run is missing: {run_id}")
        files = [(path, path.relative_to(REPO).as_posix()) for path in included_files(run_dir)]
        if required - {Path(member).name for _path, member in files}:
            raise RuntimeError(f"post-CB-sJTL evidence files missing in {run_id}")
        raw = run_dir / "raw.csv"
        result, qa, raw_qa, plot_qa = (json.loads((run_dir / name).read_text(encoding="utf-8")) for name in
                                       ("result.json", "qa.json", "chain_qa.json", "plot_qa.json"))
        case = json.loads((run_dir / "case_manifest.json").read_text(encoding="utf-8"))["case"]
        digest = root.sha256(raw)
        if (case.get("CBU_CHAIN_TOPOLOGY") != "CB_CARRY_BUFFER_ALL" or
                case.get("CARRY_POST_CB_SJTL_COUNT") != "1" or
                result.get("artifact_status") != "VALID" or result.get("physical_solve_count") != 1 or
                result.get("raw_sha256") != digest or qa.get("status") != "PASS" or
                qa.get("raw_sha256_before_analysis") != digest or qa.get("raw_sha256_after_analysis") != digest or
                raw_qa.get("status") != "PASS" or raw_qa.get("raw_sha256_after_analysis") != digest or
                plot_qa.get("status") != "PASS" or plot_qa.get("raw_sha256_after") != digest or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"post-CB-sJTL raw/provenance/mechanical identity failed: {run_id}")
        for page in plot_qa.get("pages", []):
            page_path = SERIES / page["path"]
            if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
                raise RuntimeError(f"standalone HTML identity mismatch: {run_id}/{page.get('path')}")
        run_files[run_id] = files
        raw_sha_by_run[run_id] = digest
        run_status[run_id] = {"artifact_status": "VALID", "qa_status": "PASS",
                              "physical_solve_count": 1}
        for source, member in files:
            sources[member] = source

    if not CARRY_POST_CB_SJTL_TASK.is_dir():
        raise RuntimeError("post-CB-sJTL task analysis directory is missing")
    task_files = []
    for path in sorted(CARRY_POST_CB_SJTL_TASK.rglob("*")):
        if not path.is_file():
            continue
        rel_path = path.relative_to(REPO).as_posix()
        if _excluded_delta_path(Path(rel_path)):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        task_files.append((path, rel_path))
    task_metadata_files = task_files
    for path, member in task_metadata_files:
        sources[member] = path
    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())

    for rel_path, status in changes.items():
        path = Path(rel_path)
        if status == "D" or _excluded_delta_path(path):
            continue
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            continue
        if (path.parts[:4] == ("test", "exploration", SERIES.name, "analysis") and
                len(path.parts) >= 5 and path.parts[4] == CARRY_POST_CB_SJTL_TASK.name):
            continue
        if root.in_scope(rel_path, [SERIES]) and (REPO / path).is_file() and rel_path not in sources:
            raise RuntimeError(f"changed source/evidence omitted from DELTA: {rel_path}")

    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    if int(manifest.get("physical_solve_count", -1)) != 33:
        raise RuntimeError(f"experiment_manifest should contain 33 solves, found {manifest.get('physical_solve_count')}")
    authorization = [item for item in manifest.get("authorization_batches", [])
                     if item.get("batch_id") == "BVM4X4_CARRY_POST_CB_SJTL_20261010"]
    batch_path = CARRY_POST_CB_SJTL_TASK / "BATCH_MANIFEST.json"
    summary_path = CARRY_POST_CB_SJTL_TASK / "CARRY_POST_CB_SJTL_SUMMARY.json"
    if (len(authorization) != 1 or authorization[0].get("authorized_physical_solve_count") != 4 or
            authorization[0].get("physical_solve_count_completed") != 4 or
            authorization[0].get("run_ids") != list(CARRY_POST_CB_SJTL_RUN_IDS) or
            not batch_path.is_file() or not summary_path.is_file() or
            json.loads(batch_path.read_text(encoding="utf-8")).get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW" or
            json.loads(summary_path.read_text(encoding="utf-8")).get("status") != "PASS"):
        raise RuntimeError("post-CB-sJTL batch/analysis is not closed with mechanical QA PASS")

    all_sources = [(sources[key], key) for key in sorted(sources)]
    return all_sources, {"changes": changes, "excluded_html": sorted(excluded_html),
                         "run_files": run_files, "task_metadata_files": task_metadata_files,
                         "raw_sha256_by_run": raw_sha_by_run, "run_status_by_run": run_status,
                         "all_sources": all_sources, "base_packages": []}


def carry_post_cb_sjtl_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not root.TAG_RE.fullmatch(tag):
        raise RuntimeError(f"invalid post-CB-sJTL DELTA tag: {tag!r}")
    if git("branch", "--show-current") != "master":
        raise RuntimeError("post-CB-sJTL DELTA expects the existing master branch")
    if subprocess.run(["git", "merge-base", "--is-ancestor", CARRY_POST_CB_SJTL_BASE_COMMIT,
                       git("rev-parse", "HEAD")], cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("current HEAD is not descended from the A027-A029 package checkpoint")
    base_packages, existing_refs, base_hashes = _verify_carry_post_cb_sjtl_base(root)
    all_sources, context = _carry_post_cb_sjtl_sources(root)
    context["base_packages"] = base_packages
    source_group, metadata_group = [], []
    run_files = context["run_files"]
    run_raw_groups = {}
    for path, member in all_sources:
        parts = Path(member).parts
        if parts[:4] == ("test", "exploration", SERIES.name, "runs") and len(parts) >= 6 and parts[4] in CARRY_POST_CB_SJTL_RUN_IDS:
            if Path(member).name == "raw.csv":
                continue
            metadata_group.append((path, member))
        elif parts[:5] == ("test", "exploration", SERIES.name, "analysis", CARRY_POST_CB_SJTL_TASK.name):
            metadata_group.append((path, member))
        else:
            source_group.append((path, member))
    raw_groups = {run_id: [(path, member) for path, member in run_files[run_id]
                           if Path(member).name == "raw.csv"] for run_id in CARRY_POST_CB_SJTL_RUN_IDS}
    if not source_group or not metadata_group or any(len(group) != 1 for group in raw_groups.values()):
        raise RuntimeError("post-CB-sJTL DELTA requires source, metadata and exactly one raw package per run")

    groups = [("source", "source", source_group, None, 0),
              ("runs_metadata", "evidence", metadata_group, None, 4)]
    groups.extend((f"{run_id}_raw", "raw", raw_groups[run_id], run_id, 0)
                  for run_id in CARRY_POST_CB_SJTL_RUN_IDS)
    specs, plans = [], []
    for group_name, group_kind, group_sources, run_id, solve_count in groups:
        records = root.file_records(group_sources)
        source_bytes = sum(item["bytes"] for item in records)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files = sorted(member for member in included if member not in base_hashes)
        modified_files = sorted(member for member, digest in included.items()
                                if member in base_hashes and base_hashes[member] != digest)
        name = f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_{tag}_{group_name}.zip"
        target = HANDOFF / name
        qa_target = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_target.exists():
            raise FileExistsError(f"refusing immutable post-CB-sJTL package overwrite: {name}")
        raw_map = {run_id: context["raw_sha256_by_run"][run_id]} if group_kind == "raw" and run_id else {}
        associated = ({key: context["raw_sha256_by_run"][key] for key in CARRY_POST_CB_SJTL_RUN_IDS}
                      if group_kind == "evidence" else {})
        delta = {"schema": "bvm4x4-carry-post-cb-sjtl-delta-v1",
                 "package_type": "directory_snapshot_delta", "package_group": group_name,
                 "base_commit": CARRY_POST_CB_SJTL_BASE_COMMIT, "head_commit": "PENDING_SOURCE_COMMIT",
                 "base_package_name": CARRY_POST_CB_SJTL_BASE_SOURCE_NAME,
                 "base_package_sha256": CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256,
                 "base_package_source_commit": CARRY_POST_CB_SJTL_BASE_SOURCE_HEAD,
                 "base_delta_packages": base_packages,
                 "referenced_existing_cases": existing_refs,
                 "referenced_existing_raw_sha256": existing_refs,
                 "included_files": records, "included_file_sha256": included,
                 "new_files": new_files, "modified_files": modified_files, "deleted_files": [],
                 "new_physical_solve_count": solve_count, "reused_point_count": 0,
                 "raw_sha256_by_run": raw_map, "associated_raw_sha256_by_run": associated,
                 "paired_evidence_package_name": (f"{SERIES.name}_delta_CARRY_POST_CB_SJTL_{tag}_runs_metadata.zip"
                                                  if group_kind == "raw" else None),
                 "run_artifact_status_by_run": ({run_id: context["run_status_by_run"][run_id]}
                                                 if run_id else context["run_status_by_run"]),
                 "excluded_html": context["excluded_html"], "generated_from_head": git("rev-parse", "HEAD"),
                 "scientific_interpretation_performed": False}
        extras = {"DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2)+"\n").encode("utf-8")}
        if source_bytes + sum(len(value) for value in extras.values()) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{group_name} package exceeds the Git single-file limit")
        spec = {"name": name, "kind": "bvm_4x4_carry_post_cb_sjtl_delta_v1", "scope": SERIES,
                "target": target, "qa_path": qa_target, "sources": group_sources,
                "extra_members": extras, "delta_manifest": delta,
                "base_name": CARRY_POST_CB_SJTL_BASE_SOURCE_NAME,
                "base_sha": CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256,
                "raw_by_run": raw_map, "group_kind": group_kind, "run_id": run_id,
                "readme": (f"Incremental post-CB sJTL evidence for {SERIES.name}; tag={tag}; group={group_name}.\n"
                           f"Base checkpoint: {CARRY_POST_CB_SJTL_BASE_SOURCE_NAME} ({CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256}).\n"
                           "A001-A029 raw is referenced by package/raw SHA and is not recopied.\n"
                           "A030-A033 are the only new physical solves. Generated HTML is excluded.\n"
                           "Mechanical evidence only; no event classifier, bit decode, or scientific interpretation.\n").encode()}
        specs.append(spec)
        plans.append({"package": name, "package_group": group_name, "file_count": len(records),
                      "uncompressed_source_bytes": source_bytes,
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                      "new_files": new_files, "modified_files": modified_files,
                      "qa_path": qa_target.relative_to(REPO).as_posix()})
    plan = {"base_commit": CARRY_POST_CB_SJTL_BASE_COMMIT,
            "generated_from_head": git("rev-parse", "HEAD"),
            "base_package_name": CARRY_POST_CB_SJTL_BASE_SOURCE_NAME,
            "base_package_sha256": CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256,
            "base_delta_packages": base_packages, "referenced_existing_raw_count": len(existing_refs),
            "referenced_existing_raw_sha256": existing_refs, "new_physical_solve_count": 4,
            "reused_point_count": 0, "html_included": False,
            "excluded_html_count": len(context["excluded_html"]), "package_count": len(specs),
            "packages": plans}
    return specs, {"plan": plan, "source_paths": [member for _source, member in all_sources],
                   "base_packages": base_packages, "referenced_existing_raw": existing_refs}


def submit_carry_post_cb_sjtl_delta(args: argparse.Namespace, root: Any) -> int:
    specs, context = carry_post_cb_sjtl_delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
    collisions = [str(spec["target"]) for spec in specs if spec["target"].exists() or spec["qa_path"].exists()]
    collisions.extend(str(mirror_dir/spec["name"]) for spec in specs if (mirror_dir/spec["name"]).exists())
    if collisions:
        raise FileExistsError("refusing to overwrite immutable package/mirror targets: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "scope": SERIES.relative_to(REPO).as_posix(),
                          "package_mode": "CARRY_POST_CB_SJTL_DELTA", **context["plan"],
                          "push_target": git("rev-parse", "--abbrev-ref", "@{upstream}"),
                          "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    if not context["source_paths"]:
        raise RuntimeError("post-CB-sJTL DELTA source inventory is empty")
    subprocess.run(["git", "add", "-A", "-f", "--", *context["source_paths"]], cwd=REPO, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO, check=False).returncode != 0:
        subprocess.run(["git", "commit", "-m", args.message or
                        "experiment: record post-CB sJTL chain A030-A033"], cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")
    package_results = []
    for spec in specs:
        manifest = spec["delta_manifest"]
        if spec["group_kind"] == "raw":
            paired_name = manifest.get("paired_evidence_package_name")
            paired = next((item for item in package_results if Path(item["path"]).name == paired_name), None)
            if paired is None:
                raise RuntimeError(f"runs_metadata package must precede raw package: {paired_name}")
            manifest["paired_evidence_package_sha256"] = paired["sha256"]
        manifest["head_commit"] = source_commit
        manifest["generated_from_head"] = source_commit
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode("utf-8")
        result = root.archive_bundle(spec, source_commit)
        package_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "CARRY_POST_CB_SJTL_DELTA_SPLIT_BY_RUN",
                   "base_commit": manifest["base_commit"], "head_commit": source_commit,
                   "base_package_name": manifest["base_package_name"],
                   "base_package_sha256": manifest["base_package_sha256"],
                   "base_package_source_commit": manifest["base_package_source_commit"],
                   "base_delta_packages": manifest["base_delta_packages"],
                   "delta_included_files": manifest["included_files"],
                   "delta_included_file_sha256": manifest["included_file_sha256"],
                   "new_files": manifest["new_files"], "modified_files": manifest["modified_files"],
                   "referenced_existing_cases": manifest["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": manifest["referenced_existing_raw_sha256"],
                   "new_physical_solve_count": manifest["new_physical_solve_count"],
                   "reused_point_count": 0, "html_included": False,
                   "package_group": manifest["package_group"],
                   "raw_sha256_by_run": manifest["raw_sha256_by_run"],
                   "associated_raw_sha256_by_run": manifest["associated_raw_sha256_by_run"],
                   "paired_evidence_package_name": manifest.get("paired_evidence_package_name"),
                   "paired_evidence_package_sha256": manifest.get("paired_evidence_package_sha256")})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(package_path) or
                qa.get("package_bytes") != package_path.stat().st_size or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"post-CB-sJTL PACKAGE_QA/member integrity failed: {spec['name']}")
        with zipfile.ZipFile(package_path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"post-CB-sJTL ZIP CRC failure: {spec['name']}")
            packed = json.loads(archive.read("DELTA_MANIFEST.json"))
            if packed.get("head_commit") != source_commit or any(name.lower().endswith(".html") for name in archive.namelist()):
                raise RuntimeError(f"post-CB-sJTL ZIP manifest/head/HTML QA failure: {spec['name']}")
            for member, digest in packed.get("included_file_sha256", {}).items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"post-CB-sJTL archive member SHA mismatch: {spec['name']}/{member}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        package_results.append(result)

    package_paths = [path for result in package_results for path in (result["path"], result["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive post-CB sJTL chain A030-A033 DELTA {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "CARRY_POST_CB_SJTL_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_commit, "final_commit": git("rev-parse", "HEAD"),
                      "push": push_status, "packages": package_results,
                      "base_commit": CARRY_POST_CB_SJTL_BASE_COMMIT,
                      "base_package": CARRY_POST_CB_SJTL_BASE_SOURCE_NAME,
                      "referenced_existing_raw_count": len(context["referenced_existing_raw"]),
                      "new_physical_solve_count": 4, "package_count": len(package_results),
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def _verify_carry_sjtl_position_base(root: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    packages, raw_refs, member_hashes = _verify_carry_post_cb_sjtl_base(root)
    carry_post_member_hashes: dict[str, str] = {}
    manifest_rows = {item.get("run_id"): item for item in
                     json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8")).get("runs", [])}
    expected_prior_ids = {item.get("run_id") for item in raw_refs}
    if len(raw_refs) != 29:
        raise RuntimeError("A027-A029 checkpoint must close exactly A001-A029 before A030-A033 is added")
    for group, name, expected_sha in CARRY_SJTL_POSITION_BASE_PACKAGES:
        package = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_sha or
                qa.get("source_commit") != CARRY_SJTL_POSITION_BASE_SOURCE_HEAD or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"A030-A033 checkpoint package identity/QA mismatch: {name}")
        with zipfile.ZipFile(package, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"A030-A033 checkpoint ZIP CRC failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if (delta.get("head_commit") != CARRY_SJTL_POSITION_BASE_SOURCE_HEAD or
                    delta.get("base_package_name") != CARRY_POST_CB_SJTL_BASE_SOURCE_NAME or
                    delta.get("base_package_sha256") != CARRY_POST_CB_SJTL_BASE_SOURCE_SHA256 or
                    delta.get("package_group") != group):
                raise RuntimeError(f"A030-A033 checkpoint lineage mismatch: {name}")
            included = delta.get("included_file_sha256", {})
            if {item.get("archive_path"): item.get("sha256") for item in delta.get("included_files", [])} != included:
                raise RuntimeError(f"A030-A033 checkpoint file/hash inventory mismatch: {name}")
            if any(member.lower().endswith(".html") for member in archive.namelist()):
                raise RuntimeError(f"A030-A033 checkpoint unexpectedly contains HTML: {name}")
            for member, digest in included.items():
                old = carry_post_member_hashes.setdefault(member, digest)
                if old != digest:
                    raise RuntimeError(f"A030-A033 checkpoint contains conflicting member hashes: {member}")
        packages.append({"package_name": name, "package_sha256": expected_sha,
                         "package_group": group, "source_commit": CARRY_SJTL_POSITION_BASE_SOURCE_HEAD})
        if group.endswith("_raw"):
            run_id = next((candidate for candidate in CARRY_POST_CB_SJTL_RUN_IDS if candidate in group), None)
            if not run_id:
                raise RuntimeError(f"cannot map raw checkpoint package to run: {group}")
            raw_sha = json.loads((package.parent / f"{Path(name).stem}_PACKAGE_QA.json").read_text(encoding="utf-8"))\
                .get("raw_sha256_by_run", {}).get(run_id)
            result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
            local_raw_sha = root.sha256(RUNS / run_id / "raw.csv")
            row = manifest_rows.get(run_id)
            if (not raw_sha or raw_sha != result.get("raw_sha256") or raw_sha != local_raw_sha or
                    not row or row.get("raw_sha256") != raw_sha):
                raise RuntimeError(f"A030-A033 raw checkpoint identity mismatch: {run_id}")
            raw_refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                             "raw_sha256": raw_sha, "source_package_name": name,
                             "source_package_sha256": expected_sha})
            expected_prior_ids.add(run_id)
    # The newer A030-A033 checkpoint supersedes older member versions, while
    # conflicts among its own packages are rejected above.
    member_hashes.update(carry_post_member_hashes)
    expected_ids = {f"A{i:03d}_{case}" for i, case in enumerate(
        ("D3_N0", "D3_N1", "D3_N2", "D3_N3", "D3_N4", "PAPER_1101_1101"), start=1)}
    expected_ids.update(BUS400_RUN_IDS + A009_RUN_IDS + A010_A012_RUN_IDS + T1_A013_A016_RUN_IDS +
                        T1_CHAIN_BASE_RUN_IDS + T1_CHAIN_DELTA_RUN_IDS + CB_DIRECT_D1_RUN_IDS +
                        CB_CARRY_BUFFER_D1_RUN_IDS + CB_CARRY_BUFFER_ALL_RUN_IDS + CARRY_POST_CB_SJTL_RUN_IDS)
    recorded = {item.get("run_id"): item.get("raw_sha256") for item in
                json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8")).get("runs", [])}
    if len(raw_refs) != 33 or {item.get("run_id") for item in raw_refs} != expected_ids:
        raise RuntimeError("verified A001-A033 checkpoint raw reference closure is incomplete")
    if any(recorded.get(item["run_id"]) != item["raw_sha256"] for item in raw_refs):
        raise RuntimeError("A001-A033 checkpoint raw references differ from experiment_manifest")
    return packages, raw_refs, member_hashes


def _carry_sjtl_position_sources(root: Any) -> tuple[list[tuple[Path, str]], dict[str, Any]]:
    head = git("rev-parse", "HEAD")
    changes = dict(root.committed_changes(CARRY_SJTL_POSITION_BASE_COMMIT, head))
    changes.update(root.working_changes())
    for rel_path in root.untracked_files():
        changes.setdefault(rel_path, "??")
    sources: dict[str, Path] = {}
    excluded_html: set[str] = set()
    task_prefix = CARRY_SJTL_POSITION_TASK.relative_to(REPO).as_posix()
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if not root.in_scope(rel_path, [SERIES]):
            raise RuntimeError(f"carry-sJTL DELTA found out-of-scope change: {rel_path}")
        if status == "D":
            raise RuntimeError(f"carry-sJTL DELTA refuses deletions: {rel_path}")
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs"):
            if len(path.parts) < 5 or path.parts[4] not in CARRY_SJTL_POSITION_RUN_IDS:
                raise RuntimeError(f"carry-sJTL DELTA detected historical run mutation: {rel_path}")
            continue
        if _excluded_delta_path(path):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel_path)
            continue
        if rel_path.startswith(task_prefix + "/"):
            continue
        source = REPO / path
        if source.is_file() and not source.is_symlink():
            sources[rel_path] = source

    run_files: dict[str, list[tuple[Path, str]]] = {}
    raw_sha_by_run: dict[str, str] = {}
    run_status: dict[str, Any] = {}
    required = {"deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt",
                "USER_CASE.snapshot.env", "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env",
                "CBU_PARAMS.snapshot.env", "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env",
                "stimulus.inc", "case_manifest.json", "metadata.json", "provenance.json",
                "source_manifest.json", "topology_manifest.json", "probe_manifest.json", "static_qa.json",
                "stimulus_manifest.json", "metrics.json", "raw_qa.json", "chain_qa.json", "qa.json",
                "plot_manifest.json", "plot_qa.json", "result.json", "RESULT_BRIEF.md"}
    for run_id in CARRY_SJTL_POSITION_RUN_IDS:
        run_dir = RUNS / run_id
        if not run_dir.is_dir():
            raise RuntimeError(f"authorized carry-sJTL run directory missing: {run_id}")
        files = [(path, path.relative_to(REPO).as_posix()) for path in included_files(run_dir)]
        if required - {Path(member).name for _path, member in files}:
            raise RuntimeError(f"required evidence files missing in {run_id}")
        raw = run_dir / "raw.csv"
        result, qa, chain_qa, plot_qa, case_manifest, topology = (
            json.loads((run_dir / name).read_text(encoding="utf-8")) for name in
            ("result.json", "qa.json", "chain_qa.json", "plot_qa.json", "case_manifest.json", "topology_manifest.json"))
        digest = root.sha256(raw)
        if (result.get("artifact_status") != "VALID" or result.get("physical_solve_count") != 1 or
                result.get("raw_sha256") != digest or qa.get("status") != "PASS" or
                qa.get("raw_sha256_before_analysis") != digest or qa.get("raw_sha256_after_analysis") != digest or
                chain_qa.get("status") != "PASS" or chain_qa.get("raw_sha256_after_analysis") != digest or
                plot_qa.get("status") != "PASS" or plot_qa.get("raw_sha256_after") != digest or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"carry-sJTL raw/provenance/QA identity failed: {run_id}")
        case = case_manifest.get("case", {})
        topo_sjtl = topology.get("carry_sjtl_stages", [])
        deck_sjtl_count = sum(line.startswith("XSJTL_CARRY_D") for line in
                              (run_dir / "deck.cir").read_text(encoding="utf-8").splitlines())
        if (case.get("CBU_CHAIN_TOPOLOGY") != "CB_CARRY_BUFFER_ALL" or
                result.get("carry_sjtl_count") != len(topo_sjtl) or len(topo_sjtl) != deck_sjtl_count):
            raise RuntimeError(f"run topology manifest and deck disagree: {run_id}")
        for page in plot_qa.get("pages", []):
            page_path = SERIES / page["path"]
            if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
                raise RuntimeError(f"local classic plot SHA mismatch: {run_id}/{page.get('path')}")
        run_files[run_id] = files
        raw_sha_by_run[run_id] = digest
        run_status[run_id] = {"artifact_status": "VALID", "qa_status": "PASS",
                              "plot_qa_status": "PASS", "physical_solve_count": 1}
        for source, member in files:
            sources[member] = source

    if not CARRY_SJTL_POSITION_TASK.is_dir():
        raise RuntimeError("carry-sJTL analysis directory missing")
    task_files = []
    for path in sorted(CARRY_SJTL_POSITION_TASK.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(REPO).as_posix()
        if _excluded_delta_path(Path(rel)):
            if path.suffix.lower() == ".html":
                excluded_html.add(rel)
            continue
        task_files.append((path, rel))
        sources[rel] = path
    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())

    members = set(sources)
    for rel_path, status in changes.items():
        path = Path(rel_path)
        if status == "D" or _excluded_delta_path(path):
            continue
        if path.parts[:4] == ("test", "exploration", SERIES.name, "runs") or rel_path.startswith(task_prefix + "/"):
            continue
        if root.in_scope(rel_path, [SERIES]) and (REPO / path).is_file() and rel_path not in members:
            raise RuntimeError(f"changed source/evidence omitted from carry-sJTL DELTA: {rel_path}")

    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    if int(manifest.get("physical_solve_count", -1)) != 39:
        raise RuntimeError(f"experiment_manifest should contain 39 solves, found {manifest.get('physical_solve_count')}")
    auth = [item for item in manifest.get("authorization_batches", [])
            if item.get("batch_id") == "BVM4X4_CARRY_SJTL_POSITION_20261010"]
    batch_path = CARRY_SJTL_POSITION_TASK / "attempts" / "003" / "BATCH_MANIFEST.json"
    summary_path = CARRY_SJTL_POSITION_TASK / "CARRY_SJTL_POSITION_SUMMARY.json"
    if (len(auth) != 1 or auth[0].get("authorized_physical_solve_count") != 6 or
            auth[0].get("physical_solve_count_completed") != 6 or
            auth[0].get("run_ids") != list(CARRY_SJTL_POSITION_RUN_IDS) or
            not batch_path.is_file() or not summary_path.is_file() or
            json.loads(batch_path.read_text(encoding="utf-8")).get("status") != "BATCH_COMPLETE_AWAITING_USER_CHATGPT_REVIEW" or
            json.loads(summary_path.read_text(encoding="utf-8")).get("status") != "MECHANICAL_QA_PASS"):
        raise RuntimeError("carry-sJTL batch/analysis is not mechanically closed")

    all_sources = [(sources[key], key) for key in sorted(sources)]
    return all_sources, {"changes": changes, "excluded_html": sorted(excluded_html),
                         "run_files": run_files, "task_files": task_files,
                         "raw_sha256_by_run": raw_sha_by_run, "run_status_by_run": run_status,
                         "all_sources": all_sources, "base_packages": [],
                         "task_prefix": task_prefix}


def carry_sjtl_position_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not root.TAG_RE.fullmatch(tag):
        raise RuntimeError(f"invalid carry-sJTL DELTA tag: {tag!r}")
    if git("branch", "--show-current") != "master":
        raise RuntimeError("carry-sJTL DELTA expects master")
    if subprocess.run(["git", "merge-base", "--is-ancestor", CARRY_SJTL_POSITION_BASE_COMMIT,
                       git("rev-parse", "HEAD")], cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("HEAD is not descended from the A030-A033 packaged checkpoint")
    base_packages, existing_refs, base_hashes = _verify_carry_sjtl_position_base(root)
    all_sources, context = _carry_sjtl_position_sources(root)
    context["base_packages"] = base_packages
    task_prefix = context["task_prefix"]
    run_files = context["run_files"]
    source_group = []
    metadata_group = []
    for path, member in all_sources:
        parts = Path(member).parts
        if parts[:4] == ("test", "exploration", SERIES.name, "runs") and len(parts) >= 6 and parts[4] in CARRY_SJTL_POSITION_RUN_IDS:
            if Path(member).name != "raw.csv":
                metadata_group.append((path, member))
        elif member.startswith(task_prefix + "/"):
            metadata_group.append((path, member))
        else:
            source_group.append((path, member))
    raw_groups = {run_id: [(path, member) for path, member in run_files[run_id]
                           if Path(member).name == "raw.csv"] for run_id in CARRY_SJTL_POSITION_RUN_IDS}
    if not source_group or not metadata_group or any(len(group) != 1 for group in raw_groups.values()):
        raise RuntimeError("carry-sJTL DELTA requires source, metadata and one raw package per run")
    groups = [("source", "source", source_group, None, 0),
              ("runs_metadata", "evidence", metadata_group, None, 6)]
    groups.extend((f"{run_id}_raw", "raw", raw_groups[run_id], run_id, 0)
                  for run_id in CARRY_SJTL_POSITION_RUN_IDS)
    specs, plans = [], []
    for group_name, group_kind, group_sources, run_id, solve_count in groups:
        records = root.file_records(group_sources)
        source_bytes = sum(item["bytes"] for item in records)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files = sorted(member for member in included if member not in base_hashes)
        modified_files = sorted(member for member, digest in included.items()
                                if member in base_hashes and base_hashes[member] != digest)
        package_name = f"{SERIES.name}_delta_CARRY_SJTL_POSITION_{tag}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_path.exists():
            raise FileExistsError(f"refusing immutable carry-sJTL package overwrite: {package_name}")
        raw_map = {run_id: context["raw_sha256_by_run"][run_id]} if group_kind == "raw" and run_id else {}
        associated = ({run: context["raw_sha256_by_run"][run] for run in CARRY_SJTL_POSITION_RUN_IDS}
                      if group_kind == "evidence" else {})
        delta = {"schema": "bvm4x4-carry-sjtl-position-delta-v1",
                 "package_type": "directory_snapshot_delta", "package_group": group_name,
                 "base_commit": CARRY_SJTL_POSITION_BASE_COMMIT, "head_commit": "PENDING_SOURCE_COMMIT",
                 "base_package_name": CARRY_SJTL_POSITION_BASE_PACKAGE_NAME,
                 "base_package_sha256": CARRY_SJTL_POSITION_BASE_PACKAGE_SHA256,
                 "base_package_source_commit": CARRY_SJTL_POSITION_BASE_SOURCE_HEAD,
                 "base_delta_packages": base_packages,
                 "referenced_existing_cases": existing_refs,
                 "referenced_existing_raw_sha256": existing_refs,
                 "included_files": records, "included_file_sha256": included,
                 "new_files": new_files, "modified_files": modified_files, "deleted_files": [],
                 "new_physical_solve_count": solve_count, "reused_point_count": 0,
                 "raw_sha256_by_run": raw_map, "associated_raw_sha256_by_run": associated,
                 "paired_evidence_package_name": (f"{SERIES.name}_delta_CARRY_SJTL_POSITION_{tag}_runs_metadata.zip"
                                                  if group_kind == "raw" else None),
                 "run_artifact_status_by_run": ({run_id: context["run_status_by_run"][run_id]}
                                                 if run_id else context["run_status_by_run"]),
                 "excluded_html": context["excluded_html"], "generated_from_head": git("rev-parse", "HEAD"),
                 "scientific_interpretation_performed": False}
        extras = {"DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2) + "\n").encode()}
        if source_bytes + sum(len(value) for value in extras.values()) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{group_name} uncompressed package exceeds Git file limit")
        spec = {"name": package_name, "kind": "bvm_4x4_carry_sjtl_position_delta_v1", "scope": SERIES,
                "target": target, "qa_path": qa_path, "sources": group_sources,
                "extra_members": extras, "delta_manifest": delta,
                "base_name": CARRY_SJTL_POSITION_BASE_PACKAGE_NAME,
                "base_sha": CARRY_SJTL_POSITION_BASE_PACKAGE_SHA256,
                "raw_by_run": raw_map, "group_kind": group_kind, "run_id": run_id,
                "readme": (f"Incremental BVM 4x4 Carry sJTL placement evidence for {SERIES.name}; tag={tag}; group={group_name}.\n"
                           f"Base checkpoint: {CARRY_SJTL_POSITION_BASE_PACKAGE_NAME} ({CARRY_SJTL_POSITION_BASE_PACKAGE_SHA256}).\n"
                           "A001-A033 raw evidence is referenced by exact package/raw SHA and is not recopied.\n"
                           "A034-A039 are the only new physical solves. HTML is excluded.\n"
                           "Mechanical evidence only; no SFQ/event classifier or scientific interpretation.\n").encode()}
        specs.append(spec)
        plans.append({"package": package_name, "package_group": group_name, "file_count": len(records),
                      "uncompressed_source_bytes": source_bytes,
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                      "new_files": new_files, "modified_files": modified_files,
                      "qa_path": qa_path.relative_to(REPO).as_posix()})
    plan = {"base_commit": CARRY_SJTL_POSITION_BASE_COMMIT,
            "generated_from_head": git("rev-parse", "HEAD"),
            "base_package_name": CARRY_SJTL_POSITION_BASE_PACKAGE_NAME,
            "base_package_sha256": CARRY_SJTL_POSITION_BASE_PACKAGE_SHA256,
            "base_delta_packages": base_packages, "referenced_existing_raw_count": len(existing_refs),
            "referenced_existing_raw_sha256": existing_refs, "new_physical_solve_count": 6,
            "reused_point_count": 0, "html_included": False, "excluded_html_count": len(context["excluded_html"]),
            "package_count": len(specs), "packages": plans}
    return specs, {"plan": plan, "source_paths": [member for _path, member in all_sources],
                   "base_packages": base_packages, "referenced_existing_raw": existing_refs}


def submit_carry_sjtl_position_delta(args: argparse.Namespace, root: Any) -> int:
    specs, context = carry_sjtl_position_delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
    collisions = [str(spec["target"]) for spec in specs if spec["target"].exists() or spec["qa_path"].exists()]
    collisions.extend(str(mirror_dir / spec["name"]) for spec in specs if (mirror_dir / spec["name"]).exists())
    if collisions:
        raise FileExistsError("refusing immutable carry-sJTL package overwrite: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "package_mode": "CARRY_SJTL_POSITION_DELTA",
                          **context["plan"], "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    subprocess.run(["git", "add", "-A", "-f", "--", *context["source_paths"]], cwd=REPO, check=True)
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO, check=False).returncode != 0:
        subprocess.run(["git", "commit", "-m", args.message or "experiment: record BVM 4x4 carry sJTL A034-A039"],
                       cwd=REPO, check=True)
    source_commit = git("rev-parse", "HEAD")
    package_results = []
    for spec in specs:
        delta = spec["delta_manifest"]
        if spec["group_kind"] == "raw":
            paired = next((item for item in package_results
                           if Path(item["path"]).name == delta.get("paired_evidence_package_name")), None)
            if paired is None:
                raise RuntimeError("runs_metadata package must be archived before per-run raw ZIPs")
            delta["paired_evidence_package_sha256"] = paired["sha256"]
        delta["head_commit"] = source_commit
        delta["generated_from_head"] = source_commit
        spec["extra_members"]["DELTA_MANIFEST.json"] = (json.dumps(delta, ensure_ascii=False, indent=2) + "\n").encode()
        result = root.archive_bundle(spec, source_commit)
        package_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "CARRY_SJTL_POSITION_DELTA_SPLIT_BY_RUN",
                   "base_commit": delta["base_commit"], "head_commit": source_commit,
                   "base_package_name": delta["base_package_name"],
                   "base_package_sha256": delta["base_package_sha256"],
                   "base_package_source_commit": delta["base_package_source_commit"],
                   "base_delta_packages": delta["base_delta_packages"],
                   "delta_included_files": delta["included_files"],
                   "delta_included_file_sha256": delta["included_file_sha256"],
                   "new_files": delta["new_files"], "modified_files": delta["modified_files"],
                   "referenced_existing_cases": delta["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": delta["referenced_existing_raw_sha256"],
                   "new_physical_solve_count": delta["new_physical_solve_count"],
                   "reused_point_count": 0, "html_included": False,
                   "package_group": delta["package_group"],
                   "raw_sha256_by_run": delta["raw_sha256_by_run"],
                   "associated_raw_sha256_by_run": delta["associated_raw_sha256_by_run"],
                   "paired_evidence_package_name": delta.get("paired_evidence_package_name"),
                   "paired_evidence_package_sha256": delta.get("paired_evidence_package_sha256")})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(package_path) or
                qa.get("package_bytes") != package_path.stat().st_size or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"carry-sJTL PACKAGE_QA/member integrity failed: {spec['name']}")
        with zipfile.ZipFile(package_path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"carry-sJTL ZIP CRC failure: {spec['name']}")
            packed = json.loads(archive.read("DELTA_MANIFEST.json"))
            if packed.get("head_commit") != source_commit or any(name.lower().endswith(".html") for name in archive.namelist()):
                raise RuntimeError(f"carry-sJTL ZIP lineage/HTML check failed: {spec['name']}")
            for member, digest in packed.get("included_file_sha256", {}).items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"carry-sJTL archive member SHA mismatch: {spec['name']}/{member}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        package_results.append(result)
    package_paths = [path for result in package_results for path in (result["path"], result["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive BVM 4x4 carry sJTL A034-A039 DELTA {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "CARRY_SJTL_POSITION_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_commit, "final_commit": git("rev-parse", "HEAD"),
                      "push": push_status, "packages": package_results,
                      "base_commit": CARRY_SJTL_POSITION_BASE_COMMIT,
                      "base_package": CARRY_SJTL_POSITION_BASE_PACKAGE_NAME,
                      "referenced_existing_raw_count": len(context["referenced_existing_raw"]),
                      "new_physical_solve_count": 6, "package_count": len(package_results),
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def _verify_d3_timing_checkpoint(root: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str]]:
    packages = []
    refs: list[dict[str, Any]] = []
    member_hashes: dict[str, str] = {}
    old_manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    recorded_raw = {item.get("run_id"): item.get("raw_sha256") for item in old_manifest.get("runs", [])}
    metadata_delta = None
    package_records = []
    for label, name, expected_sha in CARRY_D3_TIMING_BASE_PACKAGES:
        archive_path = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(archive_path, qa_path)
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_sha or
                qa.get("source_commit") != CARRY_D3_TIMING_BASE_SOURCE_HEAD or
                qa.get("package_bytes") != archive_path.stat().st_size):
            raise RuntimeError(f"A034-A039 checkpoint identity/QA mismatch: {name}")
        with zipfile.ZipFile(archive_path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"A034-A039 base package CRC failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if (delta.get("head_commit") != CARRY_D3_TIMING_BASE_SOURCE_HEAD or
                    delta.get("package_group") != label and not (label.endswith("_raw") and delta.get("package_group", "").endswith("_raw"))):
                raise RuntimeError(f"A034-A039 checkpoint package lineage mismatch: {name}")
            included = delta.get("included_file_sha256", {})
            records = {item.get("archive_path"): item.get("sha256") for item in delta.get("included_files", [])}
            if included != records or any(member.lower().endswith(".html") for member in archive.namelist()):
                raise RuntimeError(f"A034-A039 package member index/HTML policy failure: {name}")
            for member, digest in included.items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"A034-A039 checkpoint member hash mismatch: {name}/{member}")
                prior = member_hashes.setdefault(member, digest)
                if prior != digest:
                    raise RuntimeError(f"A034-A039 checkpoint packages disagree on member hash: {member}")
            if label == "runs_metadata":
                metadata_delta = delta
            if label.endswith("_raw"):
                raw_map = delta.get("raw_sha256_by_run", {})
                if len(raw_map) != 1:
                    raise RuntimeError(f"A034-A039 raw package must identify exactly one run: {name}")
                run_id, raw_digest = next(iter(raw_map.items()))
                if recorded_raw.get(run_id) != raw_digest:
                    raise RuntimeError(f"A034-A039 checkpoint raw reference differs from experiment_manifest: {run_id}")
                refs.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                             "raw_sha256": raw_digest, "source_package_name": name,
                             "source_package_sha256": expected_sha})
        packages.append({"package_name": name, "package_sha256": expected_sha,
                         "package_group": label, "source_commit": CARRY_D3_TIMING_BASE_SOURCE_HEAD})
        package_records.append((label, name, expected_sha))
    if metadata_delta is None:
        raise RuntimeError("A034-A039 metadata package is missing its DELTA_MANIFEST")
    prior_refs = metadata_delta.get("referenced_existing_cases", [])
    if len(prior_refs) != 33:
        raise RuntimeError("A034-A039 checkpoint must reference exactly A001-A033")
    refs.extend(prior_refs)
    associated = metadata_delta.get("associated_raw_sha256_by_run", {})
    for label, name, expected_sha in CARRY_D3_TIMING_BASE_PACKAGES:
        if not label.endswith("_raw"):
            continue
        archive_path = HANDOFF / name
        with zipfile.ZipFile(archive_path, "r") as archive:
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
        run_id, raw_digest = next(iter(delta["raw_sha256_by_run"].items()))
        if associated.get(run_id) != raw_digest:
            raise RuntimeError(f"A034-A039 metadata/raw package reference mismatch: {run_id}")
    refs.sort(key=lambda item: int(item["run_id"].split("_", 1)[0][1:]))
    if len(refs) != 39 or len({item["run_id"] for item in refs}) != 39:
        raise RuntimeError("A034-A039 checkpoint raw reference closure is not exactly A001-A039")
    for item in refs:
        run_id = item["run_id"]
        local = RUNS / run_id / "raw.csv"
        if (recorded_raw.get(run_id) != item["raw_sha256"] or not local.is_file() or
                root.sha256(local) != item["raw_sha256"]):
            raise RuntimeError(f"A001-A039 immutable raw reference identity mismatch: {run_id}")
    return packages, refs, member_hashes


def _d3_timing_file_sets(root: Any) -> tuple[list[tuple[Path, str]], dict[str, Any]]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("A040/A041 DELTA requires the master branch")
    head = git("rev-parse", "HEAD")
    if subprocess.run(["git", "merge-base", "--is-ancestor", CARRY_D3_TIMING_PACKAGE_DIFF_START, head],
                      cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("HEAD is not descended from the A034-A039 package checkpoint worktree base")
    if git("status", "--porcelain"):
        raise RuntimeError("A040/A041 packaging requires a committed, clean worktree")
    changes: dict[str, str] = {}
    output = subprocess.run(["git", "diff", "--name-status", f"{CARRY_D3_TIMING_PACKAGE_DIFF_START}..{head}"],
                            cwd=REPO, text=True, capture_output=True, check=True).stdout
    for line in output.splitlines():
        status, path = line.split("\t", 1)
        if status.startswith("D"):
            raise RuntimeError(f"A040/A041 DELTA refuses file deletion: {path}")
        changes[path] = status
    series_prefix = SERIES.relative_to(REPO).as_posix() + "/"
    task_prefix = CARRY_D3_TIMING_TASK.relative_to(REPO).as_posix() + "/"
    source_paths: dict[str, Path] = {}
    metadata_paths: dict[str, Path] = {}
    raw_paths: dict[str, Path] = {}
    excluded_html = set()
    for rel, status in changes.items():
        path = Path(rel)
        if not rel.startswith(series_prefix):
            raise RuntimeError(f"A040/A041 DELTA found out-of-scope path: {rel}")
        if path.suffix.lower() == ".html":
            excluded_html.add(rel)
            continue
        if path.suffix.lower() in {".pyc", ".tmp"} or "__pycache__" in path.parts or "handoff" in path.parts:
            continue
        full = REPO / path
        if not full.is_file() or full.is_symlink():
            raise RuntimeError(f"A040/A041 DELTA member is missing or symlinked: {rel}")
        if path.parts[:5] == ("test", "exploration", SERIES.name, "runs", CARRY_D3_TIMING_RUN_IDS[0]) or \
                path.parts[:5] == ("test", "exploration", SERIES.name, "runs", CARRY_D3_TIMING_RUN_IDS[1]):
            run_id = path.parts[4]
            if path.name == "raw.csv":
                raw_paths[run_id] = full
            else:
                metadata_paths[rel] = full
        elif rel.startswith(task_prefix) or path.name == "experiment_manifest.json":
            metadata_paths[rel] = full
        else:
            source_paths[rel] = full
    for run_id in CARRY_D3_TIMING_RUN_IDS:
        run_dir = RUNS / run_id
        required = {"deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt", "USER_CASE.snapshot.env",
                    "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env", "CBU_PARAMS.snapshot.env",
                    "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env", "stimulus.inc",
                    "case_manifest.json", "metadata.json", "provenance.json", "source_manifest.json",
                    "topology_manifest.json", "probe_manifest.json", "static_qa.json", "stimulus_manifest.json",
                    "metrics.json", "raw_qa.json", "chain_qa.json", "qa.json", "plot_manifest.json",
                    "plot_qa.json", "result.json", "RESULT_BRIEF.md"}
        files = [path for path in run_dir.rglob("*") if path.is_file() and path.suffix.lower() != ".html"
                 and path.suffix.lower() != ".pyc" and "__pycache__" not in path.parts]
        if not run_dir.is_dir() or required - {path.name for path in files}:
            raise RuntimeError(f"A040/A041 required evidence closure incomplete: {run_id}")
        result, qa, chain_qa, plot_qa, metadata = (
            json.loads((run_dir / name).read_text(encoding="utf-8")) for name in
            ("result.json", "qa.json", "chain_qa.json", "plot_qa.json", "metadata.json"))
        raw = run_dir / "raw.csv"
        digest = root.sha256(raw)
        if (result.get("artifact_status") != "VALID" or result.get("physical_solve_count") != 1 or
                result.get("raw_sha256") != digest or metadata.get("raw_sha256") != digest or
                qa.get("status") != "PASS" or qa.get("raw_sha256_before_analysis") != digest or
                qa.get("raw_sha256_after_analysis") != digest or chain_qa.get("status") != "PASS" or
                chain_qa.get("raw_sha256_after_analysis") != digest or plot_qa.get("status") != "PASS" or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"A040/A041 raw or QA identity failure: {run_id}")
        if any((SERIES / page["path"]).is_file() is False or
               root.sha256(SERIES / page["path"]) != page.get("sha256")
               for page in plot_qa.get("pages", [])):
            raise RuntimeError(f"A040/A041 standalone HTML QA/source identity mismatch: {run_id}")
        if run_id not in raw_paths:
            raw_paths[run_id] = raw
        for path in files:
            rel = path.relative_to(REPO).as_posix()
            if path.name == "raw.csv":
                continue
            metadata_paths[rel] = path
    for path in SERIES.rglob("*.html"):
        if path.is_file():
            excluded_html.add(path.relative_to(REPO).as_posix())
    # Every changed in-scope tracked file must be in exactly one archive group or be explicitly excluded.
    assigned = set(source_paths) | set(metadata_paths) | {path.relative_to(REPO).as_posix() for path in raw_paths.values()}
    for rel in changes:
        if rel in excluded_html or rel.lower().endswith((".pyc", ".tmp")) or "__pycache__" in Path(rel).parts or "handoff" in Path(rel).parts:
            continue
        if rel not in assigned:
            raise RuntimeError(f"changed evidence omitted from DELTA groups: {rel}")
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    if int(manifest.get("physical_solve_count", -1)) != 41:
        raise RuntimeError(f"experiment manifest should contain 41 physical solves, found {manifest.get('physical_solve_count')}")
    auth = [item for item in manifest.get("authorization_batches", [])
            if item.get("batch_id") == "BVM4X4_D3_CARRY_TIMING_20261010"]
    batch_path = CARRY_D3_TIMING_TASK / "attempts" / "003" / "BATCH_MANIFEST.json"
    summary_path = CARRY_D3_TIMING_TASK / "D3_CARRY_TIMING_SUMMARY.json"
    if (len(auth) != 1 or auth[0].get("authorized_physical_solve_count") != 2 or
            auth[0].get("physical_solve_count_completed") != 2 or
            auth[0].get("run_ids") != list(CARRY_D3_TIMING_RUN_IDS) or
            not batch_path.is_file() or not summary_path.is_file() or
            json.loads(batch_path.read_text(encoding="utf-8")).get("status") != "BATCH_COMPLETE_AWAITING_USER_CHATGPT_REVIEW" or
            json.loads(summary_path.read_text(encoding="utf-8")).get("status") != "MECHANICAL_QA_PASS_AWAITING_USER_REVIEW"):
        raise RuntimeError("A040/A041 batch/analysis is not mechanically closed")
    all_sources = [(source_paths[key], key) for key in sorted(source_paths)] + \
                  [(metadata_paths[key], key) for key in sorted(metadata_paths)]
    all_sources.extend((raw_paths[run_id], raw_paths[run_id].relative_to(REPO).as_posix())
                       for run_id in CARRY_D3_TIMING_RUN_IDS)
    return all_sources, {"changes": changes, "source_paths": source_paths, "metadata_paths": metadata_paths,
                         "raw_paths": raw_paths, "excluded_html": sorted(excluded_html),
                         "run_ids": list(CARRY_D3_TIMING_RUN_IDS), "generated_from_head": head}


def _d3_timing_blob_sha(commit: str, path: str) -> str | None:
    exists = subprocess.run(["git", "cat-file", "-e", f"{commit}:{path}"], cwd=REPO,
                            check=False, capture_output=True)
    if exists.returncode:
        return None
    data = subprocess.run(["git", "show", f"{commit}:{path}"], cwd=REPO,
                          check=True, capture_output=True).stdout
    return hashlib.sha256(data).hexdigest()


def d3_carry_timing_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if tag != CARRY_D3_TIMING_TAG:
        raise RuntimeError(f"A040/A041 DELTA tag must be {CARRY_D3_TIMING_TAG}")
    base_packages, refs, _base_member_hashes = _verify_d3_timing_checkpoint(root)
    all_sources, context = _d3_timing_file_sets(root)
    source_group = [(path, member) for path, member in all_sources
                    if member in context["source_paths"]]
    metadata_group = [(path, member) for path, member in all_sources
                      if member in context["metadata_paths"]]
    raw_groups = {run_id: [(path, member) for path, member in all_sources
                           if Path(member).name == "raw.csv" and run_id in Path(member).parts]
                  for run_id in CARRY_D3_TIMING_RUN_IDS}
    if not source_group or not metadata_group or any(len(items) != 1 for items in raw_groups.values()):
        raise RuntimeError("A040/A041 DELTA requires source, metadata, and one immutable raw group per case")
    group_specs = [("source", source_group, None, 0),
                   ("runs_metadata", metadata_group, None, 2),
                   *((f"{run_id}_raw", raw_groups[run_id], run_id, 0) for run_id in CARRY_D3_TIMING_RUN_IDS)]
    specs, plans = [], []
    for group_name, sources, run_id, solve_count in group_specs:
        records = root.file_records(sources)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files, modified_files = [], []
        for member, digest in included.items():
            base_digest = _d3_timing_blob_sha(CARRY_D3_TIMING_BASE_SOURCE_HEAD, member)
            if base_digest is None:
                new_files.append(member)
            elif base_digest != digest:
                modified_files.append(member)
        package_name = f"{SERIES.name}_delta_D3_CARRY_TIMING_{tag}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        if target.exists() or qa_path.exists():
            raise FileExistsError(f"refusing immutable A040/A041 package overwrite: {package_name}")
        run_raw = {}
        if run_id:
            run_raw[run_id] = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))["raw_sha256"]
        delta = {"schema": "bvm4x4-d3-carry-timing-delta-v1",
                 "package_type": "directory_snapshot_delta", "package_group": group_name,
                 "base_commit": CARRY_D3_TIMING_BASE_SOURCE_HEAD,
                 "base_worktree_checkpoint_commit": CARRY_D3_TIMING_PACKAGE_DIFF_START,
                 "head_commit": "PENDING_SOURCE_COMMIT",
                 "base_package_name": CARRY_D3_TIMING_BASE_PACKAGES[0][1],
                 "base_package_sha256": CARRY_D3_TIMING_BASE_PACKAGES[0][2],
                 "base_package_source_commit": CARRY_D3_TIMING_BASE_SOURCE_HEAD,
                 "base_delta_packages": base_packages,
                 "referenced_existing_cases": refs,
                 "referenced_existing_raw_sha256": refs,
                 "included_files": records, "included_file_sha256": included,
                 "new_files": sorted(new_files), "modified_files": sorted(modified_files),
                 "deleted_files": [], "new_physical_solve_count": solve_count,
                 "reused_point_count": 0, "raw_sha256_by_run": run_raw,
                 "associated_raw_sha256_by_run": ({item["run_id"]: item["raw_sha256"] for item in refs}
                                                   if group_name == "runs_metadata" else {}),
                 "excluded_html": context["excluded_html"],
                 "generated_from_head": context["generated_from_head"],
                 "scientific_interpretation_performed": False,
                 "automatic_follow_up": False}
        extra = {"DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2) + "\n").encode(),
                 "README.txt": (f"Incremental BVM 4x4 D3 Carry timing evidence; group={group_name}.\n"
                                "Base checkpoint is A034-A039; A001-A039 raw is referenced by exact SHA and not recopied.\n"
                                "Only A040 and A041 are new physical solves. HTML is excluded.\n"
                                "Mechanical arithmetic only; no event/SFQ classification or scientific interpretation.\n").encode()}
        source_bytes = sum(item["bytes"] for item in records)
        if source_bytes + sum(map(len, extra.values())) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"{group_name} package exceeds Git file-size guard")
        spec = {"name": package_name, "kind": "bvm_4x4_d3_carry_timing_delta_v1", "scope": SERIES,
                "target": target, "qa_path": qa_path, "sources": sources,
                "extra_members": extra, "delta_manifest": delta,
                "base_name": CARRY_D3_TIMING_BASE_PACKAGES[0][1],
                "base_sha": CARRY_D3_TIMING_BASE_PACKAGES[0][2], "raw_by_run": run_raw,
                "package_group": group_name, "run_id": run_id}
        specs.append(spec)
        plans.append({"package": package_name, "file_count": len(records) + len(extra),
                      "uncompressed_source_bytes": source_bytes,
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": run_raw, "new_physical_solve_count": solve_count,
                      "new_files": sorted(new_files), "modified_files": sorted(modified_files),
                      "qa_path": qa_path.relative_to(REPO).as_posix()})
    plan = {"base_commit": CARRY_D3_TIMING_BASE_SOURCE_HEAD,
            "working_tree_diff_start": CARRY_D3_TIMING_PACKAGE_DIFF_START,
            "generated_from_head": context["generated_from_head"],
            "base_packages": base_packages, "referenced_existing_raw_count": len(refs),
            "referenced_existing_raw_sha256": refs, "new_physical_solve_count": 2,
            "reused_point_count": 0, "html_included": False,
            "excluded_html_count": len(context["excluded_html"]),
            "package_count": len(specs), "packages": plans}
    return specs, {"plan": plan, "context": context, "referenced_existing_cases": refs}


def submit_d3_carry_timing_delta(args: argparse.Namespace, root: Any) -> int:
    specs, context = d3_carry_timing_delta_specs(args.tag, root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"BVM package mirror is not accessible: {mirror_dir}")
    collisions = [str(path) for spec in specs for path in (spec["target"], spec["qa_path"])
                  if path.exists()]
    collisions.extend(str(mirror_dir / spec["name"]) for spec in specs if (mirror_dir / spec["name"]).exists())
    if collisions:
        raise FileExistsError("refusing immutable package overwrite: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "package_mode": "D3_CARRY_TIMING_DELTA",
                          **context["plan"], "mirror_dir": str(mirror_dir), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0
    source_head = git("rev-parse", "HEAD")
    package_results = []
    for spec in specs:
        spec["delta_manifest"]["head_commit"] = source_head
        spec["delta_manifest"]["generated_from_head"] = source_head
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(spec["delta_manifest"], ensure_ascii=False, indent=2) + "\n").encode()
        result = root.archive_bundle(spec, source_head)
        archive_path = REPO / result["path"]
        qa_path = REPO / result["qa_path"]
        qa = json.loads(qa_path.read_text(encoding="utf-8"))
        qa.update({"package_mode": "D3_CARRY_TIMING_DELTA", "base_commit": CARRY_D3_TIMING_BASE_SOURCE_HEAD,
                   "head_commit": source_head, "base_package_name": CARRY_D3_TIMING_BASE_PACKAGES[0][1],
                   "base_package_sha256": CARRY_D3_TIMING_BASE_PACKAGES[0][2],
                   "base_delta_packages": CARRY_D3_TIMING_BASE_PACKAGES,
                   "referenced_existing_cases": context["referenced_existing_cases"],
                   "referenced_existing_raw_sha256": context["referenced_existing_cases"],
                   "new_physical_solve_count": spec["delta_manifest"]["new_physical_solve_count"],
                   "reused_point_count": 0, "html_included": False,
                   "package_group": spec["package_group"], "raw_sha256_by_run": spec["raw_by_run"]})
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != root.sha256(archive_path) or
                qa.get("package_bytes") != archive_path.stat().st_size or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"A040/A041 PACKAGE_QA/member integrity failed: {spec['name']}")
        with zipfile.ZipFile(archive_path, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"A040/A041 ZIP CRC failure: {spec['name']}")
            names = archive.namelist()
            if any(name.lower().endswith(".html") for name in names):
                raise RuntimeError(f"HTML must remain local, found in ZIP: {spec['name']}")
            manifest = json.loads(archive.read("DELTA_MANIFEST.json"))
            if manifest.get("head_commit") != source_head:
                raise RuntimeError(f"A040/A041 package head mismatch: {spec['name']}")
            for member, digest in manifest["included_file_sha256"].items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"A040/A041 archive member hash mismatch: {spec['name']}/{member}")
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        package_results.append(result)
    package_paths = [path for item in package_results for path in (item["path"], item["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *package_paths], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive D3 Carry timing A040-A041 DELTA {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "D3_CARRY_TIMING_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_head, "final_commit": git("rev-parse", "HEAD"),
                      "push": push_status, "packages": package_results,
                      "base_commit": CARRY_D3_TIMING_BASE_SOURCE_HEAD,
                      "base_package_name": CARRY_D3_TIMING_BASE_PACKAGES[0][1],
                      "referenced_existing_raw_count": len(context["referenced_existing_cases"]),
                      "new_physical_solve_count": 2, "html_included": False, "mirror": mirror},
                     ensure_ascii=False, indent=2))
    return 0


def d3_manual_supplement_specs(root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("manual D3 supplement requires the master branch")
    head = git("rev-parse", "HEAD")
    remote_head = git("rev-parse", "bvm/master")
    if head != D3_MANUAL_SUPPLEMENT_BASE_COMMIT or remote_head != head:
        raise RuntimeError("manual D3 supplement base is stale; sync master before packaging")

    series_prefix = SERIES.relative_to(REPO).as_posix() + "/"
    run_prefixes = {f"{series_prefix}runs/{run_id}/" for run_id in D3_MANUAL_SUPPLEMENT_RUN_IDS}
    supplement_rel = (D3_MANUAL_SUPPLEMENT_TASK / "SUPPLEMENT_MANIFEST.json").relative_to(REPO).as_posix()
    manifest_rel = (SERIES / "experiment_manifest.json").relative_to(REPO).as_posix()
    submit_rel = Path(__file__).resolve().relative_to(REPO).as_posix()
    allowed_status_paths = {manifest_rel, submit_rel, supplement_rel}
    status_output = subprocess.run(["git", "status", "--porcelain=v1", "--untracked-files=all"],
                                   cwd=REPO, text=True, capture_output=True, check=True).stdout
    status_lines = status_output.splitlines()
    for line in status_lines:
        rel = line[3:]
        if rel.lower().endswith(".html"):
            continue
        if rel not in allowed_status_paths and not any(rel.startswith(prefix) for prefix in run_prefixes):
            raise RuntimeError(f"manual D3 supplement refuses unrelated worktree change: {rel}")
        if not rel.startswith(series_prefix):
            raise RuntimeError(f"manual D3 supplement found out-of-scope change: {rel}")

    staged_before = git("diff", "--cached", "--name-only").splitlines()
    if any(path not in allowed_status_paths and not any(path.startswith(prefix) for prefix in run_prefixes)
           for path in staged_before):
        raise RuntimeError("manual D3 supplement refuses pre-staged out-of-scope changes")

    experiment_manifest_path = SERIES / "experiment_manifest.json"
    experiment_manifest = json.loads(experiment_manifest_path.read_text(encoding="utf-8"))
    if (experiment_manifest.get("maximum_physical_solve_count") != 41 or
            experiment_manifest.get("physical_solve_count") != 44):
        raise RuntimeError("manual supplement metadata must preserve the observed 41/44 manifest discrepancy")
    run_records = {item.get("run_id"): item for item in experiment_manifest.get("runs", [])}
    if not all(run_id in run_records for run_id in D3_MANUAL_SUPPLEMENT_RUN_IDS):
        raise RuntimeError("experiment_manifest is missing one or more A042-A044 records")
    if any(item.get("run_ids") and set(item["run_ids"]) & set(D3_MANUAL_SUPPLEMENT_RUN_IDS)
           for item in experiment_manifest.get("authorization_batches", [])):
        raise RuntimeError("A042-A044 must remain outside the registered authorization batches")
    registered_cases = set(experiment_manifest.get("authorized_physical_solves", []))
    if any(run_records[run_id].get("case") in registered_cases for run_id in D3_MANUAL_SUPPLEMENT_RUN_IDS):
        raise RuntimeError("A042-A044 cases must remain outside the registered authorized case list")
    authorized_d3 = [item for item in experiment_manifest.get("authorization_batches", [])
                     if item.get("batch_id") == "BVM4X4_D3_CARRY_TIMING_20261010"]
    if (len(authorized_d3) != 1 or authorized_d3[0].get("run_ids") != list(CARRY_D3_TIMING_RUN_IDS) or
            authorized_d3[0].get("authorized_physical_solve_count") != 2):
        raise RuntimeError("registered A040/A041 authorization record changed")

    supplement_manifest_path = D3_MANUAL_SUPPLEMENT_TASK / "SUPPLEMENT_MANIFEST.json"
    supplement_manifest = json.loads(supplement_manifest_path.read_text(encoding="utf-8"))
    if (supplement_manifest.get("authorization_status") != "NOT_ASSERTED_BY_PACKAGING" or
            supplement_manifest.get("registered_batch", {}).get("supplement_run_ids_are_members") is not False or
            [item.get("run_id") for item in supplement_manifest.get("runs", [])] !=
            list(D3_MANUAL_SUPPLEMENT_RUN_IDS)):
        raise RuntimeError("supplement manifest does not preserve the non-retroactive authorization boundary")
    supplement_records = {item["run_id"]: item for item in supplement_manifest["runs"]}

    # Verify the immutable A040/A041 package set, then use its metadata package as
    # the lineage source for references A001-A039 and its raw packages for A040/A041.
    base_packages: list[dict[str, Any]] = []
    base_deltas: dict[str, dict[str, Any]] = {}
    for group, name, expected_sha in D3_MANUAL_SUPPLEMENT_BASE_PACKAGES:
        package = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("package_sha256") != expected_sha or
                qa.get("source_commit") != D3_MANUAL_SUPPLEMENT_SOURCE_HEAD or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"A040/A041 base package identity/QA mismatch: {name}")
        with zipfile.ZipFile(package, "r") as archive:
            if archive.testzip() is not None or any(x.lower().endswith(".html") for x in archive.namelist()):
                raise RuntimeError(f"A040/A041 base package CRC or HTML policy failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if delta.get("head_commit") != D3_MANUAL_SUPPLEMENT_SOURCE_HEAD:
                raise RuntimeError(f"A040/A041 base package head mismatch: {name}")
            base_deltas[group] = delta
        base_packages.append({"package_name": name, "package_sha256": expected_sha,
                              "package_group": group, "source_commit": D3_MANUAL_SUPPLEMENT_SOURCE_HEAD,
                              "head_commit": D3_MANUAL_SUPPLEMENT_SOURCE_HEAD})

    old_refs = base_deltas["runs_metadata"].get("referenced_existing_cases", [])
    if len(old_refs) != 39 or len({item.get("run_id") for item in old_refs}) != 39:
        raise RuntimeError("A040/A041 metadata base does not reference exactly A001-A039")
    references = list(old_refs)
    for group in ("A040_raw", "A041_raw"):
        delta = base_deltas[group]
        raw_map = delta.get("raw_sha256_by_run", {})
        if len(raw_map) != 1:
            raise RuntimeError(f"A040/A041 base raw package must identify one run: {group}")
        run_id, raw_sha = next(iter(raw_map.items()))
        references.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                           "raw_sha256": raw_sha,
                           "source_package_name": next(item[1] for item in D3_MANUAL_SUPPLEMENT_BASE_PACKAGES
                                                        if item[0] == group),
                           "source_package_sha256": next(item[2] for item in D3_MANUAL_SUPPLEMENT_BASE_PACKAGES
                                                         if item[0] == group)})
    references.sort(key=lambda item: int(item["run_id"].split("_", 1)[0][1:]))
    if len(references) != 41 or len({item["run_id"] for item in references}) != 41:
        raise RuntimeError("manual supplement base raw reference closure is not exactly A001-A041")
    recorded_raw = {item.get("run_id"): item.get("raw_sha256") for item in experiment_manifest["runs"]}
    if any(recorded_raw.get(item["run_id"]) != item["raw_sha256"] for item in references):
        raise RuntimeError("A001-A041 manifest raw identities disagree with the verified package base")

    run_file_sets: dict[str, list[Path]] = {}
    raw_paths: dict[str, Path] = {}
    metadata_sources: list[tuple[Path, str]] = [
        (experiment_manifest_path, manifest_rel),
        (supplement_manifest_path, supplement_rel),
    ]
    stage_paths = {experiment_manifest_path, supplement_manifest_path, Path(__file__).resolve()}
    for run_id in D3_MANUAL_SUPPLEMENT_RUN_IDS:
        run_dir = RUNS / run_id
        required = {
            "deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt", "USER_CASE.snapshot.env",
            "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env", "CBU_PARAMS.snapshot.env",
            "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env", "stimulus.inc", "case_manifest.json",
            "metadata.json", "provenance.json", "source_manifest.json", "topology_manifest.json",
            "probe_manifest.json", "static_qa.json", "stimulus_manifest.json", "metrics.json", "raw_qa.json",
            "chain_qa.json", "qa.json", "plot_manifest.json", "plot_qa.json", "result.json", "RESULT_BRIEF.md",
        }
        files = sorted(path for path in run_dir.rglob("*") if path.is_file() and not path.is_symlink()
                       and path.suffix.lower() not in {".html", ".pyc", ".tmp", ".zip"}
                       and "__pycache__" not in path.parts and "handoff" not in path.parts)
        if not run_dir.is_dir() or required - {path.name for path in files}:
            raise RuntimeError(f"manual supplement evidence closure incomplete: {run_id}")
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "raw_qa.json").read_text(encoding="utf-8"))
        chain_qa = json.loads((run_dir / "chain_qa.json").read_text(encoding="utf-8"))
        plot_qa = json.loads((run_dir / "plot_qa.json").read_text(encoding="utf-8"))
        raw = run_dir / "raw.csv"
        digest = root.sha256(raw)
        expected_digest = D3_MANUAL_SUPPLEMENT_RAW_SHA256[run_id]
        if (result.get("run_id") != run_id or result.get("artifact_status") != "VALID" or
                result.get("physical_solve_count") != 1 or result.get("solver_exit_code") != 0 or
                result.get("raw_sha256") != expected_digest or digest != expected_digest or
                result.get("raw_bytes") != raw.stat().st_size or qa.get("status") != "PASS" or
                qa.get("raw_sha256_before_analysis") != digest or qa.get("raw_sha256_after_analysis") != digest or
                raw_qa.get("status") != "PASS" or raw_qa.get("raw_sha256_before") != digest or
                raw_qa.get("raw_sha256_after_analysis") != digest or
                chain_qa.get("status") != "PASS" or plot_qa.get("status") != "PASS" or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"manual supplement raw identity or QA failure: {run_id}")
        record = run_records[run_id]
        supplement_record = supplement_records[run_id]
        config = json.loads((run_dir / "metadata.json").read_text(encoding="utf-8")).get("effective_case", {})
        stage_counts = record.get("carry_sjtl_count_by_stage", {})
        stage_counts_text = ",".join(str(stage_counts.get(f"D{index}")) for index in range(1, 7))
        if (record.get("raw_sha256") != digest or record.get("deck_sha256") != result.get("deck_sha256") or
                record.get("physical_solve_count") != 1 or
                supplement_record.get("raw_sha256") != digest or
                supplement_record.get("raw_bytes") != raw.stat().st_size or
                supplement_record.get("deck_sha256") != result.get("deck_sha256") or
                supplement_record.get("stimulus_sha256") != result.get("stimulus_sha256") or
                supplement_record.get("artifact_status") != result.get("artifact_status") or
                supplement_record.get("solver_exit_code") != result.get("solver_exit_code") or
                supplement_record.get("physical_solve_count") != result.get("physical_solve_count") or
                supplement_record.get("row_bits") != result.get("row_bits") or
                supplement_record.get("column_bits") != result.get("column_bits") or
                supplement_record.get("carry_sjtl_count_by_stage") != result.get("carry_sjtl_count_by_stage") or
                supplement_record.get("carry_sjtl_count_by_stage") != stage_counts or
                config.get("CARRY_SJTL_COUNT_BY_STAGE") != stage_counts_text):
            raise RuntimeError(f"manual supplement run does not match experiment_manifest: {run_id}")
        if (config.get("ROW_BITS") != supplement_record["row_bits"] or
                config.get("COL_BITS") != supplement_record["column_bits"] or
                config.get("T1_CHAIN_CLK_START") != supplement_record["clock_start"] or
                supplement_record.get("mechanical_qa_status") != qa.get("status") or
                supplement_record.get("plot_qa_status") != plot_qa.get("status")):
            raise RuntimeError(f"manual supplement manifest/config mismatch: {run_id}")
        for page in plot_qa.get("pages", []):
            page_path = SERIES / page["path"]
            if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
                raise RuntimeError(f"manual supplement standalone HTML QA mismatch: {run_id}/{page.get('path')}")
        run_file_sets[run_id] = files
        raw_paths[run_id] = raw
        stage_paths.update(files)
        for path in files:
            if path != raw:
                metadata_sources.append((path, path.relative_to(REPO).as_posix()))

    source_path = Path(__file__).resolve()
    source_group = [(source_path, source_path.relative_to(REPO).as_posix())]
    metadata_sources.sort(key=lambda item: item[1])
    groups: list[tuple[str, list[tuple[Path, str]], str | None]] = [
        ("source", source_group, None),
        ("runs_metadata", metadata_sources, None),
        *((f"{run_id}_raw", [(raw_paths[run_id], raw_paths[run_id].relative_to(REPO).as_posix())], run_id)
          for run_id in D3_MANUAL_SUPPLEMENT_RUN_IDS),
    ]
    specs: list[dict[str, Any]] = []
    package_plans = []
    for group_name, sources, run_id in groups:
        records = root.file_records(sources)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files, modified_files = [], []
        for member, digest in included.items():
            base_digest = _d3_timing_blob_sha(D3_MANUAL_SUPPLEMENT_BASE_COMMIT, member)
            if base_digest is None:
                new_files.append(member)
            elif base_digest != digest:
                modified_files.append(member)
        raw_by_run = {}
        solve_count = 0
        if run_id:
            raw_by_run[run_id] = D3_MANUAL_SUPPLEMENT_RAW_SHA256[run_id]
            solve_count = 1
        package_name = f"{SERIES.name}_delta_{D3_MANUAL_SUPPLEMENT_TAG}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        delta = {
            "schema": "bvm4x4-manual-supplement-delta-v1",
            "package_type": "manual_supplement_delta",
            "package_group": group_name,
            "base_commit": D3_MANUAL_SUPPLEMENT_SOURCE_HEAD,
            "base_package_name": D3_MANUAL_SUPPLEMENT_BASE_PACKAGES[0][1],
            "base_package_sha256": D3_MANUAL_SUPPLEMENT_BASE_PACKAGES[0][2],
            "base_package_set": [{"package_group": label, "package_name": name, "package_sha256": sha,
                                  "head_commit": D3_MANUAL_SUPPLEMENT_SOURCE_HEAD}
                                 for label, name, sha in D3_MANUAL_SUPPLEMENT_BASE_PACKAGES],
            "head_commit": "PENDING_SOURCE_COMMIT",
            "included_files": records,
            "included_file_sha256": included,
            "new_files": sorted(new_files),
            "modified_files": sorted(modified_files),
            "deleted_files": [],
            "referenced_existing_cases": references,
            "referenced_existing_raw_sha256": references,
            "new_physical_solve_count": solve_count,
            "supplement_physical_solve_count": 3,
            "solver_invocations_this_packaging_task": 0,
            "reused_point_count": 0,
            "raw_sha256_by_run": raw_by_run,
            "authorization_status": "NOT_ASSERTED_BY_PACKAGING",
            "registered_batch_run_ids": list(CARRY_D3_TIMING_RUN_IDS),
            "supplement_run_ids": list(D3_MANUAL_SUPPLEMENT_RUN_IDS),
            "scientific_interpretation_performed": False,
            "automatic_follow_up": False,
            "html_included": False,
        }
        extra = {
            "DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2) + "\n").encode(),
            "README.txt": (
                "Manual supplemental evidence package for A042-A044.\n"
                "These runs are separate from the registered A040/A041 authorization; this package does not "
                "retroactively authorize physical solves.\n"
                "A001-A041 raw is referenced by package identity and SHA-256, never recopied.\n"
                "Generated HTML remains local. This packaging operation ran no solver and performed no "
                "scientific interpretation.\n"
            ).encode(),
        }
        if sum(item["bytes"] for item in records) + sum(map(len, extra.values())) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"manual supplement {group_name} exceeds the ordinary Git size guard")
        specs.append({"name": package_name, "kind": "bvm_4x4_manual_supplement_delta_v1", "scope": SERIES,
                      "target": target, "qa_path": qa_path, "sources": sources,
                      "extra_members": extra, "delta_manifest": delta,
                      "base_name": D3_MANUAL_SUPPLEMENT_BASE_PACKAGES[0][1],
                      "base_sha": D3_MANUAL_SUPPLEMENT_BASE_PACKAGES[0][2],
                      "raw_by_run": raw_by_run, "package_group": group_name, "run_id": run_id})
        package_plans.append({"package": package_name, "file_count": len(records) + len(extra) + 2,
                              "uncompressed_source_bytes": sum(item["bytes"] for item in records),
                              "raw_bytes": sum(item["bytes"] for item in records
                                               if Path(item["archive_path"]).name == "raw.csv"),
                              "raw_sha256_by_run": raw_by_run, "new_physical_solve_count": solve_count,
                              "new_files": sorted(new_files), "modified_files": sorted(modified_files),
                              "qa_path": qa_path.relative_to(REPO).as_posix()})

    allowed_paths = {path.relative_to(REPO).as_posix() for path in stage_paths}
    allowed_paths.update({manifest_rel, submit_rel, supplement_rel})
    return specs, {"plan": {"base_commit": D3_MANUAL_SUPPLEMENT_BASE_COMMIT,
                            "base_source_commit": D3_MANUAL_SUPPLEMENT_SOURCE_HEAD,
                            "pre_commit_head": head, "head_commit": "PENDING_SOURCE_COMMIT",
                            "base_packages": [dict(package_group=label, package_name=name,
                                                    package_sha256=sha, head_commit=D3_MANUAL_SUPPLEMENT_SOURCE_HEAD)
                                              for label, name, sha in D3_MANUAL_SUPPLEMENT_BASE_PACKAGES],
                            "referenced_existing_raw_count": len(references),
                            "new_physical_solve_count": 3, "solver_invocations_this_task": 0,
                            "html_included": False, "package_count": len(specs),
                            "packages": package_plans},
            "stage_paths": sorted(allowed_paths), "references": references,
            "run_file_sets": run_file_sets}


def submit_d3_manual_supplement(args: argparse.Namespace, root: Any) -> int:
    if args.tag != D3_MANUAL_SUPPLEMENT_TAG:
        raise RuntimeError(f"manual D3 supplement tag must be {D3_MANUAL_SUPPLEMENT_TAG}")
    specs, context = d3_manual_supplement_specs(root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"BVM package mirror is not accessible: {mirror_dir}")
    collisions = [str(path) for spec in specs for path in (spec["target"], spec["qa_path"])
                  if path.exists()]
    collisions.extend(str(mirror_dir / spec["name"]) for spec in specs if (mirror_dir / spec["name"]).exists())
    if collisions:
        raise FileExistsError("refusing immutable manual supplement package overwrite: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "package_mode": "MANUAL_SUPPLEMENT_DELTA",
                          **context["plan"], "mirror_dir": str(mirror_dir),
                          "source_paths_to_commit": context["stage_paths"], "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0

    subprocess.run(["git", "add", "-f", "--", *context["stage_paths"]], cwd=REPO, check=True)
    staged = git("diff", "--cached", "--name-only").splitlines()
    if any(path not in set(context["stage_paths"]) for path in staged):
        raise RuntimeError("staging contains a path outside the manual supplement scope")
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO, check=False).returncode == 0:
        raise RuntimeError("manual supplement has no staged evidence changes")
    subprocess.run(["git", "commit", "-m", "evidence: register manual D3 supplement A042-A044"],
                   cwd=REPO, check=True)
    source_head = git("rev-parse", "HEAD")
    package_results = []
    for spec in specs:
        spec["delta_manifest"]["head_commit"] = source_head
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(spec["delta_manifest"], ensure_ascii=False, indent=2) + "\n").encode()
        result = root.archive_bundle(spec, source_head)
        archive_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = root.verify_existing_bundle(archive_path, qa_path)
        if (qa.get("status") != "PASS" or qa.get("source_commit") != source_head or
                qa.get("package_sha256") != root.sha256(archive_path) or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"manual supplement PACKAGE_QA/member integrity failed: {spec['name']}")
        with zipfile.ZipFile(archive_path, "r") as archive:
            if any(name.lower().endswith(".html") for name in archive.namelist()):
                raise RuntimeError(f"HTML must remain local: {spec['name']}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if delta.get("head_commit") != source_head or delta.get("authorization_status") != "NOT_ASSERTED_BY_PACKAGING":
                raise RuntimeError(f"manual supplement delta identity/scope failure: {spec['name']}")
            for member, digest in delta["included_file_sha256"].items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"manual supplement member SHA mismatch: {spec['name']}/{member}")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        package_results.append(result)

    package_paths = [REPO / path for item in package_results for path in (item["path"], item["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *[path.relative_to(REPO).as_posix() for path in package_paths]],
                   cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", "package: archive manual D3 supplement A042-A044 DELTA"],
                   cwd=REPO, check=True)
    subprocess.run(["git", "push"], cwd=REPO, check=True)
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "MANUAL_SUPPLEMENT_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_head, "final_commit": git("rev-parse", "HEAD"),
                      "push": "PASS", "packages": package_results,
                      "base_commit": D3_MANUAL_SUPPLEMENT_BASE_COMMIT,
                      "base_packages": context["plan"]["base_packages"],
                      "referenced_existing_raw_count": len(context["references"]),
                      "supplement_run_ids": list(D3_MANUAL_SUPPLEMENT_RUN_IDS),
                      "supplement_physical_solve_count": 3, "solver_invocations_this_task": 0,
                      "authorization_status": "NOT_ASSERTED_BY_PACKAGING",
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def carry4_manual_supplement_specs(root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("CARRY4 manual supplement requires the master branch")
    head = git("rev-parse", "HEAD")
    if head != CARRY4_SUPPLEMENT_BASE_COMMIT or git("rev-parse", "bvm/master") != head:
        raise RuntimeError("CARRY4 manual supplement base is stale; sync master before packaging")

    series_prefix = SERIES.relative_to(REPO).as_posix() + "/"
    run_prefixes = {f"{series_prefix}runs/{run_id}/" for run_id in CARRY4_SUPPLEMENT_RUN_IDS}
    supplement_rel = (CARRY4_SUPPLEMENT_TASK / "SUPPLEMENT_MANIFEST.json").relative_to(REPO).as_posix()
    manifest_rel = (SERIES / "experiment_manifest.json").relative_to(REPO).as_posix()
    submit_rel = Path(__file__).resolve().relative_to(REPO).as_posix()
    allowed_status_paths = {manifest_rel, submit_rel, supplement_rel}
    status_output = subprocess.run(["git", "status", "--porcelain=v1", "--untracked-files=all"],
                                   cwd=REPO, text=True, capture_output=True, check=True).stdout
    for line in status_output.splitlines():
        rel = line[3:]
        if rel.lower().endswith(".html"):
            continue
        if (rel not in allowed_status_paths and
                not any(rel.startswith(prefix) for prefix in run_prefixes)):
            raise RuntimeError(f"CARRY4 manual supplement refuses unrelated change: {rel}")
        if not rel.startswith(series_prefix):
            raise RuntimeError(f"CARRY4 manual supplement found out-of-scope change: {rel}")
    staged = git("diff", "--cached", "--name-only").splitlines()
    if any(path not in allowed_status_paths and
           not any(path.startswith(prefix) for prefix in run_prefixes) for path in staged):
        raise RuntimeError("CARRY4 manual supplement refuses pre-staged out-of-scope changes")

    experiment_path = SERIES / "experiment_manifest.json"
    experiment = json.loads(experiment_path.read_text(encoding="utf-8"))
    if (experiment.get("maximum_physical_solve_count") != 41 or
            experiment.get("physical_solve_count") != 47):
        raise RuntimeError("CARRY4 supplement requires the observed 41/47 manifest state")
    run_records = {item.get("run_id"): item for item in experiment.get("runs", [])}
    if not all(run_id in run_records for run_id in CARRY4_SUPPLEMENT_RUN_IDS):
        raise RuntimeError("experiment_manifest is missing one or more A045-A047 records")
    case_names = {run_records[run_id].get("case") for run_id in CARRY4_SUPPLEMENT_RUN_IDS}
    if case_names & set(experiment.get("authorized_physical_solves", [])):
        raise RuntimeError("A045-A047 must remain outside the registered authorized-case list")
    if any(set(item.get("run_ids", [])) & set(CARRY4_SUPPLEMENT_RUN_IDS)
           for item in experiment.get("authorization_batches", [])):
        raise RuntimeError("A045-A047 must remain outside registered authorization batches")

    supplement_path = CARRY4_SUPPLEMENT_TASK / "SUPPLEMENT_MANIFEST.json"
    supplement = json.loads(supplement_path.read_text(encoding="utf-8"))
    if (supplement.get("authorization_status") != "NOT_ASSERTED_BY_PACKAGING" or
            [item.get("run_id") for item in supplement.get("runs", [])] !=
            list(CARRY4_SUPPLEMENT_RUN_IDS)):
        raise RuntimeError("CARRY4 supplement manifest authorization boundary or run list mismatch")
    supplement_records = {item["run_id"]: item for item in supplement["runs"]}

    # Verify the prior A042-A044 manual supplement package set and inherit its raw references.
    base_packages, base_deltas = [], {}
    for group, name, expected_sha in CARRY4_SUPPLEMENT_BASE_PACKAGES:
        package = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("package_sha256") != expected_sha or
                qa.get("source_commit") != CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"A042-A044 supplement base identity/QA mismatch: {name}")
        with zipfile.ZipFile(package, "r") as archive:
            if archive.testzip() is not None or any(path.lower().endswith(".html") for path in archive.namelist()):
                raise RuntimeError(f"A042-A044 supplement base CRC/HTML policy failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if (delta.get("head_commit") != CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD or
                    delta.get("authorization_status") != "NOT_ASSERTED_BY_PACKAGING"):
                raise RuntimeError(f"A042-A044 supplement base manifest mismatch: {name}")
            base_deltas[group] = delta
        base_packages.append({"package_group": group, "package_name": name,
                              "package_sha256": expected_sha,
                              "head_commit": CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD})

    references = list(base_deltas["runs_metadata"].get("referenced_existing_cases", []))
    if len(references) != 41:
        raise RuntimeError("A042-A044 base must reference exactly A001-A041")
    for group in ("A042_raw", "A043_raw", "A044_raw"):
        delta = base_deltas[group]
        raw_map = delta.get("raw_sha256_by_run", {})
        if len(raw_map) != 1:
            raise RuntimeError(f"A042-A044 raw package must identify exactly one run: {group}")
        run_id, raw_sha = next(iter(raw_map.items()))
        package_info = next(item for item in CARRY4_SUPPLEMENT_BASE_PACKAGES if item[0] == group)
        references.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                           "raw_sha256": raw_sha, "source_package_name": package_info[1],
                           "source_package_sha256": package_info[2]})
    references.sort(key=lambda item: int(item["run_id"].split("_", 1)[0][1:]))
    if len(references) != 44 or len({item["run_id"] for item in references}) != 44:
        raise RuntimeError("CARRY4 supplement base raw closure is not exactly A001-A044")
    if [int(item["run_id"].split("_", 1)[0][1:]) for item in references] != list(range(1, 45)):
        raise RuntimeError("CARRY4 supplement base raw references are not contiguous A001-A044")
    recorded_raw = {item.get("run_id"): item.get("raw_sha256") for item in experiment.get("runs", [])}
    if any(recorded_raw.get(item["run_id"]) != item["raw_sha256"] for item in references):
        raise RuntimeError("A001-A044 experiment manifest and package raw identities disagree")

    run_files, raw_paths = {}, {}
    stage_paths = {experiment_path, supplement_path, Path(__file__).resolve()}
    metadata_sources: list[tuple[Path, str]] = [
        (experiment_path, manifest_rel), (supplement_path, supplement_rel),
    ]
    for run_id in CARRY4_SUPPLEMENT_RUN_IDS:
        run_dir = RUNS / run_id
        required = {
            "deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt", "USER_CASE.snapshot.env",
            "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env", "CBU_PARAMS.snapshot.env",
            "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env", "stimulus.inc", "case_manifest.json",
            "metadata.json", "provenance.json", "source_manifest.json", "topology_manifest.json",
            "probe_manifest.json", "static_qa.json", "stimulus_manifest.json", "metrics.json", "raw_qa.json",
            "chain_qa.json", "qa.json", "plot_manifest.json", "plot_qa.json", "result.json", "RESULT_BRIEF.md",
        }
        files = sorted(path for path in run_dir.rglob("*") if path.is_file() and not path.is_symlink()
                       and path.suffix.lower() not in {".html", ".pyc", ".tmp", ".zip"}
                       and "__pycache__" not in path.parts and "handoff" not in path.parts)
        if not run_dir.is_dir() or required - {path.name for path in files}:
            raise RuntimeError(f"CARRY4 run evidence closure incomplete: {run_id}")
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "raw_qa.json").read_text(encoding="utf-8"))
        static_qa = json.loads((run_dir / "static_qa.json").read_text(encoding="utf-8"))
        chain_qa = json.loads((run_dir / "chain_qa.json").read_text(encoding="utf-8"))
        plot_qa = json.loads((run_dir / "plot_qa.json").read_text(encoding="utf-8"))
        raw = run_dir / "raw.csv"
        digest = root.sha256(raw)
        expected_sha = CARRY4_SUPPLEMENT_RAW_SHA256[run_id]
        if (result.get("run_id") != run_id or result.get("artifact_status") != "VALID" or
                result.get("physical_solve_count") != 1 or result.get("solver_exit_code") != 0 or
                result.get("raw_sha256") != expected_sha or digest != expected_sha or
                result.get("raw_bytes") != raw.stat().st_size or raw.stat().st_size >= root.MAX_GIT_FILE_BYTES or
                qa.get("status") != "PASS" or qa.get("raw_sha256_before_analysis") != digest or
                qa.get("raw_sha256_after_analysis") != digest or raw_qa.get("status") != "PASS" or
                raw_qa.get("raw_sha256_before") != digest or raw_qa.get("raw_sha256_after_analysis") != digest or
                static_qa.get("status") != "PASS" or chain_qa.get("status") != "PASS" or
                plot_qa.get("status") != "PASS"):
            raise RuntimeError(f"CARRY4 raw identity or QA failure: {run_id}")
        record, supplement_record = run_records[run_id], supplement_records[run_id]
        metadata = json.loads((run_dir / "metadata.json").read_text(encoding="utf-8"))
        config = metadata.get("effective_case", {})
        solver_parent = metadata.get("solver", {}).get("parent_head")
        stage_counts = record.get("carry_sjtl_count_by_stage", {})
        stage_text = ",".join(str(stage_counts.get(f"D{index}")) for index in range(1, 7))
        if (record.get("raw_sha256") != digest or record.get("physical_solve_count") != 1 or
                record.get("deck_sha256") != result.get("deck_sha256") or
                supplement_record.get("raw_sha256") != digest or supplement_record.get("raw_bytes") != raw.stat().st_size or
                supplement_record.get("deck_sha256") != result.get("deck_sha256") or
                supplement_record.get("stimulus_sha256") != result.get("stimulus_sha256") or
                supplement_record.get("carry_sjtl_count_by_stage") != stage_counts or
                supplement_record.get("artifact_status") != result.get("artifact_status") or
                supplement_record.get("mechanical_qa_status") != qa.get("status") or
                supplement_record.get("plot_qa_status") != plot_qa.get("status") or
                supplement_record.get("row_bits") != result.get("row_bits") or
                supplement_record.get("column_bits") != result.get("column_bits") or
                config.get("CARRY_SJTL_COUNT_BY_STAGE") != stage_text or
                config.get("ROW_BITS") != supplement_record.get("row_bits") or
                config.get("COL_BITS") != supplement_record.get("column_bits") or
                config.get("T1_CHAIN_CLK_START") != supplement_record.get("clock_start") or
                solver_parent != CARRY4_SUPPLEMENT_BASE_COMMIT):
            raise RuntimeError(f"CARRY4 supplement run/config mismatch: {run_id}")
        for page in plot_qa.get("pages", []):
            page_path = SERIES / page["path"]
            if not page_path.is_file() or root.sha256(page_path) != page.get("sha256"):
                raise RuntimeError(f"CARRY4 standalone HTML QA mismatch: {run_id}/{page.get('path')}")
        run_files[run_id], raw_paths[run_id] = files, raw
        stage_paths.update(files)
        metadata_sources.extend((path, path.relative_to(REPO).as_posix()) for path in files if path != raw)

    groups: list[tuple[str, list[tuple[Path, str]], str | None]] = [
        ("source", [(Path(__file__).resolve(), submit_rel)], None),
        ("runs_metadata", sorted(metadata_sources, key=lambda item: item[1]), None),
        *((f"{run_id}_raw", [(raw_paths[run_id], raw_paths[run_id].relative_to(REPO).as_posix())], run_id)
          for run_id in CARRY4_SUPPLEMENT_RUN_IDS),
    ]
    specs, plans = [], []
    for group_name, sources, run_id in groups:
        records = root.file_records(sources)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files, modified_files = [], []
        for member, digest in included.items():
            base_digest = _d3_timing_blob_sha(CARRY4_SUPPLEMENT_BASE_COMMIT, member)
            if base_digest is None:
                new_files.append(member)
            elif base_digest != digest:
                modified_files.append(member)
        raw_map, solve_count = {}, 0
        if run_id:
            raw_map[run_id], solve_count = CARRY4_SUPPLEMENT_RAW_SHA256[run_id], 1
        package_name = f"{SERIES.name}_delta_{CARRY4_SUPPLEMENT_TAG}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        delta = {
            "schema": "bvm4x4-manual-supplement-delta-v1",
            "package_type": "manual_supplement_delta",
            "package_group": group_name,
            "base_commit": CARRY4_SUPPLEMENT_BASE_COMMIT,
            "base_source_commit": CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD,
            "base_package_name": CARRY4_SUPPLEMENT_BASE_PACKAGES[0][1],
            "base_package_sha256": CARRY4_SUPPLEMENT_BASE_PACKAGES[0][2],
            "base_package_set": [{"package_group": label, "package_name": name, "package_sha256": sha,
                                  "head_commit": CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD}
                                 for label, name, sha in CARRY4_SUPPLEMENT_BASE_PACKAGES],
            "head_commit": "PENDING_SOURCE_COMMIT",
            "included_files": records,
            "included_file_sha256": included,
            "new_files": sorted(new_files), "modified_files": sorted(modified_files), "deleted_files": [],
            "referenced_existing_cases": references, "referenced_existing_raw_sha256": references,
            "new_physical_solve_count": solve_count, "supplement_physical_solve_count": 3,
            "solver_invocations_this_packaging_task": 0, "reused_point_count": 0,
            "raw_sha256_by_run": raw_map, "authorization_status": "NOT_ASSERTED_BY_PACKAGING",
            "supplement_run_ids": list(CARRY4_SUPPLEMENT_RUN_IDS),
            "scientific_interpretation_performed": False, "automatic_follow_up": False,
            "html_included": False,
        }
        extra = {
            "DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2) + "\n").encode(),
            "README.txt": (
                "Manual supplemental evidence package for A045-A047.\n"
                "These runs are outside the registered authorization batches; packaging makes no retroactive "
                "authorization claim.\n"
                "A001-A044 raw is referenced by package identity and SHA-256, never recopied. HTML remains local.\n"
                "This packaging operation ran no solver and performed no scientific interpretation.\n"
            ).encode(),
        }
        if sum(item["bytes"] for item in records) + sum(map(len, extra.values())) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"CARRY4 {group_name} package exceeds ordinary Git size guard")
        specs.append({"name": package_name, "kind": "bvm_4x4_manual_supplement_delta_v1", "scope": SERIES,
                      "target": target, "qa_path": qa_path, "sources": sources, "extra_members": extra,
                      "delta_manifest": delta, "base_name": CARRY4_SUPPLEMENT_BASE_PACKAGES[0][1],
                      "base_sha": CARRY4_SUPPLEMENT_BASE_PACKAGES[0][2], "raw_by_run": raw_map,
                      "package_group": group_name, "run_id": run_id})
        plans.append({"package": package_name, "file_count": len(records) + len(extra) + 2,
                      "uncompressed_source_bytes": sum(item["bytes"] for item in records),
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                      "new_files": sorted(new_files), "modified_files": sorted(modified_files),
                      "qa_path": qa_path.relative_to(REPO).as_posix()})
    allowed = {path.relative_to(REPO).as_posix() for path in stage_paths}
    return specs, {"plan": {"base_commit": CARRY4_SUPPLEMENT_BASE_COMMIT,
                            "base_source_commit": CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD,
                            "pre_commit_head": head, "head_commit": "PENDING_SOURCE_COMMIT",
                            "referenced_existing_raw_count": len(references),
                            "new_physical_solve_count": 3, "solver_invocations_this_task": 0,
                            "html_included": False, "package_count": len(specs), "packages": plans},
            "stage_paths": sorted(allowed), "references": references}


def submit_carry4_manual_supplement(args: argparse.Namespace, root: Any) -> int:
    if args.tag != CARRY4_SUPPLEMENT_TAG:
        raise RuntimeError(f"CARRY4 manual supplement tag must be {CARRY4_SUPPLEMENT_TAG}")
    specs, context = carry4_manual_supplement_specs(root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"BVM package mirror is not accessible: {mirror_dir}")
    collisions = [str(path) for spec in specs for path in (spec["target"], spec["qa_path"]) if path.exists()]
    collisions.extend(str(mirror_dir / spec["name"]) for spec in specs if (mirror_dir / spec["name"]).exists())
    if collisions:
        raise FileExistsError("refusing immutable CARRY4 package overwrite: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "package_mode": "CARRY4_MANUAL_SUPPLEMENT_DELTA",
                          **context["plan"], "mirror_dir": str(mirror_dir),
                          "source_path_count": len(context["stage_paths"]), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0
    subprocess.run(["git", "add", "-f", "--", *context["stage_paths"]], cwd=REPO, check=True)
    staged = git("diff", "--cached", "--name-only").splitlines()
    if any(path not in set(context["stage_paths"]) for path in staged):
        raise RuntimeError("CARRY4 staging contains a path outside the supplement scope")
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO, check=False).returncode == 0:
        raise RuntimeError("CARRY4 supplement has no staged evidence changes")
    subprocess.run(["git", "commit", "-m", "evidence: register manual CARRY4 supplement A045-A047"],
                   cwd=REPO, check=True)
    source_head = git("rev-parse", "HEAD")
    results = []
    for spec in specs:
        spec["delta_manifest"]["head_commit"] = source_head
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(spec["delta_manifest"], ensure_ascii=False, indent=2) + "\n").encode()
        result = root.archive_bundle(spec, source_head)
        archive_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = root.verify_existing_bundle(archive_path, qa_path)
        if (qa.get("status") != "PASS" or qa.get("source_commit") != source_head or
                qa.get("package_sha256") != root.sha256(archive_path) or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"CARRY4 PACKAGE_QA/member integrity failure: {spec['name']}")
        with zipfile.ZipFile(archive_path, "r") as archive:
            if any(name.lower().endswith(".html") for name in archive.namelist()):
                raise RuntimeError(f"HTML must remain local: {spec['name']}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if (delta.get("head_commit") != source_head or
                    delta.get("authorization_status") != "NOT_ASSERTED_BY_PACKAGING"):
                raise RuntimeError(f"CARRY4 delta identity/scope failure: {spec['name']}")
            for member, digest in delta["included_file_sha256"].items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"CARRY4 ZIP member SHA mismatch: {spec['name']}/{member}")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        results.append(result)
    package_paths = [REPO / path for item in results for path in (item["path"], item["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *[path.relative_to(REPO).as_posix() for path in package_paths]],
                   cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", "package: archive manual CARRY4 supplement A045-A047 DELTA"],
                   cwd=REPO, check=True)
    subprocess.run(["git", "push"], cwd=REPO, check=True)
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "CARRY4_MANUAL_SUPPLEMENT_SUBMIT_COMPLETE",
                      "source_commit": source_head, "final_commit": git("rev-parse", "HEAD"),
                      "push": "PASS", "packages": results,
                      "base_commit": CARRY4_SUPPLEMENT_BASE_COMMIT,
                      "base_source_commit": CARRY4_SUPPLEMENT_BASE_SOURCE_HEAD,
                      "referenced_existing_raw_count": len(context["references"]),
                      "supplement_run_ids": list(CARRY4_SUPPLEMENT_RUN_IDS),
                      "supplement_physical_solve_count": 3, "solver_invocations_this_task": 0,
                      "authorization_status": "NOT_ASSERTED_BY_PACKAGING",
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def c4r28_functional_delta_specs(root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("C4R28 DELTA requires the master branch")
    head = git("rev-parse", "HEAD")
    if head != C4R28_PARENT_HEAD or git("rev-parse", "bvm/master") != head:
        raise RuntimeError("C4R28 DELTA base is stale; sync master before packaging")

    analysis_manifest_path = C4R28_ANALYSIS_DIR / "EVIDENCE_MANIFEST.json"
    summary_qa_path = C4R28_ANALYSIS_DIR / "SUMMARY_QA.json"
    scope_path = C4R28_ANALYSIS_DIR / "ANALYSIS_SCOPE.json"
    evidence = json.loads(analysis_manifest_path.read_text(encoding="utf-8"))
    summary_qa = json.loads(summary_qa_path.read_text(encoding="utf-8"))
    scope = json.loads(scope_path.read_text(encoding="utf-8"))
    if (evidence.get("analysis_id") != C4R28_TAG or evidence.get("parent_head") != C4R28_PARENT_HEAD or
            evidence.get("physical_solver_invocations") != 0 or
            summary_qa.get("case_count") != 28 or summary_qa.get("distinct_input_pair_count") != 28 or
            summary_qa.get("distinct_run_id_count") != 28 or summary_qa.get("physical_solver_invocations") != 0 or
            summary_qa.get("candidate_match_count") != 0 or summary_qa.get("candidate_mismatch_count") != 0 or
            summary_qa.get("candidate_indeterminate_count") != 28 or
            summary_qa.get("all_candidate_decodes_indeterminate") is not True or
            summary_qa.get("status") != "PASS_WITH_INDETERMINATE_CANDIDATE_DECODING" or
            scope.get("authorized_solver_invocations") != 0 or scope.get("parent_head") != C4R28_PARENT_HEAD):
        raise RuntimeError("C4R28 analysis/evidence manifest scope or QA mismatch")
    case_records = evidence.get("run_records", [])
    run_ids = [item.get("run_id") for item in case_records]
    expected_cases = {f"C4R28_210_{a}x{b}" for a, b in C4R28_PAIRS}
    if (len(case_records) != 28 or len(set(run_ids)) != 28 or
            {item.get("case") for item in case_records} != expected_cases):
        raise RuntimeError("C4R28 evidence manifest does not enumerate exactly the 28 unique requested cases")
    analysis_script = C4R28_ANALYSIS_DIR / "analyze_functional_28.py"
    if root.sha256(analysis_script) != evidence.get("analysis_script_sha256"):
        raise RuntimeError("C4R28 analysis script SHA does not match EVIDENCE_MANIFEST")
    if evidence.get("analysis_scope_sha256") != root.sha256(C4R28_ANALYSIS_DIR / "ANALYSIS_SCOPE.json") or \
            evidence.get("preflight_sha256") != root.sha256(C4R28_ANALYSIS_DIR / "PREFLIGHT.md"):
        raise RuntimeError("C4R28 scope/PREFLIGHT SHA mismatch")
    for name, expected_sha in summary_qa.get("analysis_file_sha256", {}).items():
        path = C4R28_ANALYSIS_DIR / name
        if not path.is_file() or root.sha256(path) != expected_sha:
            raise RuntimeError(f"C4R28 analysis output SHA mismatch: {name}")
    for rel, expected_sha in summary_qa.get("figure_sha256", {}).items():
        path = SERIES / rel
        if not path.is_file() or root.sha256(path) != expected_sha:
            raise RuntimeError(f"C4R28 visualization SHA mismatch: {rel}")

    exp_path = SERIES / "experiment_manifest.json"
    experiment = json.loads(exp_path.read_text(encoding="utf-8"))
    if (experiment.get("maximum_physical_solve_count") != 41 or
            experiment.get("physical_solve_count") != 75):
        raise RuntimeError("C4R28 packaging must preserve the observed 41/75 experiment-manifest discrepancy")
    manifest_runs = {item.get("run_id"): item for item in experiment.get("runs", [])}
    authorized_cases = set(experiment.get("authorized_physical_solves", []))
    if any(item["run_id"] not in manifest_runs or manifest_runs[item["run_id"]].get("raw_sha256") != item.get("raw_sha256")
           for item in case_records):
        raise RuntimeError("C4R28 analysis and experiment manifests disagree on a run/raw hash")
    if any(item.get("case") in authorized_cases for item in case_records):
        raise RuntimeError("manual C4R28 cases must remain outside the registered authorized-case list")
    if any(set(batch.get("run_ids", [])) & set(run_ids) for batch in experiment.get("authorization_batches", [])):
        raise RuntimeError("manual C4R28 cases must not be added to a registered authorization batch")

    # Verify the A045-A047 checkpoint as the base, and inherit its A001-A044 references.
    base_package_records, base_deltas = [], {}
    for group, name, expected_sha in C4R28_BASE_PACKAGES:
        package = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("package_sha256") != expected_sha or qa.get("source_commit") != C4R28_BASE_SOURCE_HEAD or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"A045-A047 base package identity/QA mismatch: {name}")
        with zipfile.ZipFile(package, "r") as archive:
            if archive.testzip() is not None or any(member.lower().endswith(".html") for member in archive.namelist()):
                raise RuntimeError(f"A045-A047 base package CRC/HTML policy failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if (delta.get("head_commit") != C4R28_BASE_SOURCE_HEAD or
                    delta.get("authorization_status") != "NOT_ASSERTED_BY_PACKAGING"):
                raise RuntimeError(f"A045-A047 base package manifest mismatch: {name}")
            base_deltas[group] = delta
        base_package_records.append({"package_group": group, "package_name": name,
                                     "package_sha256": expected_sha,
                                     "head_commit": C4R28_BASE_SOURCE_HEAD})

    references = list(base_deltas["runs_metadata"].get("referenced_existing_cases", []))
    if len(references) != 44:
        raise RuntimeError("A045-A047 metadata package must reference exactly A001-A044")
    for group in ("A045_raw", "A046_raw", "A047_raw"):
        delta = base_deltas[group]
        raw_map = delta.get("raw_sha256_by_run", {})
        if len(raw_map) != 1:
            raise RuntimeError(f"A045-A047 raw package must identify exactly one run: {group}")
        run_id, raw_sha = next(iter(raw_map.items()))
        package_info = next(item for item in C4R28_BASE_PACKAGES if item[0] == group)
        references.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                           "raw_sha256": raw_sha, "source_package_name": package_info[1],
                           "source_package_sha256": package_info[2]})
    references.sort(key=lambda item: int(item["run_id"].split("_", 1)[0][1:]))
    if len(references) != 47 or len({item["run_id"] for item in references}) != 47:
        raise RuntimeError("C4R28 base raw closure is not exactly A001-A047")
    if [int(item["run_id"].split("_", 1)[0][1:]) for item in references] != list(range(1, 48)):
        raise RuntimeError("C4R28 base raw references are not contiguous A001-A047")
    manifest_raw = {item.get("run_id"): item.get("raw_sha256") for item in experiment.get("runs", [])}
    if any(manifest_raw.get(item["run_id"]) != item["raw_sha256"] for item in references):
        raise RuntimeError("A001-A047 experiment-manifest hashes disagree with the verified package base")

    # Validate the historical preflight seal and run artifacts without calling the solver.
    manual_dir = SERIES / "manual_batches" / "C4R28_210"
    run_script = SERIES / "run_carry4_functional_28.sh"
    seal = (manual_dir / "preflight.ok").read_text(encoding="utf-8").strip().split("\t")
    if len(seal) != 2 or seal != [root.sha256(run_script), C4R28_PARENT_HEAD]:
        raise RuntimeError("C4R28 preflight.ok does not match the original script SHA and parent HEAD")
    preflight_logs = sorted(manual_dir.glob("preflight_C4R28_210_*.log"))
    if len(preflight_logs) != 28 or any("DRY RUN PASS" not in path.read_text(errors="replace") for path in preflight_logs):
        raise RuntimeError("C4R28 preflight logs are not exactly 28 dry-run PASS files")
    anchor_dir = RUNS / "A045_MANUAL_CARRY4_15x15_210"
    anchor_result = json.loads((anchor_dir / "result.json").read_text(encoding="utf-8"))
    anchor_deck_sha = root.sha256(anchor_dir / "deck.cir")
    if anchor_deck_sha != anchor_result.get("deck_sha256"):
        raise RuntimeError("A045 baseline deck identity mismatch")
    for case_record in case_records:
        run_dir = RUNS / case_record["run_id"]
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "raw_qa.json").read_text(encoding="utf-8"))
        if (result.get("raw_sha256") != case_record.get("raw_sha256") or
                result.get("deck_sha256") != case_record.get("deck_sha256") or
                result.get("artifact_status") != "VALID" or result.get("physical_solve_count") != 1 or
                result.get("solver_exit_code") != 0 or qa.get("status") != "PASS" or
                qa.get("raw_sha256_before_analysis") != case_record.get("raw_sha256") or
                qa.get("raw_sha256_after_analysis") != case_record.get("raw_sha256") or
                raw_qa.get("status") != "PASS" or
                raw_qa.get("raw_sha256_before") != case_record.get("raw_sha256") or
                raw_qa.get("raw_sha256_after_analysis") != case_record.get("raw_sha256")):
            raise RuntimeError(f"C4R28 stored result/QA hashes mismatch: {case_record['run_id']}")
        if root.sha256(run_dir / "deck.cir") != anchor_deck_sha:
            raise RuntimeError(f"C4R28 stored deck differs from A045: {case_record['run_id']}")

    analysis_files = [path for base in (C4R28_ANALYSIS_DIR, C4R28_PLOT_DIR)
                      for path in sorted(base.rglob("*")) if path.is_file() and not path.is_symlink()
                      and path.suffix.lower() not in {".html", ".pyc", ".tmp", ".zip"}
                      and "__pycache__" not in path.parts and "handoff" not in path.parts]
    analysis_sources = [(path, path.relative_to(REPO).as_posix()) for path in analysis_files]
    analysis_sources.extend((path, path.relative_to(REPO).as_posix()) for path in (
        SERIES / "run_carry4_functional_28.sh", SERIES / "scripts" / "submit.py"))
    stage_paths = {path for path, _ in analysis_sources}
    stage_paths.add(exp_path)
    manual_files = sorted(path for path in manual_dir.rglob("*") if path.is_file() and not path.is_symlink()
                          and path.suffix.lower() not in {".html", ".pyc", ".tmp", ".zip"})
    stage_paths.update(manual_files)

    raw_paths: dict[str, Path] = {}
    run_metadata_by_id: dict[str, list[Path]] = {}
    for record in case_records:
        run_id = record["run_id"]
        run_dir = RUNS / run_id
        required = {
            "deck.cir", "raw.csv", "run.log", "stdout.txt", "stderr.txt", "USER_CASE.snapshot.env",
            "STIMULUS.snapshot.env", "T1_PARAMS.snapshot.env", "CBU_PARAMS.snapshot.env",
            "DFF_PARAMS.snapshot.env", "D0_JTL_PARAMS.snapshot.env", "stimulus.inc", "case_manifest.json",
            "metadata.json", "provenance.json", "source_manifest.json", "topology_manifest.json",
            "probe_manifest.json", "static_qa.json", "stimulus_manifest.json", "metrics.json", "raw_qa.json",
            "chain_qa.json", "qa.json", "plot_manifest.json", "plot_qa.json", "result.json", "RESULT_BRIEF.md",
        }
        files = sorted(path for path in run_dir.rglob("*") if path.is_file() and not path.is_symlink()
                       and path.suffix.lower() not in {".html", ".pyc", ".tmp", ".zip"}
                       and "__pycache__" not in path.parts and "handoff" not in path.parts)
        if not run_dir.is_dir() or required - {path.name for path in files}:
            raise RuntimeError(f"C4R28 run evidence closure incomplete: {run_id}")
        result = json.loads((run_dir / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((run_dir / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((run_dir / "raw_qa.json").read_text(encoding="utf-8"))
        if (result.get("artifact_status") != "VALID" or result.get("physical_solve_count") != 1 or
                result.get("qa_status") != "PASS" or qa.get("status") != "PASS" or
                raw_qa.get("status") != "PASS" or result.get("raw_sha256") != record.get("raw_sha256") or
                raw_qa.get("raw_sha256_before") != record.get("raw_sha256") or
                raw_qa.get("raw_sha256_after_analysis") != record.get("raw_sha256") or
                result.get("deck_sha256") != record.get("deck_sha256")):
            raise RuntimeError(f"C4R28 run/result/analysis SHA or QA mismatch: {run_id}")
        if root.sha256(run_dir / "deck.cir") != anchor_deck_sha:
            raise RuntimeError(f"C4R28 deck no longer matches A045 baseline: {run_id}")
        if root.sha256(run_dir / "raw.csv") != record.get("raw_sha256"):
            raise RuntimeError(f"C4R28 raw SHA no longer matches analysis: {run_id}")
        raw_paths[run_id] = run_dir / "raw.csv"
        run_metadata_by_id[run_id] = [path for path in files if path.name != "raw.csv"]
        stage_paths.update(files)

    # Split run metadata only when the uncompressed source closure would approach the Git 100 MB cap.
    metadata_base = [(exp_path, exp_path.relative_to(REPO).as_posix()),
                     *((path, path.relative_to(REPO).as_posix()) for path in manual_files)]
    base_size = sum(path.stat().st_size for path, _ in metadata_base)
    metadata_groups: list[tuple[str, list[tuple[Path, str]], list[str]]] = []
    group_paths: list[tuple[Path, str]] = []
    group_runs: list[str] = []
    group_size = base_size
    for record in case_records:
        run_id = record["run_id"]
        next_paths = [(path, path.relative_to(REPO).as_posix()) for path in run_metadata_by_id[run_id]]
        next_size = sum(path.stat().st_size for path, _ in next_paths)
        if group_runs and group_size + next_size > C4R28_MAX_METADATA_GROUP_BYTES:
            metadata_groups.append((f"runs_metadata_{len(metadata_groups)+1:03d}",
                                    metadata_base + group_paths, list(group_runs)))
            group_paths, group_runs, group_size = [], [], 0
        group_paths.extend(next_paths)
        group_runs.append(run_id)
        group_size += next_size
    if group_runs:
        metadata_groups.append((f"runs_metadata_{len(metadata_groups)+1:03d}",
                                (metadata_base if not metadata_groups else []) + group_paths,
                                list(group_runs)))

    groups: list[tuple[str, list[tuple[Path, str]], list[str], str | None]] = [
        ("source_analysis", analysis_sources, [], None),
        *((name, sources, included_runs, None) for name, sources, included_runs in metadata_groups),
        *((f"{run_id}_raw", [(raw_paths[run_id], raw_paths[run_id].relative_to(REPO).as_posix())],
           [run_id], run_id) for run_id in run_ids),
    ]
    specs, plans = [], []
    for group_name, sources, included_runs, raw_run_id in groups:
        records = root.file_records(sources)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files, modified_files = [], []
        for member, digest in included.items():
            base_digest = _d3_timing_blob_sha(C4R28_PARENT_HEAD, member)
            if base_digest is None:
                new_files.append(member)
            elif base_digest != digest:
                modified_files.append(member)
        raw_map = {}
        solve_count = 0
        if raw_run_id:
            record = next(item for item in case_records if item["run_id"] == raw_run_id)
            if included.get(f"{SERIES.relative_to(REPO).as_posix()}/runs/{raw_run_id}/raw.csv") != record["raw_sha256"]:
                raise RuntimeError(f"C4R28 raw package input SHA mismatch: {raw_run_id}")
            raw_map[raw_run_id] = record["raw_sha256"]
            solve_count = 1
        package_name = f"{SERIES.name}_delta_{C4R28_TAG}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        delta = {
            "schema": "bvm4x4-carry4-functional-28-delta-v1",
            "package_type": "directory_snapshot_delta",
            "package_group": group_name,
            "base_commit": C4R28_BASE_SOURCE_HEAD,
            "base_checkpoint_commit": C4R28_PARENT_HEAD,
            "base_package_name": C4R28_BASE_PACKAGES[0][1],
            "base_package_sha256": C4R28_BASE_PACKAGES[0][2],
            "base_package_set": [{"package_group": label, "package_name": name, "package_sha256": sha,
                                  "head_commit": C4R28_BASE_SOURCE_HEAD}
                                 for label, name, sha in C4R28_BASE_PACKAGES],
            "head_commit": "PENDING_SOURCE_COMMIT",
            "included_files": records, "included_file_sha256": included,
            "new_files": sorted(new_files), "modified_files": sorted(modified_files), "deleted_files": [],
            "referenced_existing_cases": references, "referenced_existing_raw_sha256": references,
            "new_physical_solve_count": solve_count, "batch_physical_solve_count": 28,
            "solver_invocations_this_analysis_and_archive_task": 0, "reused_point_count": 0,
            "raw_sha256_by_run": raw_map, "included_run_ids": included_runs,
            "registered_experiment_maximum_physical_solve_count": 41,
            "observed_experiment_manifest_physical_solve_count": 75,
            "authorization_status": "MANUAL_EVIDENCE_PACKAGED; NO_RETROACTIVE_AUTHORIZATION_CLAIM",
            "candidate_decode_status": "INDETERMINATE; NO_PREREGISTERED_THRESHOLD",
            "candidate_match_count": 0, "candidate_mismatch_count": 0,
            "candidate_indeterminate_count": 28,
            "scientific_interpretation_performed": False, "automatic_follow_up": False,
            "html_included": False,
        }
        extra = {
            "DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2) + "\n").encode(),
            "README.txt": (
                f"C4R28 functional-28 manual evidence DELTA, group={group_name}.\n"
                "The 28 physical runs were already completed manually; this task executed no solver.\n"
                "A001-A047 raw is referenced by exact package/raw SHA and is not recopied.\n"
                "Product-bit candidate classification is INDETERMINATE because no decode threshold was preregistered.\n"
                "No scientific interpretation is included. HTML remains local.\n"
            ).encode(),
        }
        source_bytes = sum(item["bytes"] for item in records) + sum(map(len, extra.values()))
        if source_bytes >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"C4R28 {group_name} exceeds Git uncompressed-size guard; reduce/split the group")
        specs.append({"name": package_name, "kind": "bvm4x4_carry4_functional_28_delta_v1", "scope": SERIES,
                      "target": target, "qa_path": qa_path, "sources": sources, "extra_members": extra,
                      "delta_manifest": delta, "base_name": C4R28_BASE_PACKAGES[0][1],
                      "base_sha": C4R28_BASE_PACKAGES[0][2], "raw_by_run": raw_map,
                      "package_group": group_name, "run_id": raw_run_id})
        plans.append({"package": package_name, "file_count": len(records) + len(extra) + 2,
                      "uncompressed_source_bytes": sum(item["bytes"] for item in records),
                      "raw_bytes": sum(item["bytes"] for item in records if Path(item["archive_path"]).name == "raw.csv"),
                      "included_run_count": len(included_runs), "raw_sha256_by_run": raw_map,
                      "new_physical_solve_count": solve_count, "new_files": sorted(new_files),
                      "modified_files": sorted(modified_files), "qa_path": qa_path.relative_to(REPO).as_posix()})

    allowed_paths = {path.relative_to(REPO).as_posix() for path in stage_paths}
    return specs, {"plan": {"analysis_id": C4R28_TAG, "base_commit": C4R28_PARENT_HEAD,
                            "base_source_commit": C4R28_BASE_SOURCE_HEAD,
                            "pre_commit_head": head, "head_commit": "PENDING_SOURCE_COMMIT",
                            "base_packages": [{"package_group": group, "package_name": name,
                                               "package_sha256": sha, "head_commit": C4R28_BASE_SOURCE_HEAD}
                                              for group, name, sha in C4R28_BASE_PACKAGES],
                            "referenced_existing_raw_count": len(references),
                            "new_physical_solve_count": 28, "solver_invocations_this_task": 0,
                            "candidate_counts": {"match": 0, "mismatch": 0, "indeterminate": 28},
                            "html_included": False, "package_count": len(specs), "packages": plans},
            "stage_paths": sorted(allowed_paths), "references": references,
            "run_ids": run_ids}


def submit_c4r28_functional_delta(args: argparse.Namespace, root: Any) -> int:
    if args.tag != C4R28_TAG:
        raise RuntimeError(f"C4R28 DELTA tag must be {C4R28_TAG}")
    specs, context = c4r28_functional_delta_specs(root)
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"BVM package mirror is not accessible: {mirror_dir}")
    collisions = [str(path) for spec in specs for path in (spec["target"], spec["qa_path"]) if path.exists()]
    collisions.extend(str(mirror_dir / spec["name"]) for spec in specs if (mirror_dir / spec["name"]).exists())
    if collisions:
        raise FileExistsError("refusing immutable C4R28 package overwrite: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", "package_mode": "C4R28_FUNCTIONAL_DELTA",
                          **context["plan"], "mirror_dir": str(mirror_dir),
                          "source_path_count": len(context["stage_paths"]), "no_files_modified": True},
                         ensure_ascii=False, indent=2))
        return 0
    subprocess.run(["git", "add", "-f", "--", *context["stage_paths"]], cwd=REPO, check=True)
    staged = git("diff", "--cached", "--name-only").splitlines()
    if any(path not in set(context["stage_paths"]) for path in staged):
        raise RuntimeError("C4R28 staging contains a path outside the registered analysis/archive scope")
    if subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=REPO, check=False).returncode == 0:
        raise RuntimeError("C4R28 has no staged evidence changes")
    subprocess.run(["git", "commit", "-m", "evidence: add C4R28 manual functional analysis"],
                   cwd=REPO, check=True)
    source_head = git("rev-parse", "HEAD")
    results = []
    for spec in specs:
        spec["delta_manifest"]["head_commit"] = source_head
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(spec["delta_manifest"], ensure_ascii=False, indent=2) + "\n").encode()
        result = root.archive_bundle(spec, source_head)
        archive_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = root.verify_existing_bundle(archive_path, qa_path)
        if (qa.get("status") != "PASS" or qa.get("source_commit") != source_head or
                qa.get("package_sha256") != root.sha256(archive_path) or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"C4R28 PACKAGE_QA/member integrity failure: {spec['name']}")
        with zipfile.ZipFile(archive_path, "r") as archive:
            if any(name.lower().endswith(".html") for name in archive.namelist()):
                raise RuntimeError(f"HTML must remain local: {spec['name']}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if (delta.get("head_commit") != source_head or delta.get("authorization_status") !=
                    "MANUAL_EVIDENCE_PACKAGED; NO_RETROACTIVE_AUTHORIZATION_CLAIM"):
                raise RuntimeError(f"C4R28 DELTA scope/head failure: {spec['name']}")
            for member, digest in delta["included_file_sha256"].items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"C4R28 ZIP member SHA mismatch: {spec['name']}/{member}")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"], "status": qa["status"]})
        results.append(result)
    package_paths = [REPO / path for item in results for path in (item["path"], item["qa_path"])]
    subprocess.run(["git", "add", "-f", "--", *[path.relative_to(REPO).as_posix() for path in package_paths]],
                   cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive C4R28 functional DELTA {args.tag}"],
                   cwd=REPO, check=True)
    subprocess.run(["git", "push"], cwd=REPO, check=True)
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "C4R28_FUNCTIONAL_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_head, "final_commit": git("rev-parse", "HEAD"),
                      "push": "PASS", "packages": results,
                      "base_commit": C4R28_PARENT_HEAD, "base_source_commit": C4R28_BASE_SOURCE_HEAD,
                      "referenced_existing_raw_count": len(context["references"]),
                      "included_run_ids": context["run_ids"], "existing_physical_solve_count": 28,
                      "solver_invocations_this_task": 0,
                      "candidate_counts": {"match": 0, "mismatch": 0, "indeterminate": 28},
                      "authorization_status": "MANUAL_EVIDENCE_PACKAGED; NO_RETROACTIVE_AUTHORIZATION_CLAIM",
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def _manual_run_blob_sha(commit: str, path: str) -> str | None:
    exists = subprocess.run(["git", "cat-file", "-e", f"{commit}:{path}"], cwd=REPO,
                            check=False, capture_output=True)
    if exists.returncode:
        return None
    data = subprocess.run(["git", "show", f"{commit}:{path}"], cwd=REPO,
                          check=True, capture_output=True).stdout
    return hashlib.sha256(data).hexdigest()


def _verify_manual_checkpoint_blobs(package_set: list[dict[str, Any]], checkpoint_commit: str) -> None:
    for item in package_set:
        for name in (item["package_name"], f"{Path(item['package_name']).stem}_PACKAGE_QA.json"):
            rel = (HANDOFF / name).relative_to(REPO).as_posix()
            committed = subprocess.run(["git", "rev-parse", f"{checkpoint_commit}:{rel}"],
                                       cwd=REPO, text=True, capture_output=True, check=False)
            current = subprocess.run(["git", "hash-object", rel], cwd=REPO, text=True,
                                      capture_output=True, check=True).stdout.strip()
            if committed.returncode != 0 or committed.stdout.strip() != current:
                raise RuntimeError(f"checkpoint file differs from its committed identity: {rel}")


def _verify_manual_checkpoint_packages(root: Any, package_set: list[dict[str, Any]],
                                       checkpoint_commit: str | None = None) -> None:
    if not package_set:
        raise RuntimeError("manual-run checkpoint has an empty package set")
    for item in package_set:
        name = item.get("package_name")
        expected_sha = item.get("package_sha256")
        if not isinstance(name, str) or not isinstance(expected_sha, str):
            raise RuntimeError("manual-run checkpoint package identity is malformed")
        package = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("status") != "PASS" or qa.get("package_sha256") != expected_sha or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"manual-run checkpoint package identity/QA mismatch: {name}")
    if checkpoint_commit:
        _verify_manual_checkpoint_blobs(package_set, checkpoint_commit)


def _manual_c4r28_bootstrap_checkpoint(root: Any, head: str) -> dict[str, Any]:
    """Build the first generic manual-run base from the already verified C4R28 checkpoint."""
    if head != C4R28_PACKAGE_FINAL_HEAD:
        raise RuntimeError("manual-run checkpoint registry is absent and HEAD is not the registered C4R28 package HEAD")
    evidence_path = C4R28_ANALYSIS_DIR / "EVIDENCE_MANIFEST.json"
    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    run_records = evidence.get("run_records", [])
    c4r28_ids = [item.get("run_id") for item in run_records]
    expected_ids = [f"A{i:03d}_C4R28_210_{a}x{b}" for i, (a, b) in
                    enumerate(C4R28_PAIRS, start=48)]
    if len(c4r28_ids) != 28 or c4r28_ids != expected_ids:
        raise RuntimeError("C4R28 base evidence does not enumerate the registered A048-A075 run set")

    package_names = [
        f"{SERIES.name}_delta_{C4R28_TAG}_source_analysis.zip",
        f"{SERIES.name}_delta_{C4R28_TAG}_runs_metadata_001.zip",
        f"{SERIES.name}_delta_{C4R28_TAG}_runs_metadata_002.zip",
        *(f"{SERIES.name}_delta_{C4R28_TAG}_{run_id}_raw.zip" for run_id in c4r28_ids),
    ]
    package_set = []
    package_qas = {}
    for index, name in enumerate(package_names):
        package = HANDOFF / name
        qa_path = HANDOFF / f"{Path(name).stem}_PACKAGE_QA.json"
        qa = root.verify_existing_bundle(package, qa_path)
        if (qa.get("status") != "PASS" or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True or
                qa.get("package_sha256") != root.sha256(package) or
                qa.get("package_bytes") != package.stat().st_size):
            raise RuntimeError(f"C4R28 bootstrap package identity/member QA mismatch: {name}")
        if package_set and qa.get("source_commit") != package_set[0]["source_commit"]:
            raise RuntimeError(f"C4R28 package set is split across source commits: {name}")
        group = ("source_analysis" if index == 0 else
                 f"runs_metadata_{index:03d}" if index <= 2 else c4r28_ids[index - 3])
        package_set.append({"package_group": group, "package_name": name,
                            "package_sha256": qa["package_sha256"],
                            "package_bytes": qa["package_bytes"],
                            "source_commit": qa["source_commit"]})
        package_qas[name] = qa

    metadata_refs = []
    c4r28_source_commit = package_set[0]["source_commit"]
    for name in package_names[1:3]:
        with zipfile.ZipFile(HANDOFF / name, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f"C4R28 metadata base ZIP CRC failure: {name}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
        if (delta.get("head_commit") != c4r28_source_commit or
                delta.get("authorization_status") !=
                "MANUAL_EVIDENCE_PACKAGED; NO_RETROACTIVE_AUTHORIZATION_CLAIM"):
            raise RuntimeError(f"C4R28 metadata base lineage/scope mismatch: {name}")
        refs = delta.get("referenced_existing_raw_sha256", [])
        if len(refs) != 47:
            raise RuntimeError(f"C4R28 metadata base should reference 47 existing raws: {name}")
        if metadata_refs and refs != metadata_refs:
            raise RuntimeError("C4R28 metadata package groups disagree on their inherited raw references")
        metadata_refs = refs
    older_numbers = sorted(int(item.get("run_id", "A000").split("_", 1)[0][1:])
                           for item in metadata_refs)
    if older_numbers != list(range(1, 48)) or len({item.get("run_id") for item in metadata_refs}) != 47:
        raise RuntimeError("C4R28 base does not provide a unique A001-A047 raw-reference closure")

    references = list(metadata_refs)
    for run_id in c4r28_ids:
        name = f"{SERIES.name}_delta_{C4R28_TAG}_{run_id}_raw.zip"
        qa = package_qas[name]
        raw_map = qa.get("raw_sha256_by_run", {})
        raw_sha = raw_map.get(run_id)
        raw_member_hashes = [digest for member, digest in qa.get("included_file_sha256", {}).items()
                             if member.endswith(f"/runs/{run_id}/raw.csv")]
        if (set(raw_map) != {run_id} or len(raw_member_hashes) != 1 or
                raw_member_hashes[0] != raw_sha):
            raise RuntimeError(f"C4R28 base raw-package identity/member hash mismatch: {run_id}")
        references.append({"run_id": run_id, "raw_path": f"runs/{run_id}/raw.csv",
                           "raw_sha256": raw_sha, "source_package_name": name,
                           "source_package_sha256": qa["package_sha256"]})

    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    manifest_raw = {item.get("run_id"): item.get("raw_sha256") for item in manifest.get("runs", [])}
    reference_ids = {item.get("run_id") for item in references}
    reference_numbers = sorted(int(run_id.split("_", 1)[0][1:]) for run_id in reference_ids)
    if len(references) != 75 or len(reference_ids) != 75 or reference_numbers != list(range(1, 76)):
        raise RuntimeError("C4R28 checkpoint raw closure is not exactly A001-A075")
    if any(manifest_raw.get(item["run_id"]) != item["raw_sha256"] for item in references):
        raise RuntimeError("C4R28 checkpoint raw references disagree with experiment_manifest.json")
    _verify_manual_checkpoint_blobs(package_set, C4R28_PACKAGE_FINAL_HEAD)

    return {"tag": C4R28_TAG, "base_commit": C4R28_PACKAGE_FINAL_HEAD,
            "source_commit": c4r28_source_commit, "checkpoint_commit": C4R28_PACKAGE_FINAL_HEAD,
            "package_set": package_set, "run_ids": sorted(reference_ids),
            "all_raw_references": sorted(references, key=lambda item: int(item["run_id"].split("_", 1)[0][1:]))}


def _manual_run_base_checkpoint(root: Any, head: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    registry_path = MANUAL_RUN_CHECKPOINTS_PATH
    if not registry_path.is_file():
        checkpoint = _manual_c4r28_bootstrap_checkpoint(root, head)
        return checkpoint, [checkpoint]

    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    if registry.get("schema") != "bvm4x4-manual-run-delta-checkpoints-v1":
        raise RuntimeError("manual-run checkpoint registry schema mismatch")
    checkpoints = registry.get("checkpoints", [])
    if not checkpoints:
        raise RuntimeError("manual-run checkpoint registry is empty")
    checkpoint = checkpoints[-1]
    if (not checkpoint.get("package_set") or not checkpoint.get("all_raw_references") or
            not checkpoint.get("run_ids")):
        raise RuntimeError("latest manual-run checkpoint is incomplete")
    checkpoint_commit = subprocess.run(
        ["git", "log", "-1", "--format=%H", "--",
         registry_path.relative_to(REPO).as_posix()], cwd=REPO, text=True,
        capture_output=True, check=True).stdout.strip()
    if not checkpoint_commit or subprocess.run(
            ["git", "merge-base", "--is-ancestor", checkpoint_commit, head],
            cwd=REPO, check=False).returncode != 0:
        raise RuntimeError("latest manual-run checkpoint commit is not an ancestor of current HEAD")
    _verify_manual_checkpoint_packages(root, checkpoint["package_set"], checkpoint_commit)

    references = checkpoint["all_raw_references"]
    run_ids = checkpoint["run_ids"]
    if (len(references) != len(run_ids) or len({item.get("run_id") for item in references}) != len(references) or
            set(run_ids) != {item.get("run_id") for item in references}):
        raise RuntimeError("latest manual-run checkpoint raw-reference closure is ambiguous")
    current_manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    manifest_raw = {item.get("run_id"): item.get("raw_sha256") for item in current_manifest.get("runs", [])}
    if any(manifest_raw.get(item["run_id"]) != item.get("raw_sha256") for item in references):
        raise RuntimeError("manual-run checkpoint raw identities disagree with experiment_manifest.json")
    return checkpoint, checkpoints


def _manual_run_pending_ids(checkpoint: dict[str, Any]) -> tuple[list[str], list[str]]:
    manifest = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    known = set(checkpoint["run_ids"])
    pending_rows = [item for item in manifest.get("runs", []) if item.get("run_id") not in known]
    manual = sorted((item.get("run_id") for item in pending_rows if item.get("batch_id") is None),
                    key=lambda rid: int(rid.split("_", 1)[0][1:]) if isinstance(rid, str) else 0)
    registered = sorted(item.get("run_id") for item in pending_rows if item.get("batch_id") is not None)
    if any(not isinstance(run_id, str) or not re.fullmatch(r"A\d{3}_[A-Za-z0-9_.-]+", run_id)
           for run_id in manual):
        raise RuntimeError("new manual run ID is malformed")
    return manual, registered


def _manual_run_pending_for_auto_route() -> bool:
    """Avoid sending an unregistered manual run into an unrelated fixed --delta branch."""
    manifest_path = SERIES / "experiment_manifest.json"
    if not manifest_path.is_file():
        return False
    registry_path = MANUAL_RUN_CHECKPOINTS_PATH
    if registry_path.is_file():
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
        checkpoints = registry.get("checkpoints", [])
        if not checkpoints:
            raise RuntimeError("manual-run checkpoint registry is empty")
        known = set(checkpoints[-1].get("run_ids", []))
    else:
        if git("rev-parse", "HEAD") != C4R28_PACKAGE_FINAL_HEAD:
            return False
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        known = {item.get("run_id") for item in manifest.get("runs", [])
                 if isinstance(item.get("run_id"), str) and
                 item["run_id"].startswith("A") and
                 item["run_id"].split("_", 1)[0][1:].isdigit() and
                 int(item["run_id"].split("_", 1)[0][1:]) <= 75}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    return any(item.get("run_id") not in known and item.get("batch_id") is None
               for item in manifest.get("runs", []))


def _manual_run_file_set(run_id: str) -> tuple[list[Path], Path]:
    run_dir = RUNS / run_id
    if not run_dir.is_dir():
        raise RuntimeError(f"manual run directory is missing: {run_id}")
    files = sorted(path for path in run_dir.rglob("*") if path.is_file() and not path.is_symlink()
                   and path.suffix.lower() not in {".html", ".pyc", ".tmp", ".zip"}
                   and "__pycache__" not in path.parts and "handoff" not in path.parts)
    missing = MANUAL_RUN_REQUIRED_FILES - {path.name for path in files}
    raw = run_dir / "raw.csv"
    if missing or not raw.is_file() or raw.is_symlink():
        raise RuntimeError(f"manual run evidence closure incomplete for {run_id}; missing={sorted(missing)}")
    return files, raw


def manual_run_delta_specs(tag: str, root: Any) -> tuple[list[dict[str, Any]], dict[str, Any]] | None:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", tag):
        raise RuntimeError("manual-run DELTA tag must be 1-80 safe filename characters")
    if git("branch", "--show-current") != "master":
        raise RuntimeError("manual-run DELTA requires the master branch")
    head = git("rev-parse", "HEAD")
    if git("rev-parse", "bvm/master") != head:
        raise RuntimeError("manual-run DELTA requires local master to match bvm/master")
    if git("diff", "--cached", "--name-only"):
        raise RuntimeError("manual-run DELTA refuses pre-staged changes")

    checkpoint, checkpoint_history = _manual_run_base_checkpoint(root, head)
    manual_ids, registered_ids = _manual_run_pending_ids(checkpoint)
    if not manual_ids:
        return None
    if registered_ids:
        raise RuntimeError("pending registered-batch runs are mixed with manual runs; package the registered batch first: " +
                           ", ".join(registered_ids))

    manifest_path = SERIES / "experiment_manifest.json"
    manifest_rel = manifest_path.relative_to(REPO).as_posix()
    script_path = Path(__file__).resolve()
    script_rel = script_path.relative_to(REPO).as_posix()
    readme_path = SERIES / "README.md"
    readme_rel = readme_path.relative_to(REPO).as_posix()
    current_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    base_manifest_bytes = subprocess.run(["git", "show", f"{head}:{manifest_rel}"], cwd=REPO,
                                         capture_output=True, check=True).stdout
    base_manifest = json.loads(base_manifest_bytes)
    expected_count = int(base_manifest.get("physical_solve_count", -1)) + len(manual_ids)
    if int(current_manifest.get("physical_solve_count", -2)) != expected_count:
        raise RuntimeError("experiment_manifest physical_solve_count does not increase by exactly the pending manual run count")

    base_raw_refs = checkpoint["all_raw_references"]
    base_raw_by_id = {item["run_id"]: item["raw_sha256"] for item in base_raw_refs}
    current_rows = {item.get("run_id"): item for item in current_manifest.get("runs", [])}
    base_rows = {item.get("run_id"): item for item in base_manifest.get("runs", [])}
    if any(base_raw_by_id.get(run_id) != row.get("raw_sha256") for run_id, row in base_rows.items()
           if run_id in base_raw_by_id):
        raise RuntimeError("a previously checkpointed raw identity changed in the current experiment manifest")

    all_run_files: dict[str, list[Path]] = {}
    raw_paths: dict[str, Path] = {}
    new_raw_by_run: dict[str, str] = {}
    evidence_paths: set[Path] = {manifest_path}
    for run_id in manual_ids:
        files, raw = _manual_run_file_set(run_id)
        result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((RUNS / run_id / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((RUNS / run_id / "raw_qa.json").read_text(encoding="utf-8"))
        static_qa = json.loads((RUNS / run_id / "static_qa.json").read_text(encoding="utf-8"))
        chain_qa = json.loads((RUNS / run_id / "chain_qa.json").read_text(encoding="utf-8"))
        plot_qa = json.loads((RUNS / run_id / "plot_qa.json").read_text(encoding="utf-8"))
        metadata = json.loads((RUNS / run_id / "metadata.json").read_text(encoding="utf-8"))
        row = current_rows.get(run_id)
        digest = root.sha256(raw)
        if (not row or result.get("run_id") != run_id or row.get("run_id") != run_id or
                result.get("physical_solve_count") != 1 or result.get("solver_exit_code") != 0 or
                result.get("artifact_status") != "VALID" or result.get("qa_status") != "PASS" or
                result.get("raw_sha256") != digest or result.get("raw_bytes") != raw.stat().st_size or
                row.get("raw_sha256") != digest or row.get("deck_sha256") != result.get("deck_sha256") or
                row.get("physical_solve_count") != 1 or qa.get("status") != "PASS" or
                qa.get("raw_sha256_before_analysis") != digest or qa.get("raw_sha256_after_analysis") != digest or
                raw_qa.get("status") != "PASS" or raw_qa.get("raw_sha256_before") != digest or
                raw_qa.get("raw_sha256_after_analysis") != digest or static_qa.get("status") != "PASS" or
                chain_qa.get("status") != "PASS" or plot_qa.get("status") != "PASS" or
                metadata.get("solver", {}).get("parent_head") != head or
                raw.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"manual run result/raw/QA/provenance identity failure: {run_id}")
        all_run_files[run_id], raw_paths[run_id] = files, raw
        new_raw_by_run[run_id] = digest
        evidence_paths.update(path for path in files if path != raw)

    base_registry_ids = set(checkpoint["run_ids"])
    untracked_run_dirs = {path.name for path in RUNS.iterdir() if path.is_dir() and path.name.startswith("A")
                          and path.name not in base_registry_ids and path.name not in manual_ids}
    if untracked_run_dirs:
        raise RuntimeError("new run directories are not registered for this manual DELTA: " +
                           ", ".join(sorted(untracked_run_dirs)))

    workflow_paths = []
    for path, relpath in ((script_path, script_rel), (readme_path, readme_rel)):
        if _manual_run_blob_sha(head, relpath) != root.sha256(path):
            workflow_paths.append((path, relpath))
    workflow_sha256 = {relpath: root.sha256(path) for path, relpath in workflow_paths}
    base_metadata_sources = [(manifest_path, manifest_rel), *workflow_paths]
    base_metadata_bytes = sum(path.stat().st_size for path, _member in base_metadata_sources)
    if base_metadata_bytes >= MANUAL_RUN_METADATA_GROUP_BYTES:
        raise RuntimeError("manual-run manifest/workflow metadata exceeds the package group size limit")
    run_metadata_sources = {
        run_id: [(path, path.relative_to(REPO).as_posix()) for path in all_run_files[run_id]
                 if path != raw_paths[run_id]]
        for run_id in manual_ids
    }
    metadata_groups: list[tuple[str, list[tuple[Path, str]], list[str]]] = []
    pending_metadata: list[tuple[Path, str]] = []
    pending_run_ids: list[str] = []
    pending_bytes = base_metadata_bytes
    for run_id in manual_ids:
        next_sources = run_metadata_sources[run_id]
        next_bytes = sum(path.stat().st_size for path, _member in next_sources)
        if next_bytes >= MANUAL_RUN_METADATA_GROUP_BYTES:
            raise RuntimeError(f"single manual run metadata exceeds the package group limit: {run_id}")
        if pending_run_ids and pending_bytes + next_bytes >= MANUAL_RUN_METADATA_GROUP_BYTES:
            group_no = len(metadata_groups) + 1
            metadata_groups.append((f"runs_metadata_{group_no:03d}",
                                   (base_metadata_sources if group_no == 1 else []) + pending_metadata,
                                   list(pending_run_ids)))
            pending_metadata, pending_run_ids, pending_bytes = [], [], 0
        pending_metadata.extend(next_sources)
        pending_run_ids.append(run_id)
        pending_bytes += next_bytes
    if pending_run_ids:
        group_no = len(metadata_groups) + 1
        metadata_groups.append((f"runs_metadata_{group_no:03d}",
                               (base_metadata_sources if group_no == 1 else []) + pending_metadata,
                               list(pending_run_ids)))
    raw_sources = {run_id: [(path, path.relative_to(REPO).as_posix())]
                   for run_id, path in raw_paths.items()}

    prior_packages = checkpoint["package_set"]
    base_package = prior_packages[0]
    references = sorted(base_raw_refs, key=lambda item: int(item["run_id"].split("_", 1)[0][1:]))
    groups: list[tuple[str, list[tuple[Path, str]], str | None, list[str]]] = [
        *((name, sources, None, included_runs) for name, sources, included_runs in metadata_groups),
        *((f"{run_id}_raw", raw_sources[run_id], run_id, [run_id]) for run_id in manual_ids),
    ]
    specs, plans = [], []
    for group_name, sources, run_id, included_run_ids in groups:
        records = root.file_records(sources)
        included = {item["archive_path"]: item["sha256"] for item in records}
        new_files, modified_files = [], []
        for member, digest in included.items():
            old_digest = _manual_run_blob_sha(head, member)
            if old_digest is None:
                new_files.append(member)
            elif old_digest != digest:
                modified_files.append(member)
        raw_map = {run_id: new_raw_by_run[run_id]} if run_id else {}
        solve_count = 1 if run_id else 0
        package_name = f"{SERIES.name}_delta_{tag}_{group_name}.zip"
        target = HANDOFF / package_name
        qa_path = HANDOFF / f"{Path(package_name).stem}_PACKAGE_QA.json"
        delta = {
            "schema": "bvm4x4-manual-run-delta-v1", "package_type": "manual_run_delta",
            "tag": tag, "package_group": group_name, "base_commit": head,
            "base_checkpoint_tag": checkpoint["tag"],
            "base_package_name": base_package["package_name"],
            "base_package_sha256": base_package["package_sha256"],
            "base_package_set": prior_packages, "base_run_packages": base_raw_refs,
            "head_commit": "PENDING_SOURCE_COMMIT", "workflow_file_sha256": workflow_sha256,
            "included_files": records, "included_file_sha256": included,
            "new_files": sorted(new_files), "modified_files": sorted(modified_files), "deleted_files": [],
            "referenced_existing_cases": references,
            "referenced_existing_raw_sha256": references,
            "raw_sha256_by_run": raw_map, "new_run_ids": manual_ids,
            "included_run_ids": included_run_ids,
            "new_raw_sha256_by_run": new_raw_by_run,
            "new_physical_solve_count": solve_count,
            "batch_physical_solve_count": len(manual_ids), "solver_invocations_this_task": 0,
            "reused_point_count": 0, "authorization_status": "NOT_ASSERTED_BY_PACKAGING",
            "scientific_interpretation_performed": False, "automatic_follow_up": False,
            "html_included": False,
        }
        extra = {
            "DELTA_MANIFEST.json": (json.dumps(delta, ensure_ascii=False, indent=2) + "\n").encode(),
            "README.txt": (f"Manual-run DELTA package for {', '.join(manual_ids)}.\n"
                           "Previously checkpointed raw files are referenced by exact package and raw SHA-256; "
                           "they are not recopied.\nGenerated HTML remains local. No solver or scientific "
                           "interpretation was performed by this packaging task.\n").encode(),
        }
        if sum(item["bytes"] for item in records) + sum(map(len, extra.values())) >= root.MAX_GIT_FILE_BYTES:
            raise RuntimeError(f"manual-run package exceeds the ordinary Git size guard: {package_name}")
        specs.append({"name": package_name, "kind": "bvm4x4_manual_run_delta_v1", "scope": SERIES,
                      "target": target, "qa_path": qa_path, "sources": sources, "extra_members": extra,
                      "delta_manifest": delta, "base_name": base_package["package_name"],
                      "base_sha": base_package["package_sha256"], "raw_by_run": raw_map,
                      "package_group": group_name, "run_id": run_id})
        plans.append({"package": package_name, "package_group": group_name,
                      "included_run_ids": included_run_ids,
                      "file_count": len(records) + len(extra) + 2,
                      "uncompressed_source_bytes": sum(item["bytes"] for item in records),
                      "raw_bytes": sum(item["bytes"] for item in records
                                       if Path(item["archive_path"]).name == "raw.csv"),
                      "raw_sha256_by_run": raw_map, "new_physical_solve_count": solve_count,
                      "new_files": sorted(new_files), "modified_files": sorted(modified_files),
                      "qa_path": qa_path.relative_to(REPO).as_posix()})

    allowed_worktree = {path.relative_to(REPO).as_posix() for path in evidence_paths}
    allowed_worktree.update(raw.relative_to(REPO).as_posix() for raw in raw_paths.values())
    allowed_worktree.update(relpath for _path, relpath in workflow_paths)
    checkpoint_raw_sha = {
        f"{SERIES.relative_to(REPO).as_posix()}/{item['raw_path']}": item["raw_sha256"]
        for item in base_raw_refs
    }
    status = subprocess.run(["git", "status", "--porcelain=v1", "--untracked-files=all"],
                            cwd=REPO, text=True, capture_output=True, check=True).stdout
    unexpected = []
    for line in status.splitlines():
        relpath = line[3:]
        if relpath.startswith("\"") and relpath.endswith("\""):
            relpath = json.loads(relpath)
        if relpath not in allowed_worktree:
            expected_raw_sha = checkpoint_raw_sha.get(relpath)
            if expected_raw_sha:
                raw_path = REPO / relpath
                if raw_path.is_file() and not raw_path.is_symlink() and root.sha256(raw_path) == expected_raw_sha:
                    continue
            unexpected.append(relpath)
    if unexpected:
        raise RuntimeError("manual-run DELTA refuses unrelated worktree changes: " + ", ".join(sorted(unexpected)))

    stage_paths = {manifest_rel}
    stage_paths.update(path.relative_to(REPO).as_posix() for path in evidence_paths if path != script_path)
    stage_paths.update(relpath for _path, relpath in workflow_paths)
    return specs, {"checkpoint": checkpoint, "checkpoint_history": checkpoint_history,
                   "references": references, "run_ids": manual_ids, "new_raw_by_run": new_raw_by_run,
                   "pre_commit_head": head, "workflow_paths": [rel for _path, rel in workflow_paths],
                   "workflow_path_pairs": [(str(path), rel) for path, rel in workflow_paths],
                   "evidence_paths": sorted(stage_paths - {rel for _path, rel in workflow_paths}),
                   "stage_paths": sorted(stage_paths),
                   "plan": {"package_mode": "MANUAL_RUN_DELTA", "tag": tag,
                            "base_commit": head, "base_checkpoint_tag": checkpoint["tag"],
                            "base_package_set": prior_packages,
                            "referenced_existing_raw_count": len(references),
                            "new_run_ids": manual_ids, "new_physical_solve_count": len(manual_ids),
                            "solver_invocations_this_task": 0,
                            "manifest_count": current_manifest.get("physical_solve_count"),
                            "manifest_registered_maximum": current_manifest.get("maximum_physical_solve_count"),
                            "html_included": False, "package_count": len(specs), "packages": plans}}


def submit_manual_run_delta(args: argparse.Namespace, root: Any,
                            prepared: tuple[list[dict[str, Any]], dict[str, Any]] | None = None) -> int:
    specs, context = prepared if prepared is not None else manual_run_delta_specs(args.tag, root)
    if specs is None:
        raise RuntimeError("no new uncheckpointed manual runs are available")
    mirror_dir = Path(args.mirror_dir).expanduser().resolve()
    if not mirror_dir.is_dir():
        raise RuntimeError(f"BVM package mirror is not accessible: {mirror_dir}")
    collisions = [str(path) for spec in specs for path in (spec["target"], spec["qa_path"]) if path.exists()]
    collisions.extend(str(mirror_dir / spec["name"]) for spec in specs if (mirror_dir / spec["name"]).exists())
    if collisions:
        raise FileExistsError("refusing immutable manual-run package overwrite: " + ", ".join(collisions))
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", **context["plan"],
                          "source_paths_to_commit": context["stage_paths"],
                          "mirror_dir": str(mirror_dir), "push_target": "bvm/master",
                          "no_files_modified": True}, ensure_ascii=False, indent=2))
        return 0

    workflow_dirty = []
    for absolute, relpath in context["workflow_path_pairs"]:
        if subprocess.run(["git", "diff", "--quiet", "--", relpath], cwd=REPO,
                          check=False).returncode != 0:
            workflow_dirty.append(relpath)
    if workflow_dirty:
        subprocess.run(["git", "add", "-f", "--", *workflow_dirty], cwd=REPO, check=True)
        staged = git("diff", "--cached", "--name-only").splitlines()
        if staged != sorted(workflow_dirty):
            raise RuntimeError("workflow maintenance commit would stage paths outside the submit script/README")
        subprocess.run(["git", "commit", "-m", "tools: generalize manual-run DELTA submission"],
                       cwd=REPO, check=True)

    evidence_paths = context["evidence_paths"]
    if evidence_paths:
        subprocess.run(["git", "add", "-f", "--", *evidence_paths], cwd=REPO, check=True)
    staged = git("diff", "--cached", "--name-only").splitlines()
    if any(path not in set(evidence_paths) for path in staged):
        raise RuntimeError("manual-run evidence commit would stage paths outside the run/manifest scope")
    if staged:
        run_label = ",".join(context["run_ids"])
        subprocess.run(["git", "commit", "-m", f"evidence: record manual runs {run_label}"],
                       cwd=REPO, check=True)
    source_head = git("rev-parse", "HEAD")

    results = []
    for spec in specs:
        spec["delta_manifest"]["head_commit"] = source_head
        spec["extra_members"]["DELTA_MANIFEST.json"] = (
            json.dumps(spec["delta_manifest"], ensure_ascii=False, indent=2) + "\n").encode()
        result = root.archive_bundle(spec, source_head)
        archive_path, qa_path = REPO / result["path"], REPO / result["qa_path"]
        qa = root.verify_existing_bundle(archive_path, qa_path)
        if (qa.get("status") != "PASS" or qa.get("source_commit") != source_head or
                qa.get("package_sha256") != root.sha256(archive_path) or
                qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"manual-run PACKAGE_QA/member integrity failure: {spec['name']}")
        with zipfile.ZipFile(archive_path, "r") as archive:
            if any(name.lower().endswith(".html") for name in archive.namelist()):
                raise RuntimeError(f"HTML must remain local: {spec['name']}")
            delta = json.loads(archive.read("DELTA_MANIFEST.json"))
            if (delta.get("head_commit") != source_head or
                    delta.get("authorization_status") != "NOT_ASSERTED_BY_PACKAGING"):
                raise RuntimeError(f"manual-run DELTA scope/head failure: {spec['name']}")
            for member, digest in delta["included_file_sha256"].items():
                if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                    raise RuntimeError(f"manual-run ZIP member SHA mismatch: {spec['name']}/{member}")
        for run_id, expected in context["new_raw_by_run"].items():
            raw = RUNS / run_id / "raw.csv"
            if root.sha256(raw) != expected:
                raise RuntimeError(f"manual-run immutable raw SHA changed during packaging: {run_id}")
        result.update({"sha256": qa["package_sha256"], "bytes": qa["package_bytes"],
                       "status": qa["status"], "package_group": spec["package_group"]})
        results.append(result)

    new_refs = list(context["references"])
    for result in results:
        run_id = result.get("package_group", "")
        if not run_id.endswith("_raw"):
            continue
        actual_run_id = run_id[:-4]
        new_refs.append({"run_id": actual_run_id, "raw_path": f"runs/{actual_run_id}/raw.csv",
                         "raw_sha256": context["new_raw_by_run"][actual_run_id],
                         "source_package_name": Path(result["path"]).name,
                         "source_package_sha256": result["sha256"]})
    new_refs.sort(key=lambda item: int(item["run_id"].split("_", 1)[0][1:]))
    current_registry = {"schema": "bvm4x4-manual-run-delta-checkpoints-v1",
                        "checkpoints": context["checkpoint_history"]}
    checkpoint_entry = {
        "tag": args.tag, "base_commit": context["pre_commit_head"], "source_commit": source_head,
        "package_set": [{"package_group": item["package_group"],
                         "package_name": Path(item["path"]).name,
                         "package_sha256": item["sha256"], "package_bytes": item["bytes"],
                         "source_commit": source_head} for item in results],
        "new_run_ids": context["run_ids"],
        "run_ids": sorted({item["run_id"] for item in new_refs},
                           key=lambda rid: int(rid.split("_", 1)[0][1:])),
        "new_raw_sha256_by_run": context["new_raw_by_run"],
        "all_raw_references": new_refs,
        "new_physical_solve_count": len(context["run_ids"]),
        "solver_invocations_this_task": 0, "html_included": False,
        "authorization_status": "NOT_ASSERTED_BY_PACKAGING",
        "scientific_interpretation_performed": False,
    }
    if any(item.get("tag") == args.tag for item in current_registry["checkpoints"]):
        raise RuntimeError(f"manual-run DELTA tag already exists in checkpoint registry: {args.tag}")
    current_registry["checkpoints"].append(checkpoint_entry)
    MANUAL_RUN_CHECKPOINTS_PATH.write_text(
        json.dumps(current_registry, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    package_paths = [REPO / path for item in results for path in (item["path"], item["qa_path"])]
    checkpoint_rel = MANUAL_RUN_CHECKPOINTS_PATH.relative_to(REPO).as_posix()
    subprocess.run(["git", "add", "-f", "--", *[path.relative_to(REPO).as_posix() for path in package_paths],
                    checkpoint_rel], cwd=REPO, check=True)
    subprocess.run(["git", "commit", "-m", f"package: archive manual-run DELTA {args.tag}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    mirror = root.copy_mirror([spec["target"] for spec in specs], mirror_dir)
    print(json.dumps({"status": "MANUAL_RUN_DELTA_SUBMIT_COMPLETE",
                      "source_commit": source_head, "final_commit": git("rev-parse", "HEAD"),
                      "push": push_status, "packages": results,
                      "base_commit": context["pre_commit_head"],
                      "base_checkpoint_tag": context["checkpoint"]["tag"],
                      "referenced_existing_raw_count": len(context["references"]),
                      "included_run_ids": context["run_ids"],
                      "new_physical_solve_count": len(context["run_ids"]),
                      "solver_invocations_this_task": 0,
                      "authorization_status": "NOT_ASSERTED_BY_PACKAGING",
                      "html_included": False, "mirror": mirror}, ensure_ascii=False, indent=2))
    return 0


def checkpointed_raw_git_plan(root: Any) -> dict[str, Any]:
    if git("branch", "--show-current") != "master":
        raise RuntimeError("checkpointed raw tracking requires the master branch")
    head = git("rev-parse", "HEAD")
    if git("rev-parse", "bvm/master") != head:
        raise RuntimeError("checkpointed raw tracking requires local master to match bvm/master")
    if git("diff", "--cached", "--name-only"):
        raise RuntimeError("checkpointed raw tracking refuses pre-staged changes")
    if git("diff", "--cached", "--name-only"):
        raise RuntimeError("checkpointed raw tracking refuses pre-staged changes")

    registry = json.loads(MANUAL_RUN_CHECKPOINTS_PATH.read_text(encoding="utf-8"))
    if registry.get("schema") != "bvm4x4-manual-run-delta-checkpoints-v1" or not registry.get("checkpoints"):
        raise RuntimeError("manual-run checkpoint registry is missing or invalid")
    checkpoint = registry["checkpoints"][-1]
    run_ids = checkpoint.get("new_run_ids", [])
    expected_raw = checkpoint.get("new_raw_sha256_by_run", {})
    package_by_group = {item.get("package_group"): item for item in checkpoint.get("package_set", [])}
    if not run_ids or set(run_ids) != set(expected_raw):
        raise RuntimeError("latest checkpoint does not identify its complete new raw set")

    experiment = json.loads((SERIES / "experiment_manifest.json").read_text(encoding="utf-8"))
    manifest_rows = {item.get("run_id"): item for item in experiment.get("runs", [])}
    files = []
    for run_id in run_ids:
        raw = RUNS / run_id / "raw.csv"
        result = json.loads((RUNS / run_id / "result.json").read_text(encoding="utf-8"))
        qa = json.loads((RUNS / run_id / "qa.json").read_text(encoding="utf-8"))
        raw_qa = json.loads((RUNS / run_id / "raw_qa.json").read_text(encoding="utf-8"))
        row = manifest_rows.get(run_id)
        expected = expected_raw[run_id]
        if (not raw.is_file() or raw.is_symlink() or root.sha256(raw) != expected or
                result.get("raw_sha256") != expected or result.get("raw_bytes") != raw.stat().st_size or
                qa.get("status") != "PASS" or qa.get("raw_sha256_after_analysis") != expected or
                raw_qa.get("status") != "PASS" or raw_qa.get("raw_sha256_after_analysis") != expected or
                not row or row.get("raw_sha256") != expected or raw.stat().st_size >= root.MAX_GIT_FILE_BYTES):
            raise RuntimeError(f"checkpointed raw/result/QA identity mismatch: {run_id}")

        package_item = package_by_group.get(f"{run_id}_raw")
        if not package_item:
            raise RuntimeError(f"checkpoint has no per-run raw ZIP identity: {run_id}")
        package = HANDOFF / package_item["package_name"]
        package_qa_path = HANDOFF / f"{Path(package_item['package_name']).stem}_PACKAGE_QA.json"
        package_qa = root.verify_existing_bundle(package, package_qa_path)
        raw_member = f"{SERIES.relative_to(REPO).as_posix()}/runs/{run_id}/raw.csv"
        if (package_qa.get("package_sha256") != package_item.get("package_sha256") or
                package_qa.get("raw_sha256_by_run", {}).get(run_id) != expected or
                package_qa.get("included_file_sha256", {}).get(raw_member) != expected or
                package_qa.get("reopened_zip_crc_and_member_hashes_pass") is not True):
            raise RuntimeError(f"checkpointed raw ZIP does not attest the exact raw bytes: {run_id}")

        rel = raw.relative_to(REPO).as_posix()
        tracked = subprocess.run(["git", "ls-files", "--error-unmatch", rel], cwd=REPO,
                                 check=False, capture_output=True).returncode == 0
        if tracked and root.sha256(raw) != expected:
            raise RuntimeError(f"already tracked raw differs from its immutable checkpoint: {run_id}")
        attribute = subprocess.run(["git", "check-attr", "filter", "--", rel], cwd=REPO,
                                   text=True, capture_output=True, check=True).stdout.strip()
        filter_value = attribute.rsplit(": filter: ", 1)[-1]
        if filter_value not in {"unspecified", "unset"}:
            raise RuntimeError(f"refusing implicit Git filter/LFS conversion for {rel}: {filter_value}")
        files.append({"run_id": run_id, "path": rel, "bytes": raw.stat().st_size,
                      "sha256": expected, "package_name": package_item["package_name"],
                      "package_sha256": package_item["package_sha256"], "already_tracked": tracked})

    to_add = {item["path"] for item in files if not item["already_tracked"]}
    allowed = set(to_add)
    script_rel = Path(__file__).resolve().relative_to(REPO).as_posix()
    readme_rel = (SERIES / "README.md").relative_to(REPO).as_posix()
    for path in (script_rel, readme_rel):
        if subprocess.run(["git", "diff", "--quiet", "--", path], cwd=REPO,
                          check=False).returncode != 0:
            allowed.add(path)
    status = subprocess.run(["git", "status", "--porcelain=v1", "--untracked-files=all"],
                            cwd=REPO, text=True, capture_output=True, check=True).stdout
    unexpected = []
    for line in status.splitlines():
        rel = line[3:]
        if rel not in allowed:
            unexpected.append(rel)
    if unexpected:
        raise RuntimeError("checkpointed raw tracking refuses unrelated worktree changes: " +
                           ", ".join(sorted(unexpected)))
    return {"head": head, "checkpoint_tag": checkpoint.get("tag"), "run_ids": run_ids,
            "files": files, "to_add": sorted(to_add), "workflow_paths": sorted(allowed - to_add),
            "physical_solve_count": 0}


def submit_checkpointed_raws(args: argparse.Namespace, root: Any) -> int:
    plan = checkpointed_raw_git_plan(root)
    if not plan["to_add"]:
        print(json.dumps({"status": "RAW_ALREADY_TRACKED", **plan,
                          "commit_created": False, "solver_invocations": 0}, ensure_ascii=False, indent=2))
        return 0
    if args.dry_run:
        print(json.dumps({"status": "DRY_RUN_PASS", **plan,
                          "push_target": "bvm/master", "zip_recreated": False,
                          "no_files_modified": True}, ensure_ascii=False, indent=2))
        return 0

    if plan["workflow_paths"]:
        subprocess.run(["git", "add", "-f", "--", *plan["workflow_paths"]], cwd=REPO, check=True)
        staged = git("diff", "--cached", "--name-only").splitlines()
        if staged != plan["workflow_paths"]:
            raise RuntimeError("raw tracking maintenance commit staged unexpected paths")
        subprocess.run(["git", "commit", "-m", "tools: add checkpointed raw tracking command"],
                       cwd=REPO, check=True)
    subprocess.run(["git", "add", "-f", "--", *plan["to_add"]], cwd=REPO, check=True)
    staged = git("diff", "--cached", "--name-only").splitlines()
    if staged != plan["to_add"]:
        raise RuntimeError("raw data commit staged paths outside the checkpointed raw set")
    run_label = ",".join(plan["run_ids"])
    subprocess.run(["git", "commit", "-m", f"data: track checkpointed raw files {run_label}"],
                   cwd=REPO, check=True)
    push_status = "SKIPPED"
    if not args.no_push:
        subprocess.run(["git", "push"], cwd=REPO, check=True)
        push_status = "PASS"
    print(json.dumps({"status": "CHECKPOINTED_RAWS_TRACKED",
                      "commit": git("rev-parse", "HEAD"), "push": push_status,
                      "checkpoint_tag": plan["checkpoint_tag"], "run_ids": plan["run_ids"],
                      "files": plan["files"], "zip_recreated": False,
                      "solver_invocations": 0}, ensure_ascii=False, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Submit/package only this 4x4 experiment scope")
    parser.add_argument("tag")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-push", action="store_true")
    parser.add_argument("--delta", action="store_true",
                        help="append the completed batch to its verified checkpoint using the local DELTA workflow")
    parser.add_argument("--d3-carry-timing", action="store_true",
                        help="package/push only the completed A040/A041 D3 carry-timing delta")
    parser.add_argument("--d3-manual-supplement", action="store_true",
                        help="package user-confirmed manual A042-A044 as a separate non-retroactive supplement")
    parser.add_argument("--carry4-manual-supplement", action="store_true",
                        help="package manual A045-A047 as a separate non-retroactive CARRY4 supplement")
    parser.add_argument("--carry4-functional-28", action="store_true",
                        help="package the read-only C4R28_210 analysis and 28 manual raw files as a dedicated DELTA")
    parser.add_argument("--manual-runs", action="store_true",
                        help="package all newly discovered uncheckpointed manual run directories as an immutable DELTA")
    parser.add_argument("--track-packaged-raws", action="store_true",
                        help="commit raw CSVs already present in the latest verified package checkpoint; do not rebuild ZIPs")
    parser.add_argument("--metadata-v2", action="store_true",
                        help="create a corrected metadata-only v2; never runs JoSIM")
    parser.add_argument("--message")
    parser.add_argument("--mirror-dir", default=str(MIRROR_DEFAULT))
    args = parser.parse_args()
    try:
        root = load_root_submit()
        if args.track_packaged_raws:
            if (args.delta or args.d3_carry_timing or args.d3_manual_supplement or
                    args.carry4_manual_supplement or args.carry4_functional_28 or
                    args.manual_runs or args.metadata_v2):
                raise RuntimeError("--track-packaged-raws cannot be combined with another package mode")
            return submit_checkpointed_raws(args, root)
        if args.manual_runs:
            if (args.d3_carry_timing or args.d3_manual_supplement or args.carry4_manual_supplement or
                    args.carry4_functional_28 or args.metadata_v2):
                raise RuntimeError("--manual-runs cannot be combined with another fixed package mode")
            return submit_manual_run_delta(args, root)
        if args.carry4_functional_28:
            if args.delta or args.d3_carry_timing or args.d3_manual_supplement or args.carry4_manual_supplement or args.metadata_v2:
                raise RuntimeError("--carry4-functional-28 cannot be combined with other package modes")
            return submit_c4r28_functional_delta(args, root)
        if args.carry4_manual_supplement:
            if args.delta or args.d3_carry_timing or args.d3_manual_supplement or args.metadata_v2:
                raise RuntimeError("--carry4-manual-supplement cannot be combined with other package modes")
            return submit_carry4_manual_supplement(args, root)
        if args.d3_manual_supplement:
            if args.delta or args.d3_carry_timing or args.metadata_v2:
                raise RuntimeError("--d3-manual-supplement cannot be combined with other package modes")
            return submit_d3_manual_supplement(args, root)
        if args.d3_carry_timing:
            if args.delta or args.metadata_v2:
                raise RuntimeError("--d3-carry-timing cannot be combined with --delta or --metadata-v2")
            return submit_d3_carry_timing_delta(args, root)
        if args.delta:
            if args.metadata_v2:
                raise RuntimeError("--delta and --metadata-v2 are mutually exclusive")
            if _manual_run_pending_for_auto_route():
                return submit_manual_run_delta(args, root)
            carry_sjtl_position_batch = CARRY_SJTL_POSITION_TASK / "attempts" / "003" / "BATCH_MANIFEST.json"
            if carry_sjtl_position_batch.is_file():
                return submit_carry_sjtl_position_delta(args, root)
            carry_post_cb_sjtl_batch = CARRY_POST_CB_SJTL_TASK / "BATCH_MANIFEST.json"
            if carry_post_cb_sjtl_batch.is_file():
                return submit_carry_post_cb_sjtl_delta(args, root)
            carry_buffer_all_batch = CB_CARRY_BUFFER_ALL_TASK / "BATCH_MANIFEST.json"
            if carry_buffer_all_batch.is_file():
                return submit_cb_carry_buffer_all_delta(args, root)
            carry_buffer_batch = (CB_CARRY_BUFFER_D1_TASK / "BATCH_MANIFEST.json")
            if carry_buffer_batch.is_file():
                return submit_cb_carry_buffer_d1_delta(args, root)
            cb_direct_batch = (SERIES / "analysis/cb-direct-d1-20261009/attempts/002/BATCH_MANIFEST.json")
            if cb_direct_batch.is_file():
                return submit_cb_direct_d1_delta(args, root)
            chain_manifest = SERIES / "analysis" / "t1-chain-20261009" / "BATCH_MANIFEST.json"
            if chain_manifest.is_file():
                return submit_t1_chain_delta(args, root)
            return submit_delta(args, root)
        validate_scope()
        if args.metadata_v2:
            return submit_metadata_v2(args, root)
        specs, _plan = package_specs(args.tag, root, dry_run=args.dry_run)
        mirror_dir = Path(args.mirror_dir).expanduser().resolve()
        if not mirror_dir.is_dir():
            raise RuntimeError(f"mirror directory is not accessible: {mirror_dir}")
        mirror_collisions = [spec["name"] for spec in specs if (mirror_dir / spec["name"]).exists()]
        if mirror_collisions:
            raise FileExistsError("same-name mirror target already exists: " + ", ".join(mirror_collisions))
        if args.dry_run:
            return 0
        source_paths = included_files(SERIES)
        relative_paths = [path.relative_to(REPO).as_posix() for path in source_paths]
        if relative_paths:
            subprocess.run(["git", "add", "-A", "-f", "--", *relative_paths], cwd=REPO, check=True)
        staged_empty = subprocess.run(["git", "diff", "--cached", "--quiet"],
                                       cwd=REPO, check=False).returncode == 0
        if staged_empty:
            raise RuntimeError("no scoped experiment/source changes to commit")
        subprocess.run(["git", "commit", "-m", args.message or "experiment: add BVM 4x4 diagonal batch"],
                       cwd=REPO, check=True)
        source_commit = git("rev-parse", "HEAD")
        package_results = []
        for spec in specs[:-1]:
            package_results.append(root.archive_bundle(spec, source_commit))
        update_summary_with_packages(package_results)
        subprocess.run(["git", "add", "--", (SERIES / "BATCH_SUMMARY.md").relative_to(REPO).as_posix()],
                       cwd=REPO, check=True)
        if subprocess.run(["git", "diff", "--cached", "--quiet"],
                          cwd=REPO, check=False).returncode != 0:
            subprocess.run(["git", "commit", "-m", "docs: record 4x4 run package hashes"], cwd=REPO, check=True)
        summary_commit = git("rev-parse", "HEAD")
        package_results.append(root.archive_bundle(specs[-1], summary_commit))
        package_paths = []
        for result in package_results:
            package_paths.extend((REPO / result["path"], REPO / result["qa_path"]))
        subprocess.run(["git", "add", "--", (SERIES / "BATCH_SUMMARY.md").relative_to(REPO).as_posix()],
                       cwd=REPO, check=True)
        subprocess.run(["git", "add", "-f", "--", *[p.relative_to(REPO).as_posix() for p in package_paths]],
                       cwd=REPO, check=True)
        subprocess.run(["git", "commit", "-m", f"package: archive 4x4 diagonal batch {args.tag}"],
                       cwd=REPO, check=True)
        push_status = "SKIPPED"
        if not args.no_push:
            subprocess.run(["git", "push"], cwd=REPO, check=True)
            push_status = "PASS"
        mirror_results = root.copy_mirror([REPO / x["path"] for x in package_results], mirror_dir)
        print(json.dumps({"status": "SUBMIT_COMPLETE", "source_commit": source_commit,
                          "summary_commit": summary_commit, "final_commit": git("rev-parse", "HEAD"),
                          "push": push_status, "packages": package_results,
                          "mirror": mirror_results}, ensure_ascii=False, indent=2))
        return 0
    except (OSError, RuntimeError, ValueError, KeyError, json.JSONDecodeError, subprocess.CalledProcessError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
