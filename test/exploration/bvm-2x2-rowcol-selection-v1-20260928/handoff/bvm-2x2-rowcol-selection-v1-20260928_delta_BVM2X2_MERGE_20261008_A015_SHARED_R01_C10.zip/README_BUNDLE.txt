DELTA evidence package bvm-2x2-rowcol-selection-v1-20260928_delta_BVM2X2_MERGE_20261008_A015_SHARED_R01_C10.zip
Base package: bvm-2x2-rowcol-selection-v1-20260928_snapshot_bvm2x2-rowcol-a001.zip
Base SHA-256: 90b174f0f7ea71c6d41bcf85db1d999af9c173c0b0ecbb8de31f1c96bb4e3f50
New run raw files are included once; pre-existing raws are referenced by path and SHA-256.
Generated HTML is excluded. ZIP CRC/member SHA verification passed at creation.
No scientific interpretation is performed by packaging.
