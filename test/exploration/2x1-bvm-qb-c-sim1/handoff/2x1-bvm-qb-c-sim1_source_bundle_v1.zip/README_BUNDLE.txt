Workspace snapshot bundle of files as present on 2026-09-24.
This archive preserves the files byte-for-byte but does not independently certify
solver identity, run completion, raw semantics, or scientific validity.
No simulation was run while packaging. See BUNDLE_MANIFEST.json for member hashes.
