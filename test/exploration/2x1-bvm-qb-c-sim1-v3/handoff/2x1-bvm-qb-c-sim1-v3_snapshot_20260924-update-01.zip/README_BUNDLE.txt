Byte-preserving snapshot of 2x1-bvm-qb-c-sim1-v3.
Archive integrity and member hashes are checked; this package does not certify
solver identity, raw semantics, or scientific validity.
