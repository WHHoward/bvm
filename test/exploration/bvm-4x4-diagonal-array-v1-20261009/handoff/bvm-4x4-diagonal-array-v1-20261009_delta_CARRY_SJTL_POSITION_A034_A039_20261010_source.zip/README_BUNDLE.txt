Incremental BVM 4x4 Carry sJTL placement evidence for bvm-4x4-diagonal-array-v1-20261009; tag=A034_A039_20261010; group=source.
Base checkpoint: bvm-4x4-diagonal-array-v1-20261009_delta_CARRY_POST_CB_SJTL_A030_A033_20261010_source.zip (a77b77cfc17ca76c7ba82ce622ba51911c6390b53abb6ca6c05f4932f744fa26).
A001-A033 raw evidence is referenced by exact package/raw SHA and is not recopied.
A034-A039 are the only new physical solves. HTML is excluded.
Mechanical evidence only; no SFQ/event classifier or scientific interpretation.
