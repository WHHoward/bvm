Shared metadata snapshot for bvm-4x4-diagonal-array-v1-20261009.
Authorized runs: A001_D3_N0, A002_D3_N1, A003_D3_N2, A004_D3_N3, A005_D3_N4, A006_PAPER_1101_1101
Per-run raw files are stored only in their own handoff archives.
Generated HTML/Plotly JS and historical artifacts are excluded.
No new physical solve or scientific interpretation by packaging.
