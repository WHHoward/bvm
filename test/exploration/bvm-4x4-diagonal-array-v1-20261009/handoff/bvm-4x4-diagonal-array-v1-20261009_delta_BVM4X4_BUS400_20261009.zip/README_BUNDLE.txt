Incremental evidence delta for bvm-4x4-diagonal-array-v1-20261009; tag=BVM4X4_BUS400_20261009.
Git base: 3de08ba0fd5997b253269849dbc1a535786c8fd6
Metadata checkpoint: bvm-4x4-diagonal-array-v1-20261009_metadata_v2_BVM4X4_20261009.zip (19af77800333d2c596b25606c26ac84fbd0ae4101b5b14f83fefc121c5975be1)
Contains only changed/new source and the two new BUS400 runs.
A001-A006 raw is referenced by immutable package/raw SHA and is not copied.
Generated HTML is excluded. No scientific interpretation.
